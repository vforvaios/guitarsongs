INSERT INTO public.tenants_templates_page_sections (id,tenant_id,template_page_section_id,"label",slug,orderid,richtext,singlephoto,link,photos,isactive) VALUES
	 (1,3,1,'','',1,'','','','',1),
	 (2,3,2,'INFO','info',2,'','https://picsum.photos/1024/500','https://www.google.com','',1),
	 (3,3,3,'ΣΧΕΤΙΚΑ ΜΕ ΕΜΑΣ','aboutus',3,'<h1>Σχετικά με εμάς</h1>
  <p>
    Αυτό είναι ένα απλό κείμενο παράδειγμα που προέρχεται από έναν rich text editor.
    Μπορείς να το επικολλήσεις στη βάση δεδομένων ως HTML και να το εμφανίσεις
    όπως ακριβώς θα το βλέπεις σε έναν editor — με υποστήριξη μορφοποίησης,
    στίχων και inline στοιχείων.
  </p>','','','',1),
	 (4,3,4,'GALLERY','gallery',4,'','','','https://picsum.photos/400/600,https://picsum.photos/400/600,https://picsum.photos/400/600,https://picsum.photos/400/600',1),
	 (5,3,5,'','',7,'','','','',1),
	 (6,3,6,'ΕΠΙΚΟΙΝΩΝΙΑ','contact',6,'','','','',1),
	 (7,3,7,'ΡΑΝΤΕΒΟΥ','booking',5,'','','','',1);
