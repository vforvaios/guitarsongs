INSERT INTO public.difficulties (id,difficulty,"level") VALUES
	 (1,'ΕΥΚΟΛΟ','easy'),
	 (2,'ΜΕΤΡΙΟ','medium'),
	 (3,'ΔΥΣΚΟΛΟ','hard');
