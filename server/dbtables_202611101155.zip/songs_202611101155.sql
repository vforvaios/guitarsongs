INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Να μαγαπάς',2,NULL,0,NULL,'2026-09-11 13:35:23','2026-09-28 07:48:37','{title: Να μαγαπάς}
{verse: Verse}
[C]Σου γράφω πάλι από α[G]νάγκη
[F]η ώρα [G]πέντε το [C]πρωί
[C]το μόνο πράμα που ''χει [G]μείνει
[F]όρθιο [G]στον κόσμο είσαι [C]εσύ

[F]τι να [G]τις κάνω τις [C]τιμές τους
[F]τα λόγια [G]τα θεατρι[C]κά [Am]
[Am]μες στην οθόνη του [G]μυαλού μου
[F]χάρτινα [G]είδωλα νε[C]κρά
 
{verse: Chorus}
[C]Να μ'' α[Dm]γαπάς όσο [G]μπορείς να μ'' α[C]γαπάς
[C]Να μ'' α[Dm]γαπάς όσο [G]μπορείς να μ'' α[C]γαπάς

{verse: Verse}
[C]Κοιτάζοντας μες στον [G]καθρέφτη
[F]βλέπω έ[G]να πρόσωπο [C]γνωστό
[C]κι ίσως η ασχήμια του [G]να φύγει
[F]μόλις [G]πλυθώ και ξυ[C]ριστώ
[F]βρομάει η [G]ανάσα απ'' τα [C]τσιγάρα
[F]βαραίνει [G]ο νους μου απ'' τα [C]ποτά [Am]
[Am]στον τοίχο κάποια Μό[G]να Λίζα
[F]σε φέρνει [G]ακόμα πιο [C]κοντά

{verse: Chorus}
[C]Να μ'' α[Dm]γαπάς όσο [G]μπορείς να μ'' α[C]γαπάς
[C]Να μ'' α[Dm]γαπάς όσο [G]μπορείς να μ'' α[C]γαπάς

{verse: Verse}
[C]Αν και τελειώνει αυτό [G]το γράμμα
[F]η ανά[G]γκη μου δεν στα[C]ματά
[C]σαν το πουλί πάνω [G]στο σύρμα
[F]σαν τον [G]αλήτη που [C]γυρνάει
[F]θέλω [G]να ''ρθείς και να [C]μανάψεις
[F]το πα[G]ραμύθι να [C]μου πεις [Am]
[Am]σαν μάνα γη να μ'' α[G]γκαλιάσεις
[F]σαν ά[G]σπρο φώς να ξα[C]ναρθείς

{verse: Chorus}
[C]Να μ'' α[Dm]γαπάς όσο [G]μπορείς να μ'' α[C]γαπάς
[C]Να μ'' α[Dm]γαπάς όσο [G]μπορείς να μ'' α[C]γαπάς',NULL),
	 ('All Apologies',3,NULL,0,NULL,'2026-09-11 14:42:11','2026-09-28 07:06:08','{title: All Apologies}

{verse: Verse}
[G]What else should I be, all apologies
[G]What else could I say, everyone is gay
[G]What else could I write, I don''t have the right
[G]What else should I be, all apologies
 
[C]In the sun, in the sun I feel as one
[C]In the sun, in the sun

[D]Married, buried
 
{verse: Verse}
[G]I wish I was like you, easily amused
[G]Find my nest of salt, everything''s my fault
[G]I''ll take all the blame, aqua seafoam shame
[G]Sunburn, freezer burn, choking on the ashes of her enemy

[C]In the sun, in the sun I feel as one
[C]In the sun, in the sun

[D]Married, buried
[D]Married, buried, yeah, yeah, yeah, yeah
 
[D]All in all is all we are
[D]All in all is all we are
[D]All in all is all we are
[D]All in all is all we are
 
(Repeat all the All in alls 4 more times, 20 lines in total)','D DU UDU'),
	 ('Knocking on Heavens door',4,NULL,0,NULL,'2026-09-11 14:51:13','2026-10-05 07:11:09','{title: Knocking on Heavens door}
{verse: Intro}
[G] [D] [Am]
(instrumental)
[G]    [D]   [Am]
 Oo, ooh-ooh
[G]    [D]   [C]
 Oo, ooh-ooh
 
{verse: Verse}
[G]Mama, [D]take this badge off of [Am]me
[G]I can''t [D]use it any[C]more
[G]It''s getting [D]dark to dark to [Am]see
[G]Feel like I''m [D]knocking on heaven''s [C]door
 
{verse: Chorus}
[G]Knock, knock, [D]knockin’ on heaven''s [Am]door
[G]Knock, knock, [D]knockin’ on heaven’s [C]door
[G]Knock, knock, [D]knockin’ on heaven''s [Am]door
[G]Knock, knock, [D]knockin’ on heaven’s [C]door
 
{verse: Verse}
[G]Mama, [D]put my guns in the [Am]ground
[G]I can''t [D]shoot them any[C]more
[G]That long black [D]cloud is coming [Am]down
[G]I feel I''m [D]knocking on heaven''s [C]door
 
{verse: Chorus}
[G]Knock, knock, [D]knockin’ on heaven''s [Am]door
[G]Knock, knock, [D]knockin’ on heaven’s [C]door
[G]Knock, knock, [D]knockin’ on heaven''s [Am]door
[G]Knock, knock, [D]knockin’ on heaven’s [C]door
 
{verse: Outro}
[G]    [D]   [Am]
 Oo, ooh-ooh
[G]    [D]   [C]
 Oo, ooh-ooh
(quick fade)','D-D-UD'),
	 ('Iris',5,NULL,0,NULL,'2026-09-11 15:04:32','2026-10-26 13:59:36','{title: Iris}
{verse: Intro}
[Em] [E] [C]
  
{verse: Verse}
And I''d [G]give up for[Am]ever to [C]touch you
''Cause I [Em]know that you [D]feel me some[C]how
You''re the [G]closest to [Am]heaven that [C]I''ll ever be
And I [Em]don''t want to [D]go home right [C]now
 
{verse: Verse}
And [G]all I can [Am]taste is this [C]moment
And [Em]all I can [D]breathe is your [C]life
And [G]sooner or [Am]later it''s [C]over
I just [Em]don''t [D]want to [C]miss you tonight
  
{verse: Chorus}
And I [Em]don''t want the [D]world to [C]see me
''Cause I [Em]don''t think that [D]they''d under[C]stand
When [Em]everything''s [D]made to be [C]broken
I just [Em]want you to [D]know who I [C]am
 
{verse: Verse}
And you [G]can''t fight the [Am]tears that ain''t [C]coming
Or the [Em]moment of [D]truth in your [C]lies
When [G]everything [Am]feels like the [C]movies
Yeah, you [Em]bleed just to [D]know you''re [C]alive
 
{verse: Chorus}
And I [Em]don''t want the [D]world to [C]see me
''Cause I [Em]don''t think that [D]they''d under[C]stand
When [Em]everything''s [D]made to be [C]broken
I just [Em]want you to [D]know who I [C]am
 
{verse: Instrumental}
[Em]   -    [G]  -   [Em]    -    [C] (x2)
 
 
[Chorus]
And I [Em]don''t want the [D]world to [C]see me
''Cause I [Em]don''t think that [D]they''d under[C]stand
When [Em]everything''s [D]made to be [C]broken
I just [Em]want you to [D]know who I [C]am

And I [Em]don''t want the [D]world to [C]see me
''Cause I [Em]don''t think that [D]they''d under[C]stand
When [Em]everything''s [D]made to be [C]broken
I just EGm]want you to [D]know who I [C]am
 
[Outro]
I just [Em]want you to [D]know who I [C]am
I just [Em]want you to [D]know who I [C]am
I just [Em]want you to [D]know who I [C]am','D-UDUD'),
	 ('Συννεφιασμένη Κυριακή',6,NULL,0,NULL,'2026-09-14 08:18:52','2026-09-28 07:49:27','{title: Συννεφιασμένη Κυριακή}
{verse: Intro}
[D] [Em] [D] [G] [Em] [A] [D]

{verse: Verse}
[D]Συννεφια[Em]σμένη Κυριακή[D],    [Em]μοιάζεις με [A]την καρδιά [D]μου
[Em]που έχει [A]πάντα [D]συννεφιά, [Em]συννεφιά        | 2x
[D]Χριστέ και [G]Πα-, Χριστέ και [A]Παναγιά μου   [D]| 2x

{verse: Interlude}
[D] [Em] [D] [G] [Em] [A] [D]

{verse: Verse}
[D]Είσαι μια [Em]μέρα σαν κι αυ[D]τή [Em]που ''χασα [A]την χαρά [D]μου
[Em]Συννεφια[A]σμένη Κυρια[D]κή, [Em]Κυριακή
[D]ματώνεις [G]την, ματώνεις [A]την καρδιά μου[D]

{verse: Verse}
[D]Όταν σε [Em]βλέπω βροχε[D]ρή, [Em]στιγμή δεν [A]ησυχάζω[D]
[Em]Μαύρη μου [A]κάνεις τη [D]ζωή, [Em]τη ζωή
[D]και βαρια[G]να-, και βαρια[A]ναστενάζω[D]

{verse: Outro}
[D] [Em] [D] [G] [Em] [A] [D] ',NULL),
	 ('Κάθε Ηλιοβασίλεμα',7,NULL,0,NULL,'2026-09-14 08:27:23','2026-09-28 07:49:45','{title: Κάθε Ηλιοβασίλεμα}
{verse: Intro}
[Bm] [Em] [Am] [G]  [Dm] [Em] [Dm] [Em]

{verse: Verse}
[Em]Όταν ζυγώνει η βρα[Am]διά και γλυκο[Dm]σουρουπώ[Em]νει
[Em]βαθιά μου σφάζουν την καρ[Am]διά  της ερη[Dm]μιάς μου πό[Em]νοι

{verse: Chorus}
[G]Θλιμμένο σούρουπο, ποτέ να μη νυ[Dm]χτώ[Am]νει
[G]γι αυτούς που ζούνε [Dm]μό[Em]νοι

{verse: Verse}
[Em]Κάθε ηλιοβασίλε[Am]μα δε ξέρω τι μού [Dm]φταί[Em]ει
[Em]Με παίρνει το παρά[Am]πονο, αχ, και η καρδιά μου [Dm]κλαίει[Em]

{verse: Chorus}
[G]Θλιμμένο σούρουπο, ποτέ να μη νυ[Dm]χτώ[Am]νει
[G]γι αυτούς που ζούνε [Dm]μό[Em]νο ',NULL),
	 ('Το Χρυσόψαρο',8,NULL,0,NULL,'2026-09-14 08:38:44','2026-09-28 07:51:31','{title: Το Χρυσόψαρο}
{verse: Verse}
[D]Ένα χρυσόψαρο μέσα στη γυάλα
και μια γατούλα μούρλια θηλυ[A]κό
πρασινομάτα και κοκκινομάλλα
αρχίσαν [G]ένα παιχνι[A]δάκι ερωτι[D]κό

{verse: Verse}
[D]Η γάτα λέει για δες το κοροϊδάκι
επίστεψε ότι εγώ το αγα[A]πώ
μα λέει και το κουτό χρυσό ψαράκι
Τι κούνια [G]που σε κούνα[A]γε πωπωπω[D]πω

{verse: Chorus}
Κι αν σ'' αγα[G]πώ δεν θα σου το [A]πω
το ''χω για κα[G]κό να μην [A]έχω μυστι[D]κό
Κι αν σ'' αγα[G]πώ, δε θα σ'' αγα[A]πώ
αν θα σού το [D]πω ότι [A]έχω μυστι[D]κό

{verse: Verse}
[D]Μα παίξε παίξε το ίδιο παιχνιδάκι
νιώθει η γατούλα έρωτα κρυ[A]φό
και γίνηκε αυτή το κοροϊδάκι
κι ατσίδα [G]έγινε το [A]ψάρι το χρυ[D]σό

{verse: Verse}
[D]Αυτά τα λέει ένα τραγουδάκι
που τραγουδιέται σ'' εύθυμο σκο[A]πό
Αντί να φάει η γάτα το ψαράκι
το ψάρι [G]τρώει τη γα[A]τούλα π'' αγα[D]πώ

{verse: Chorus}
Κι αν σ'' αγα[G]πώ δεν θα σου το [A]πω
το ''χω για κα[G]κό να μην [A]έχω μυστι[D]κό
Κι αν σ'' αγα[G]πώ, δε θα σ'' αγα[A]πώ
αν θα σού το [D]πω ότι [A]έχω μυστι[D]κό',NULL),
	 ('Αχ Αγάπη',9,NULL,0,NULL,'2026-09-14 08:49:01','2026-09-28 07:51:42','{title: Αχ Αγάπη}
{verse: Verse}
[Em]Θέλω να σου μιλήσω, μα [B]τρέμει η φω[Em]νή μου
[Em]λες κι αγαπάω πρώτη φο[B]ρά στη ζω[Em]ή μου     
[Am]Θέλω να τραγουδήσω, μα δε μ'' αφ[D]ήνει το [G]δάκρυ  
[Am]Αχ, α[Em]γάπη, α[B]γάπη, α[Em]γάπη              

{verse: Verse}
[G]Θέλω να σου μιλήσω κι έχω στο [D]νου μου χιλιάδες [G]σκέψεις
[G]Όμως μπροστά σε σένα χάνουν το [D]νόημα και οι [G]λέξεις
[Em]Κι όπως σε αγκαλιάζω και στο κο[B]ρμί σου φιλιά χα[Em]ράζω
[Em]φεύγεις και μένω μόνος και σου φω[B]νάζω, και σου φω[Em]νάζω
[C]Αχ, αγ[Em]άπη, α[B]γάπη, α[Em]γάπη

{verse: Verse}
[Em]Θέλω να σου μιλήσω, μα [B]πάλι σω[Em]παίνω          
[Em]Θέλω να σε χορτάσω, μα [B]δε σε χο[Em]ρταίνω          
[Am]Μέσα στα δυο σου μάτια βλέπω τον [D]ήλιο να [G]λάμπει   
[Am]Αχ, α[Em]γάπη, α[B]γάπη, α[Em]γάπη                       

{verse: Verse}
[G]Θέλω να σου μιλήσω κι έχω στο [D]νου μου χιλιάδες [G]σκέψεις
[G]Όμως μπροστά σε σένα χάνουν το [D]νόημα και οι [G]λέξεις
[Em]Κι όπως σε αγκαλιάζω και στο κο[B]ρμί σου φιλιά χα[Em]ράζω
[Em]φεύγεις και μένω μόνος και σου φω[B]νάζω, και σου φω[Em]νάζω
[C]Αχ, αγ[Em]άπη, α[B]γάπη, α[Em]γάπη',NULL),
	 ('Καρδιά Παραπονιάρα',6,NULL,0,NULL,'2026-09-14 09:03:00','2026-09-28 07:52:03','{title: Καρδιά Παραπονιάρα}

{verse: Verse}
[Dm]Ποια [E]λύ- ποια [F]λύπη σε μα[E]ραίνει
[Dm]βα[E]ριά βα[F]ριά κι'' αφόρη[E]τη
[A]Καρδιά, καρδιά παραπο[Dm]νιάρα κι''[E] απα- κι'' α[F]παρηγόρη[E]τη

{verse: Chorus}
[Dm]Σ'' αυ[E]τό, σ'' αυ[F]τό τον ψεύτη [E]κόσμο
[Dm]Τον [E]τό-, τον [F]τόσο άπο[E]νο

{verse: Verse}
[A]Καρδιά, καρδιά γιατί να [Dm]λιώνεις
[E]μέσ'' το μέσ'' [F]το παράπο[E]νο

{verse: Verse}
[Dm]Τι σ'' έ-, τι σ'' έχει αδικήσει
[Dm]και σε, και σε ξεγέλασε

{verse: Chorus}
[A]Μίλησε, μίλησε καρ[Dm]διά μου
[E]και χα και [F]χαμογέλα[E]σε',NULL),
	 ('Μην Κλαις',6,NULL,0,NULL,'2026-09-14 09:12:19','2026-09-28 07:52:21','{title: Μην Κλαις}

{verse: Verse}
[G]Μην κλαις και μην λυπάσαι που βρα[Am]διάζει
[C]Εμείς που ζήσαμε φτω[G]χοί
[G]Του κόσμου η βροχή δε μάς πει[Am]ράζει
[C]Εμείς που [D]ζούμε μονα[G]χοί

{verse: Chorus} 
[G]Τα σπίτια [D]είναι χαμη[G]λά
σαν έρη[E]μοι στρατώ[Am]νες
[C]Τα καλοκαίρια μας μι[Am]κρά   
[G]κι ατέλειω[D]τοι χειμώ[G]νες    

{verse: Verse}
[G]Μην κλαις και μην φοβάσαι το σκο[Am]τάδι
[C]Εμείς που ζήσαμε φτω[G]χοί
[G]Του κόσμου η απονιά δε μάς τρο[Am]μάζει
[C]Θα έρθει και για [D]μας μια κυρια[G]κή

{verse: Chorus}
[G]Τα σπίτια [D]είναι χαμη[G]λά
σαν έρη[E]μοι στρατώ[Am]νες
[C]Τα καλοκαίρια μας μι[Am]κρά   
[G]κι ατέλειω[D]τοι χειμώ[G]νες',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Εγώ δεν είμαι ποιητής',10,NULL,0,NULL,'2026-09-14 09:35:44','2026-09-28 07:52:28','{title: Εγώ δεν είμαι ποιητής}
{verse: Verse}
[F]Εγώ δεν είμαι ποιη[C]τής είμαι στι[Dm]χά-[C]α-[Dm]κι
[F]Είμαι στιχάκι της στι[C]γμής            
[Am]πάνω σε τοίχο φυλα[Dm]κής [C]και σε πα[Dm]γκά-[C]α-[Dm]κι 

{verse: Verse}
[F]Με τραγουδάνε οι τρε[C]λοί και οι α[Dm]λή-[C]η-[Dm]τες
[F]Καταραμένη είμαι ψυ[C]χή           
[Am]με μιαν εξόριστή ψυ[Dm]χή [C]σ'' άλλους πλα[Dm]νή-[C]ή-[Dm]τες

{verse: Verse}
[F]Εγώ δεν είμαι ποιη[C]τής, είμαι ο λυ[Dm]γμό-[C]ο-[Dm]ος σου
[F]Είμαι ένας δείπνος μυστι[C]κός           
[Am]δίπλα ο Ιούδας κλαίει σκυ[Dm]φτός [C]κι είμαι αδερ[Dm]φό-[C]ό-[Dm]ός σου',NULL),
	 ('Είναι κάτι στιγμές',10,NULL,0,NULL,'2026-09-14 09:49:24','2026-09-28 07:52:50','{title: Είναι κάτι στιγμές}

{verse: Verse}
[Bm]Είναι [D]κάτι στιγμές τρυφε[A]ρές και λε[Em]πτές
Σαν κλω[G]στές τυλιγμένες σ'' α[Bm]δράχτι
Σε γυ[D]ρνούν απαλά σε με[A]θούν σιωπηρά
Σε γε[G]μίζουν με [A]πείσμα και [Bm]άχτι

{verse: Chorus}
[Bm]Για όλα αυτά που ζητάς
Για πο[G]λλά που πο[Em]νάς
Για το [G]τίποτε μιας ευτυ[Bm]χίας
Και [Bm]γυρνάς σαν τρελός
Του κα[G]θρέπτη εαυ[Em]τός
Θύμα, [G]θύτης κα[A]κής συγκυ[Bm]ρίας

{verse: Verse}
Πλημμυ[D]ρίζουν το χθες μαγε[A]μένες σκι[Em]ές
Που ξω[G]πίσω μου γράφουν τρο[Bm]χιά
Με κρα[D]τούνε θαρρώ σαν α[A]λήθειες παλιές
Σε λα[G]βύρινθο [A]δέσμιο [Bm]βαθιά

{verse: Verse}
Είναι [D]κάτι στιγμές σαν μι[A]κρές πινε[Em]λιές
Ζωγρα[G]φιάς που δεν έχει τε[Bm]λειώσει
Λείπουν [D]λίγα ακριβά των χρω[A]μάτων νερά
Για να [G]δώσουν του [A]τόπου τη [Bm]γνώση

{verse: Chorus}
[Bm]Για τους κήπους της γης
Για το [G]ροζ της αυ[Em]γής
Για το [G]κύμα που απόμεινε [Bm]μόνο
Να [Bm]χαϊδεύει με αφρούς
Τους πι[G]κρούς μας καη[Em]μούς
Και να [G]διώχνει της [A]πίκρας τον [Bm]πόνο',NULL),
	 ('Αχ Χελιδόνι μου',11,NULL,0,NULL,'2026-09-14 09:56:33','2026-09-28 07:53:00','{title: Αχ Χελιδόνι μου}

{verse: Verse}
[Am]Αχ χελιδόνι μου, πώς να πε[Dm]τάξεις
σ'' αυτό το [E]μαύρο τον ουρα[Am]νό
[A]Αίμα σταλάζει το δειλι[Dm]νό
και πώς να [G]κλάψεις, και πώς να [E]κλάψεις
Αχ χελιδόνι [Am]μου

{verse: Verse}
[Am]Αχ παληκάρι μου, τα τραίνα φύ[Dm]γαν
δεν έχει [E]δρόμο για μισε[Am]μό
[A]Κι όσοι μιλούσαν για λυτρω[Dm]μό
πες μου που [G]πήγαν, πες μου που [E]πήγαν
Αχ παληκάρι [Am]μου

{verse: Verse}
[Am]Αχου καρδούλα μου, φυλακι[Dm]σμένη
δεν βγαίνει [E]ο ήλιος που καρτε[Am]ράς
[A]Μόνο ο τελάλης της αγο[Dm]ράς
σε ξεκου[G]φαίνει, σε ξεκου[E]φαίνει
Αχου καρδούλα [Am]μου',NULL),
	 ('Αλήτη με είπες μια βραδιά',6,NULL,0,NULL,'2026-09-14 10:48:01','2026-09-28 07:53:09','{title: Αλήτη με είπες μια βραδιά}

{verse: Verse}
[A]Αλήτη [E]μ'' είπες μια βρα[A]διά
[A]χωρίς κα[E]μιά αιτί[A]α
[D]Μα του αλήτη η κα[A]ρδιά
[E]δεν σου κρατάει κακί[A]α

{verse: Verse}
[A]Θα ''ρθει μια [E]μέρα όμως μι[A]κρή
[A]για να [E]μετανοή[A]σεις
[D]Για του αλήτη την κα[A]ρδιά
[E]θα κλάψεις, θα δακρύ[A]σεις

{verse: Verse}
[A]Αλήτη [E]μ'' είπες, μα ε[A]γώ
[A]χωρίς να [E]σε μισή[A]σω
[D]γελώ ακόμα κι αν πο[A]νώ
[E]για να μη σε λυπή[A]σω',NULL),
	 ('Φραγκοσυριανή',12,NULL,0,NULL,'2026-09-14 10:55:07','2026-09-28 07:53:23','{title: Φραγκοσυριανή}

{verse: Verse}
[Am]Μία φούντωση, μια φλόγα
που'' χω μέσα στην κα[E]ρδιά
λες και [Dm]μάγια μου'' χεις [Am]κάνει
Φραγκο[E]συρια[F]νή γλυ[E]κιά
λες και [Dm]μάγια μου ''χεις [Am]κάνει
Φραγκο[E]συριανή γλυ[Am]κιά

{verse: Verse}
[Am]Θα ''ρθω να σε ανταμώσω
κάτω στην ακρογια[E]λιά
Θα ήθε[Dm]λα να σε χο[Am]ρτάσω
όλο [E]χάδια [F]και φι[E]λιά
Θα ήθε[Dm]λα να σε χο[Am]ρτάσω
όλο [E]χάδια και φι[Am]λιά

{verse: Verse}
[Am]Θα σε πάρω να γυρίσω
Φοίνικα, Παρακο[E]πή
Γαλη[Dm]σσά και Nτελα[Am]γκράτσια
και ας [E]μου ''ρθει [F]συγκο[E]πή
Γαλη[Dm]σσά και Nτελα[Am]γκράτσια
και ας [E]μου ''ρθει συγκο[Am]πή

{verse: Verse}
[Am]Στο Πατέλι, στο Nιχώρι
φίνα στην Αληθι[E]νή
και στο [Dm]Πισκοπιό ρο[Am]μάντζα
γλυκιά μου [E]Φραγκο[F]συρια[E]νή
και στο [Dm]Πισκοπιό ρο[Am]μάντζα
γλυκιά μου [E]Φραγκοσυρια[Am]νή',NULL),
	 ('Αυγερινός',13,NULL,0,NULL,'2026-09-14 10:58:52','2026-09-28 07:53:38','{title: Αυγερινός}

{verse: Verse}
[Am]Με βρήκε ο αυγερινός
Σαν φύλλο κίτρινο στους δρόμους
Κλαίει στα μάτια μου ο θεός
Κι έχω τον πόνο σου στους ώμους

{verse: Chorus}
Δε με χω[Dm]ράει το κρε[Am]βάτι μου
Γιατί μου [Dm]λείπει η α[Am]γάπη μου
Δε με χω[G]ράει και ο ντου[Am]νιάς
Αφού ε[G]σύ δε [F]μ'' αγα[Am]πάς

{verse: Verse}
[Am]Τα σπίτια γύρω μου κλειστά
Και σφαλιστή κάθε ταβέρνα
Κι όπου γυρίσω με πατά
Της μαύρης μοίρας μου η φτέρνα

{verse: Chorus}
Δε με χω[Dm]ράει το κρε[Am]βάτι μου
Γιατί μου [Dm]λείπει η α[Am]γάπη μου
Δε με χω[G]ράει και ο ντου[Am]νιάς
Αφού ε[G]σύ δε [F]μ'' αγα[Am]πάς',NULL),
	 ('Το Άγαλμα',14,NULL,0,NULL,'2026-09-14 11:07:19','2026-09-28 07:53:46','{title: Το Άγαλμα}
{verse: Verse}
[Am]Χθες μεσάνυχτα και κάτι [G]κατηφόρι[Am]σα
[Am]στη μικρή την πλατεϊτσα [G]που σε γνώρι[C]σα
[F]Κάποιο άγαλμα που μ'' είδε, [G]με θυμήθη[Em]κε
[F]και τον πόνο [G]μου ν'' α[Am]κούσει [E]δεν αρνήθη[Am]κε 

{verse: Verse}
[Am]Και τού μίλησα για σένα [G]και για μένα[Am]νε
[Am]Και τα μάτια του βουρκώναν [G]κι όλο κλαίγα[Am]νε
[F]Τού ''πα για το φέρσιμό σου [G]και για τ'' άλλα [Em]σου
[F]τ'' ασυγχώρητα τα λάθη τα μεγάλα σου

{verse: Verse}
[Am]Κι ύστερα με πιάσαν Θέ μου [G]κάτι κλάματα
[Am]που με βρήκανε κουρέλι [G]τα χαράμα[Am]τα
[F]Με το άγαλμα ως το δρόμο [G]προχωρήσα[Em]με
[F]Μου εσκούπι[G]σε τα [Am]μάτια [E]και χωρίσα[Am]με',NULL),
	 ('Ένα βράδυ που βρεχε',9,NULL,0,NULL,'2026-09-14 11:14:59','2026-09-28 07:53:53','{title: Ένα βράδυ που βρεχε}
{verse: Verse}
[Am]Ένα βράδυ [E]που ''βρεχε [Dm]που ''βρεχε [Am]μονότονα
Έφυγες α[E]γάπη μου
[F]Ποιος σε πήρε [Dm]να ''ξερα
[G]Και να τον ε[C]σκότωνα
[Dm]Ένα βράδυ που ''βρεχε [E]που ''βρε χε μο[Am]νότονα

{verse: Verse}
[Am]Ένα βράδυ [E]που ''βρεχε [Dm]μέχρι το ξη[Am]μέρωμα
Έφυγες α[E]γάπη μου
[F]Αχ αυτός ο [Dm]άτιμος
[G]ήθελε μα[C]χαίρωμα
[Dm]Ένα βράδυ που ''βρεχε [E]μέχρι το ξη[Am]μέρωμα',NULL),
	 ('Πετροβολούσα τη ζωή',9,NULL,0,NULL,'2026-09-14 11:21:17','2026-09-28 07:54:05','{title: Πετροβολούσα τη ζωή}

{verse: Verse}
[Am]Εγώ από μι[G]κρό παι[Am]δί
πε[Dm]τροβο[Am]λούσα [E]τη ζω[Am]ή
[Am]κι όπου [Dm]αντάμωνα τον [Am]πόνο
[E]τον ε[Am]κέρναγα κρασί

{verse: Verse} 
[Em]Μα οι πέτρες όλες που ''ριξα
[A]απάνω μου όλες [Dm]πέφτουν
[Am]μετράω τα χτυ[E]πήματα
που τελειωμό δεν [Am]έχουν

{verse: Verse} 
[Am]Για της γυναίκας την καρδιά
έ[Dm]πεφτα [Am]μέσα [E]στη φω[Am]τιά
[Am]και της [Dm]μοίρας τα χα[Am]στούκια
[E]πετρο[Am]βόλαγα κι αυτά',NULL),
	 ('Σε μια στοίβα καλαμιές',15,NULL,0,NULL,'2026-09-14 11:27:59','2026-09-28 07:54:21','{title: Σε μια στοίβα καλαμιές}

{verse: Verse}
[Em]Σε μια στοίβα καλαμιές αποκοι[Dm]μήθη[Em]κα
[Em]κι έβλεπα από την αρχή [Dm]πως ξαναγεννήθη[Em]κα
[Am]Πως ξαναγεννήθη[Em]κα

{verse: Chorus}
[C]Έβλεπα φωτιές στο δρόμο, [Dm]έβλεπα παντού [Em]φωτιές
[C]Πως καιγόταν τα κορμιά μας, [Dm]ζούσαν μόνο οι [Em]ψυχές
[Em]και δεν είχαν ούτε πόνο, [Dm]ούτε και λαβω[Em]ματιές
[Em]Να ''μενα στον άλλο κόσμο, [Dm]να μην ξύπναγα [Em]ποτές

{verse: Verse}
[Em]Σε μια στοίβα καλαμιές αποκοι[Dm]μήθη[Em]κα
[Em]Σα με ξύπνησε η βροχή, [Dm]αχ πόσο λυπήθη[Em]κα
[Am]Αχ πόσο λυπήθη[Em]κα

{verse: Chorus}
[C]Έβλεπα φωτιές στο δρόμο, [Dm]έβλεπα παντού [Em]φωτιές
[C]Πως καιγόταν τα κορμιά μας, [Dm]ζούσαν μόνο οι [Em]ψυχές
[Em]και δεν είχαν ούτε πόνο, [Dm]ούτε και λαβω[Em]ματιές
[Em]Να ''μενα στον άλλο κόσμο, [Dm]να μην ξύπναγα [Em]ποτές',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Πες μου που πουλάν καρδιές',15,NULL,0,NULL,'2026-09-14 11:34:03','2026-09-28 07:54:44','{title: Πες μου που πουλάν καρδιές}

{verse: Verse}
[Em]Πες μου πού πουλάν κα[Am]ρδιές, να σου πάρω [Em]μια
[Em]Πες μου πού πουλάν [Am]χαρές, [Dm]να σου πάρω [Em]δυο
[Em]Πες μου πού πουλάν ψυ[Am]χές, να σου πάρω [Em]μια
[Em]Πού πουλάν αη[Am]τόφτερα[Dm], να σου πάρω [Em]δυο

{verse: Chorus}
[Em]Θέλω [Dm]να ''χεις δυο κα[Em]ρδιές
[C]ν'' αγα-, ν'' α[Dm]γαπάς διπλά [Em]τον κόσμο
Θέλω να ''χεις [G]δυο ψυχές, [Dm]γιομάτες να ''[Em]ναι δυόσμο
[Dm]Θέλω να ''σαι αε[Em]τός
[Dm]Θέλω να ''σαι αε[Em]τός

{verse: Verse}
[Em]Πες μου πού πουλάν κα[Am]ρδιές, να σου πάρω [Em]μια
[Em]Πες μου πού πουλάν [Am]ψυχές, [Dm]να σου πάρω [Em]δυο
[Em]Πού πουλάν [G]τις Κυριακές, [Dm]τις γιορτές, τις [Em]σχόλες
[Em]Πες μου πού που[Am]λάν χαρές[Dm], να στις πάρω [Em]όλες

{verse: Chorus}
[Em]Θέλω [Dm]να ''χεις δυο κα[Em]ρδιές
[C]ν'' αγα-, ν'' α[Dm]γαπάς διπλά [Em]τον κόσμο
Θέλω να ''χεις [G]δυο ψυχές, [Dm]γιομάτες να ''[Em]ναι δυόσμο
[Dm]Θέλω να ''σαι αε[Em]τός
[Dm]Θέλω να ''σαι αε[Em]τός',NULL),
	 ('Μυστικέ μου έρωτα',16,NULL,0,NULL,'2026-09-14 11:39:56','2026-09-28 07:55:37','{title: Μυστικέ μου έρωτα}
{verse: Intro}
[C] [Em] [F] [Em] [C] [Em] [F] [Dm] [F] [Em]

{verse: Verse}
Μυ[C]στικέ μου [Em]έρωτα αχ έρωτα κρυφέ
ότι [C]τώρα [Em]ένιωσα δεν ένιωσα ποτέ
Μυστι[Am]κέ μου [Em]έρωτα αχ [Dm]έρωτα κρυ[Em]φέ

{verse: Chorus}
Μια φω[Em]τιά μου καίει τα [G]στήθια μια φω[Em]τιά
την α[C]λήθεια δεν τη [G]λέω πουθε[Em]νά
και πο[Dm]νώ και πο[Em]νώ
Μυστι[Am]κέ μου [Em]έρωτα αχ [Em]έρωτα
σ'' αγα[Em]πώ, [Dm]σ'' α [F]γα[Em]πώ

{verse: Verse}
Μυ[C]στικέ μου [Em]έρωτα και πάθος μου κρυφό
μόνο [C]που σε [Em]σκέφτομαι πεθαίνω και ριγώ
μυστι[Am]κέ μου [Em]έρωτα αχ [Dm]έρωτα πο[Em]νώ

{verse: Chorus}
Μια φω[Em]τιά μου καίει τα [G]στήθια μια φω[Em]τιά
την α[C]λήθεια δεν τη [G]λέω πουθε[Em]νά
και πο[Dm]νώ και πο[Em]νώ
Μυστι[Am]κέ μου [Em]έρωτα αχ [Em]έρωτα
σ'' αγα[Em]πώ, [Dm]σ'' α [F]γα[Em]πώ',NULL),
	 ('Δεν έχει δρόμο να διαβώ',17,NULL,0,NULL,'2026-09-14 12:02:25','2026-09-28 07:55:46','{title: Δεν έχει δρόμο να διαβώ}

{verse: Verse}
[Am]Δεν έχει δρόμο να [Dm]διαβώ
[E]σοκάκι να περά[Am]σω
[Am]γωνιά να μη σε θυμη[Dm]θώ -ώ-ώ
ημέρα [E]να-α -α μην κλά[Am]ψω

{verse: Verse}
[Am]Δεν έχει μέρα να [Dm]μη πω
[E]βραδιά να μη μιλή[Am]σω
[Am]νύχτα να μη σ'' αναζη[Dm]τώ
βαθιά [E]να σε φιλή[Am]σω

{verse: Verse}
[Am]Όλες οι ώρες γί[Dm]νανε
[E]φωνή που σε φωνά[Am]ζουν
[Am]Κι οι νύχτες γίναν δάκρυ[Dm]α
που στην [E]καρδιά μου στά[Am]ζουν',NULL),
	 ('Τι σουκανα και με εγκατέλειψες',17,NULL,0,NULL,'2026-09-14 12:09:00','2026-09-28 07:56:06','{title: Τι σουκανα και με εγκατέλειψες}
{verse: Intro}
[Am] [B] [Dm] [E] [Am] [Am] [Dm] [E] [Am]

{verse: Verse}
[Am]Έφυγες και κλαιν τα νυχτο[Dm]πούλια
Στάλα-στάλα [Am]πέφτουνε τα [E]δάκρυα βρο[Am]χή
[Am]Μαράθηκαν στη γλάστρα τα ζου[Dm]μπούλια
μαύρη νύχτα [Am]μου σκεπάζει [E]τώρα την ψυ[Am]χή

{verse: Chorus}
[C]Τι σου ''κα[F]να και [G]μ'' εγκατέλει[C]ψες
[F]Γύρισε [G]πίσω, για[F]τί μου έλει[C]ψες
[C]Τι σου ''κα[F]να και [G]μ'' εγκατέλει[C]ψες
[Dm]Γύρισε [Am]πίσω, για[E]τί μου έλει[Am]ψες

{verse: Verse}
[Am]Σ'' έχασα και χάθηκε το [Dm]φως μου
και σ'' ατέλειω[Am]τα σκοτάδια [E]πάντα περπα[Am]τώ
[Am]Μου ''κλεισες το σπίτι το φτω[Dm]χό μου
κι όποιον άνθρω[Am]πο θα βρω για [E]σένα τον ρω[Am]τώ

{verse: Chorus}
[C]Τι σου ''κα[F]να και [G]μ'' εγκατέλει[C]ψες
[F]Γύρισε [G]πίσω, για[F]τί μου έλει[C]ψες
[C]Τι σου ''κα[F]να και [G]μ'' εγκατέλει[C]ψες
[Dm]Γύρισε [Am]πίσω, για[E]τί μου έλει[Am]ψες',NULL),
	 ('Ροζ',18,NULL,0,NULL,'2026-09-14 12:17:21','2026-09-28 07:56:26','{title: Ροζ}

{verse: Verse}
[E]Πάντα ονειρε[Am]υόμουνα [E]έν'' ανοικτό τζι[Am]πάκι
[C]Mόνο αυτό μάς έλειπε, [F]τώρα τι να σου [C]πω
[Dm]Πάντα γκρινιάρα [Am]ήσουνα [E]κι αγύριστο κε[Am]φάλι
[Dm]Κι εσύ είχες την [Am]απαίτηση [E]να σε υπηρε[Am]τώ

{verse: Verse}
[E]Ήθελα στη ντου[Am]λάπα μου να [E]υπάρχει μία [Am]τάξη
[C]Ήθελα στη ντουλάπα μου να [F]γίνεται χα[C]μός
[Dm]Παλιές φωτο[Am]γραφίες σου [E]θα ''θελα να ''χες [Am]κάψει
[Dm]Μπροστά στους ξένους [Am]θα ''θελα [E]να ''σαι πιο σοβα[Am]ρός

{verse: Chorus}
[Am]Πόσο άλλαξες, πόσο [G]άλλαξα
[E]Τα όνειρά μου [Am]κόκκινα, [G]τα όνειρά μου [C]άσπρα
[Dm]ρούχα μαζί που [Am]πλύθηκαν [E]κι έχουνε γίνει [Am]ροζ
[Dm]ρούχα μαζί που [Am]πλύθηκαν [E]κι έχουνε γίνει [Am]ροζ

{verse: Verse}
[E]Ήθελα στα γε[Am]νέθλια να [E]μου ''φερνες λου[Am]λούδια
[C]Ήθελα στα γενέθλια [F]μόνος μου να τα [C]πιω
[Dm]Να με γλυκονα[Am]νούριζες [E]τα βράδια με τρα[Am]γούδια
[Dm]Άσε με, πήγε [Am]τέσσερις, [E]θέλω να κοιμη[Am]θώ

{verse: Verse}
[E]Kοίτα καλέ πού [Am]έμπλεξα, θα [E]σκάσω απ'' το κα[Am]κό μου
[C]Πάνω που ετοιμα[F]ζόμουνα το ίδιο να σου [C]πω
[Dm]Βρε, αν δε σ'' ερωτε[Am]υόμουνα, [E]θα ''κανα το δι[Am]κό μου
[Dm]Εγώ να δεις τι [Am]θα ''κανα, μα [E]έλα που σ'' αγα[Am]πώ

{verse: Chorus}
[Am]Πόσο άλλαξες, πόσο [G]άλλαξα
[E]Τα όνειρά μου [Am]κόκκινα, [G]τα όνειρά μου [C]άσπρα
[Dm]ρούχα μαζί που [Am]πλύθηκαν [E]κι έχουνε γίνει [Am]ροζ
[Dm]ρούχα μαζί που [Am]πλύθηκαν [E]κι έχουνε γίνει [Am]ροζ',NULL),
	 ('Νατανε το 21',11,NULL,0,NULL,'2026-09-14 12:27:09','2026-09-28 07:56:54','{title: Νατανε το 21}
{verse: Verse}
[Am]Μου ξανάρχονται ένα-ένα χρόνια δοξα[E]σμένα
[F]Να ''τανε το εικοσι[Dm]ένα να ''ρθει μια στι[E]γμή
[Am]Να περνάω καβαλάρης στο πλατύ τ'' α[E]λώνι
[F]και με τον Κολοκο[Dm]τρώνη να ''πινα κρα[Am]σί

{verse: Verse}
Να πολε[Dm]μάω τις μέρες στα [E]κάστρα
και το σπα[Dm]θί μου να πιάνει φω[Am]τιά
και να κρα[Dm]τάω τις νύχτες με τ'' [E]άστρα
μια ομορ[F]φούλα αγκα[E]λιά

{verse: Chorus}
[Am]Μου ξανάρχονται ένα-ένα χρόνια δοξα[E]σμένα
[F]Να ''τανε το εικοσι[Dm]ένα να ''ρθει μια βρα[E]διά

{verse: Verse}
[Am]Πρώτος το χορό να σέρνω στου Μωριά τις [E]στράτες
[F]και ξωπίσω μου μα[Dm]νιάτες και οι ψαρια[E]νοί
[Am]Κι όταν λαβωμένος γέρνω κάτω απ'' τους μπα[E]ξέδες
[F]να με ραίνουν μενε[Dm]ξέδες χέρια κι ουρα[Am]νοί

{verse: Verse}
Να πολε[Dm]μάω τις μέρες στα [E]κάστρα
και το σπα[Dm]θί μου να πιάνει φω[Am]τιά
και να κρα[Dm]τάω τις νύχτες με τ'' [E]άστρα
μια ομορ[F]φούλα αγκα[E]λιά

{verse: Chorus}
[Am]Μου ξανάρχονται ένα-ένα χρόνια δοξα[E]σμένα
[F]Να ''τανε το εικοσι[Dm]ένα να ''ρθει μια βρα[E]διά',NULL),
	 ('Ξημερώνει Κυριακή',14,NULL,0,NULL,'2026-09-14 12:34:18','2026-09-28 07:57:08','{title: Ξημερώνει Κυριακή}

{verse: Verse}
[Am]Ο παλιός φω[Dm]νόγρα[Am]φος [Dm]πάνω στο τρα[Am]πέζι
[Dm]άρχισε να [Am]παίζει [E]μες στη σιγα[Am]λιά
[Am]Η καρδιά σου [Dm]έλιω[Am]σε [Dm]κι έγιν'' ένα [Am]δάκρυ
[G]στων ματιών την [C]άκρη [Dm]σα ροδοστα[C]λιά

{verse: Chorus}
[F]Ξημερώνει, ξημερώνει Κυρια[C]κή, μη μου λυπάσαι
[F]Είναι όμορφη, είναι όμορφη η ζω[C]ή, [Dm]να το θυ[Am]μάσαι
[Dm]Μη μου λυ[F]πάσαι, [G]να το θυ[Am]μάσαι

{verse: Verse}
[Am]Ο παλιός φω[Dm]νόγρα[Am]φος [Dm]πάνω στο τρα[Am]πέζι
[Dm]έπαψε να [Am]παίζει [E]μέσα στη νυ[Am]χτιά
[Am]Το τραγούδι [Dm]τέλειω[Am]σε, [Dm]πάει λυπη[Am]μένη
[G]σα ναυαγι[C]σμένη [Dm]στη θολή μα[C]τιά

{verse: Chorus}
[F]Ξημερώνει, ξημερώνει Κυρια[C]κή, μη μου λυπάσαι
[F]Είναι όμορφη, είναι όμορφη η ζω[C]ή, [Dm]να το θυ[Am]μάσαι
[Dm]Μη μου λυ[F]πάσαι, [G]να το θυ[Am]μάσαι',NULL),
	 ('Σταμάτησε του ρολογιού τους δεικτες',19,NULL,0,NULL,'2026-09-14 12:41:45','2026-09-28 07:57:16','{title: Σταμάτησε του ρολογιού τους δείκτες}

{verse: Verse}
[Am]Σταμάτη[Em]σε [Dm]του ρολογιού τους [Em]δείχτες
[Am]τώρα που είμαστ'' αγκα[Em]λιά
[Am]Πάρε τις [Em]πίκρες, τις [Am]πίκρες μου και [Dm]ρίχ'' τες
[Dm]στο βράχο του Καβομα[C]λιά, [Am]καλέ [Em]μου
[Dm]στο βράχο [Em]του Καβομα[Am]λιά

{verse: Verse}
[Am]Σταμάτη[Em]σε του [Dm]ρολογιού τους [Em]δείχτες
[Am]τώρα που είμαστ'' αγκα[Em]λιά
[Am]και τις βα[Em]θιές λα[Am]βωματιές σου [Dm]δείχ'' τες
[Dm]να σ'' τις γιατρέψω με φι[C]λιά, [Am]καλέ [Em]μου
[Dm]να σ'' τις για[Em]τρέψω με φι[Am]λιά

{verse: Verse}
[Am]Σταμάτη[Em]σε του [Dm]ρολογιού τους [Em]δείχτες
[Am]και τίποτα να μη μου [Em]πεις
[Am]Πέρασα [Em]χίλιες, [Am]χίλιες άδειες [Dm]νύχτες
[Dm]νύχτες που πρόσμενα να ''[C]ρθεις, [Am]καλέ [Em]μου
[Dm]νύχτες που [Em]πρόσμενα να ''[Am]ρθεις',NULL),
	 ('Αν κάνω άτακτη ζωή',7,NULL,0,NULL,'2026-09-14 12:50:44','2026-09-28 07:57:40','{title: Αν κάνω άτακτη ζωή}
{verse: Verse}
[Em]Αν κάνω άτακτη ζωή, δεν θα σε βάλω για κριτή
γιατί δεν [Am]έχεις το δικαίωμα [Em]αυτό
Ήμουν στην [Dm]άκρη του γκρε[G]μού, μα συ ξε[F]νύχταγες α[Em]λλού
όταν ζη[Am]τούσα κάποιο [F]χέρι να πια[Em]στώ

{verse: Chorus}
Αν κάνω [G]άτακτη ζωή, δικός μου εί[F]ναι λογαρια[Em]σμός
Πάψε να με κατηγορείς, για μένα [Am]άξιος κρι[Em]τής
είναι μονάχα ο Θεός
Αν κάνω [G]άτακτη ζωή, δικός μου [F]είναι λογαρια[Em]σμός

{verse: Verse}
[Em]Πέρασε βλέπεις ο καιρός, που ''σουν ο άντρας ο σκληρός
και με ξε[Am]χνούσες πότε εδώ και πότε ε[Em]κεί
Έκανα [Dm]πέτρα την κα[G]ρδιά, κι όπου βρε[F]θώ κτίζω φω[Em]λιά
κι αυτό το [Am]λες πως είναι [F]άτακτη ζω[Em]ή

{verse: Chorus}
Αν κάνω [G]άτακτη ζωή, δικός μου εί[F]ναι λογαρια[Em]σμός
Πάψε να με κατηγορείς, για μένα [Am]άξιος κρι[Em]τής
είναι μονάχα ο Θεός
Αν κάνω [G]άτακτη ζωή, δικός μου [F]είναι λογαρια[Em]σμός',NULL),
	 ('Δεν ξέρω πόσο σαγαπώ',20,NULL,0,NULL,'2026-09-14 12:59:09','2026-10-12 06:48:55','{title: Δεν ξέρω πόσο σαγαπώ}

{verse: Verse}
[Am]Δεν ξέρω πόσο σ'' αγαπώ, δεν ξέρω [A]πόσο σ'' α[Dm]γαπώ
Μέτρο δεν [E]έχει η αγά[Am]πη
[Am]Κι ειν'' απ'' τον ήλιο πιο ψηλά, κι είν'' απ'' τον [A]ήλιο πιο [Dm]ψηλά
Και δεν την [E]φτάνει μά[Am]τι

{verse: Chorus}
[C]Ήταν μια σπίθα στην αρ[Dm]χή και μιας βροχής ψιχά[E]λα
[Am]Κι έγινε η σπίθα πυρκαγιά, κι έγινε η [A]σπίθα πυρκα[Dm]γιά
Και πέλα[E]γος η στά[Am]λα

{verse: Verse}
[Am]Η αγάπη που μας έδεσε, η αγάπη [A]που μας έδε[Dm]σε
Πόνο δε [E]θα γνωρί[Am]σει
[Am]Είμαστε δυο σταλαγματιές, είμαστε [A]δυο σταλαγμα[Dm]τιές
Από την [E]ίδια βρύ[Am]ση

{verse: Chorus}
[C]Ήταν μια σπίθα στην αρ[Dm]χή και μιας βροχής ψιχά[E]λα
[Am]Κι έγινε η σπίθα πυρκαγιά, κι έγινε η [A]σπίθα πυρκα[Dm]γιά
Και πέλα[E]γος η στά[Am]λα',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Perfect',21,NULL,0,NULL,'2026-09-15 06:52:32','2026-10-05 06:51:49','{title: Perfect}
{verse: Intro}
[D] [D]

{verse: Verse}
I found a [G]love, for [Em]me
Darling just [C]dive right in, and follow my [D]lead
Well I found a [G]girl beauti[Em]ful and sweet
Well I never [C]knew you were the someone waiting for [D]me

{verse: Verse}
Cause we were just kids when we
[G]Fell in love, not knowing [Em]what it was
I will not [C]give you  up this [G]time[D]
But darling just [G]kiss me slow, your heart is [Em]all I own
And in your [C]eyes you’re holding [D]mine

{verse: Chorus}
Baby [Em]I’m [C]dancing in the [G]dark, with [D]you between my [Em]arms
[C]Barefoot on the [G]grass, [D]listening to our [Em]favorite song
When I [C]saw you in that [G]dress, looking so [D]beautiful
I [D]don''t [C]deserve this, darling [G]you look [D]perfect to[G]night

{verse: Verse}
Well I found a [G]woman, stronger than [Em]anyone I know
She shares my [C]dreams, I hope that someday I’ll share her [D]home
I found a [G]love, to carry [Em]more than just my secrets
To carry [C]love, to carry children of our [D]own

{verse: Verse}
We are still kids, but we’re [G]so in love, fighting a[Em]gainst all odds
I know we’ll [C]be alright this [G]time[D]
Darling just [G]hold my hand, be my girl, [Em]I’ll be your man
I see my [C]future in your [D]eyes

{verse: Chorus}
Baby [Em]I’m [C]dancing in the [G]dark, with [D]you between my [Em]arms
[C]Barefoot on the [G]grass, [D]listening to our [Em]favorite song
When I [C]saw you in that [G]dress, looking so [D]beautiful
I [D]don''t [C]deserve this, darling [G]you look [D]perfect to[G]night',NULL),
	 ('Simple Man',22,NULL,0,NULL,'2026-09-15 07:02:43','2026-09-28 07:09:18','{title: Simple Man}
{verse: Verse}
Well, Mama [C]told me, [G] when I was [Am]young.
Come sit be[C]side me, [G] my [Am]only son.
And listen [C]closely, [G] to what [Am]I say.
And if you [C]do this, [G]it''ll help you, some [Am]sunny day.
Oh yeah!
  
{verse: Verse}
Oh, take your [C]time, [G] don''t [Am]live too fast.
Troubles will [C]come, [G] and they [Am]will pass.
Go find a [C]woman, [G] and you''ll [Am]find love.
And don''t for[C]get son, [G]there is someone up [Am]above.
 
{verse: Chorus}
And be a [C]simple [G] kind of [Am]man.
Oh, be [C]something,  you [G]love and under[Am]stand.
Baby, be a [C]simple [G] kind of [Am]man.
Oh, won''t you [C]do this for [G]me son, if you [Am]can?
 
{verse: Verse}
Forget your [C]lust, [G] for rich [Am]man''s gold,
All that you [C]need, [G] is in your [Am]soul.
And you can [C]do this, [G]oh baby,  if you [Am]try.
All that I [C]want for [G]you my son, is to be [Am]satisfied.
  
{verse: Chorus}
And be a [C]simple [G] kind of [Am]man.
Oh, be [C]something,  you [G]love and under[Am]stand.
Baby, be a [C]simple [G] kind of [Am]man.
Oh, won''t you [C]do this for [G]me son, if you [Am]can?
Oh yes, I will.
 
{verse: Verse}
Boy, don''t you [C]worry, [G] you''ll find [Am]yourself.
Follow your [C]heart, [G] and nothing [Am]else.
You can [C]do this, [G] oh baby,  if you [Am]try.
All that I [C]want for you my [G]son, is to be [Am]satisfied.

{verse: Chorus}
And be a [C]simple [G] kind of [Am]man.
Oh, be [C]something,  you [G]love and under[Am]stand.
Baby, be a [C]simple [G] kind of [Am]man.
Oh, won''t you [C]do this for [G]me son, if you [Am]can?',NULL),
	 ('Have you ever seen the rain',23,NULL,0,NULL,'2026-09-15 07:08:56','2026-10-05 12:11:13','{title: Have you ever seen the rain}
{verse: Intro}
[Am] [F] [C] [G] [C]

{verse: Verse}
[C]Someone told me long ago
There''s a calm before the storm, I [G]know
It''s been coming for [C]some time
 
[C]When it''s over, so they say
It''ll rain a sunny day, I [G]know
Shining down like [C]water
 
{verse: Chorus}
[F]I wanna [G]know
Have you [C]ever seen the [Am]rain
[F]I wanna [G]know
Have you [C]ever seen the [Am]rain
[F]Coming [G]down on a sunny [C]day
 
{verse: Verse}
[C]Yesterday and days before
Sun is cold and rain is hard, I [G]know
Been that way for [C]all my time

[C]''Til forever on it goes
Through the circle fast and slow, I [G]know
It can''t stop, I [C]wonder
 
{verse: Chorus}
[F]I wanna [G]know
Have you [C]ever seen the [Am]rain
[F]I wanna [G]know
Have you [C]ever seen the [Am]rain
[F]Coming [G]down on a sunny [C]day
 
{verse: Chorus}
[F]I wanna [G]know
Have you [C]ever seen the [Am]rain
[F]I wanna [G]know
Have you [C]ever seen the [Am]rain
[F]Coming [G]down on a sunny [C]day','D-DU-UDU'),
	 ('Stand by me',24,NULL,0,NULL,'2026-09-15 07:30:22','2026-10-05 07:05:07','{title: Stand by me}
{verse: Intro}
[G] [Em] [C] [G] [G] [Em] [C] [G]

{verse: Verse}
When the [G]night has come [Em]
And the land is dark
And the [C]moon is the [D]only light we''ll [G]see
No I won''t be afraid, no I [Em]won''t be afraid
Just as [C]long as you [D]stand, stand [G]by me

{verse: Verse}
And darlin'', darlin'', stand by me, oh now [Em]stand by me
[C]Stand by me, [D]stand by me[G]
 
{verse: Chorus}
If the sky that we look upon [Em]
Should tumble and fall
And the [C]mountains should [D]crumble to the [G]sea
 
{verse: Verse}
I won''t [G]cry, I won''t cry, no I [Em]won''t shed a tear
Just as [C]long as you [D]stand, stand by [G]me
 
{verse: Chorus}
And darlin'', darlin'', stand by me, oh now [Em]stand by me
[C]Stand by me, [D]stand by me[G]
 
{verse: Verse}
Whenever you''re in trouble won''t you [G]stand by me, oh now now [Em]stand by me
Oh [C]stand by me, [D]stand by me, stand by [G]me
 
{verse: Chorus}
And darlin'', darlin'', stand by me, oh now [Em]stand by me
[C]Stand by me, [D]stand by me[G]','D-DU-UDU'),
	 ('Θα εκραγώ',41,NULL,0,NULL,'2026-09-16 13:19:56','2026-10-07 09:16:19','{title: Θα εκραγώ}

{verse: Verse}
[Am]Σε ποιον να μι[G]λήσω, αλήθεια να [F]πω
τα μάτια να [Am]κλείσω, να ονειρευ[E]τώ.

{verse: Verse}
[Am]Ανώνυμο [G]θύμα κρυφής μηχα[F]νής
εκπέμπω ένα [Am]σήμα, μ'' ακούει κα[E]νείς;

{verse: Chorus}
Έχω [Am]τόσο κουραστεί να μοι[G]ράζομαι
και μετά να την πληρώνω ε[Am]γώ
σ'' ένα [Am]κόσμο εχθρικό κομμα[G]τιάζομαι
για τους άλλους πάντα αιμορρα[F]γώ[G], θα εκρα[Am]γώ.

{verse: Verse}
[Am]Σε κάθε μου [G]βήμα και ένα για[F]τί
κακότεχνο [Am]ποίημα αυτή η ζω[E]ή.

{verse: Verse}
[Am]Πως να σ'' αγκα[G]λιάσω χωρίς να [F]σκεφτώ
πως κάτι θα [Am]χάσω πως θα προδο[E]θώ.

{verse: Chorus}
Έχω [Am]τόσο κουραστεί να μοι[G]ράζομαι
και μετά να την πληρώνω ε[Am]γώ
σ'' ένα [Am]κόσμο εχθρικό κομμα[G]τιάζομαι
για τους άλλους πάντα αιμορρα[F]γώ[G], θα εκρα[Am]γώ.','D-DU-UDU'),
	 ('Wicked Game',25,NULL,0,NULL,'2026-09-15 07:38:06','2026-10-05 07:04:30','{title: Wicked Game}
{verse: Intro}
[Am] [G] [D]

{verse: Verse}
[Am]The world was on fire 
[G]No one could save me but [D]you. 
[Am]Strange what desire will [G]make foolish people [D]do 
[Am]I never dreamed that [G]I''d meet somebody [D]like you 
And [Am]I never dreamed that [G]I''d lose somebody [D]like you 
 
{verse: Chorus}
No, [Am]I   [G]don''t want to fall in [D]love 
No, [Am]I   [G]don''t want to fall in [D]love
With [Am]you 

{verse: Instrumental}
[Am] [G] [D]

{verse: Verse}
[Am]What a wicked [G]game you play 
[D]To make me feel this way 
[Am]What a wicked [G]thing to do 
[D]To let me dream of you 

{verse: Verse}
[Am]What a wicked [G]thing to say 
[D]You never felt this way 
[Am]What a wicked [G]thing to do 
[D]To make me dream of you 

{verse: Chorus}
No, [Am]I   [G]don''t want to fall in [D]love 
No, [Am]I   [G]don''t want to fall in [D]love
With [Am]you 

{verse: Instrumental}
[Am] [G] [D]

{verse: Verse}
[Am]The world was on fire 
[G]No one could save me but [D]you. 
[Am]Strange what desire will [G]make foolish people [D]do 
[Am]I never dreamed that [G]I''d love somebody like [D]you 
And [Am]I never dreamed that [G]I''d lose somebody [D]like you 

{verse: Chorus}
No, [Am]I   [G]don''t want to fall in [D]love 
No, [Am]I   [G]don''t want to fall in [D]love
With [Am]you','D-DU-UDU'),
	 ('Friday I am in love',26,NULL,0,NULL,'2026-09-15 08:01:58','2026-09-30 14:23:37','{title: Friday I am in love}
{verse: Intro}
[D] [G] [D] [A] [Bm] [G] [D] [A]

{verse: Verse}
[D]I don''t care if [G]Monday''s blue
[D]Tuesday''s grey and [A]Wednesday too
[Bm]Thursday I don''t [G]care about you
It''s [D]Friday I''m in [A]love
 
{verse: Verse}
[D]Monday you can [G]fall apart
[D]Tuesday Wednesday [A]break my heart
[Bm]Thursday doesn''t [G]even start
It''s [D]Friday I''m in [A]love
 
{verse: Chorus}
[G]Saturday [A]wait
And [Bm]Sunday always [G]comes too late
But [D]Friday never [A]hesitate...
 
{verse: Verse}
[D]I don''t care if [G]Mondays black
[D]Tuesday Wednesday [A]heart attack
[Bm]Thursday never [G]looking back
It''s [D]Friday I''m in [A]love 
 
[D]Monday you can [G]hold your head
[D]Tuesday Wednesday [A]stay in bed
Or [Bm]Thursday watch the [G]walls instead
It''s [D]Friday I''m in [A]love 

{verse: Chorus}
[G]Saturday [A]wait
And [Bm]Sunday always [G]comes too late
But [D]Friday never [A]hesitate... [Bm]
 
{verse: Bridge} 
Dressed up to the [G]eyes, it''s a wonderful surprise [D]
To see your [A]shoes and your spirits [Bm]rise
Throwing out your [G]frown and just smiling at the [D]sound
And as sleek as a [A]shriek spinning round and [Bm]round
Always take a big [G]bite, it''s such a gorgeous [D]sight
To see you [A]eat in the middle of the [Bm]night
You can never get [G]enough, enough of this [D]stuff
It''s Friday I''m in [A]love
 
{verse: Verse}
[D]I don''t care if [G]Monday''s blue
[D]Tuesday''s grey and [A]Wednesday too
[Bm]Thursday I don''t [G]care about you
It''s [D]Friday I''m in [A]love 
 
{verse: Verse}
[D]Monday you can [G]fall apart
[D]Tuesday Wednesday [A]break my heart
[Bm]Thursday doesn''t [G]even start
It''s [D]Friday I''m in [A]love ',NULL),
	 ('Linger',27,NULL,0,NULL,'2026-09-15 08:12:19','2026-09-28 07:12:09','{title: Linger}
{verse: Intro}
[D] [A] [C] [G]
 
{verse: Verse}
If [D]you, if you could return, don''t let it [A]burn, don''t let it fade.
I''m sure I''m not being [C]rude, but it''s just your attitude,
It''s tearing me [G]apart, it''s ruining everything.
I [D]swore, I swore I would be true, and honey, so did [A]you.
So why were you holding her [C]hand? Is that the way we stand?
Were you lying all the [G]time? Was it just a game to you?
 
{verse: Chorus}
But I''m in so [D]deep, you know I''m such a [A]fool for you.
You got me wrapped around your [C]finger, ah, ha, ha.
Do you have to let it [G]linger? Do you have to, do you have to,
Do you have to let it [D]linger?
 
{verse: Refrain}
Oh, I [A]thought the world of you, I thought [C]nothing could go wrong,
But I was [G]wrong, I was wrong.
 
{verse: Verse}
If [D]you, if you could get by, trying not to [A]lie,
Things wouldn''t be so [C]confused and I wouldn''t feel so used,
But you always really [G]knew, I just wanna be with you.
 
{verse: Chorus}
And I''m in so [D]deep, you know I''m such a [A]fool for you,
You got me wrapped around your [C]finger, ah, ha, ha.
Do you have to let it [G]linger? Do you have to, do you have to,
Do you have to let it [D]linger?

And I''m in so [D]deep, you know I''m such a [A]fool for you,
You got me wrapped around your [C]finger, ah, ha, ha.
Do you have to let it [G]linger? Do you have to, do you have to,
Do you have to let it [D]linger?',NULL),
	 ('Nights in white satin',28,NULL,0,NULL,'2026-09-15 08:21:05','2026-10-16 10:41:20','{title: Nights in white satin}
{verse: Intro}
[Em] [D]

{verse: Verse} 
[Em]Nights in white [D]satin, [Em]never reaching the [D]end
[C]Letters I''ve [G]written, [F]never meaning to [Em]send
[Em]Beauty I''d [D]always missed, [Em]with these eyes [D]before
[C]Just what the [G]truth is, [F]I can''t say any[Em]more

{verse: Chorus}
Cause I [A]love you, yes I [C]love you
Ohhh how I [Em]love you [D] [Em] [D]

{verse: Verse} 
[Em]Gazing at [D]people, [Em]some hand in [D]hand
[C]Just what I''m [G]going through, [F]they can''t under[Em]stand
[Em]Some try to [D]tell me, [Em]thoughts they cannot [D]defend
[C]Just what you [G]want to be, [F]you''ll be in the [Em]end

{verse: Chorus}
Cause I [A]love you, yes I [C]love you
Ohhh how I [Em]love you [D] [Em] [D]
Cause I [A]love you, yes I [C]love you
Ohhh how I [Em]love you [D] [Em] [D]',NULL),
	 ('Wonderful tonight',29,NULL,0,NULL,'2026-09-15 08:32:04','2026-10-16 10:41:15','{title: Wonderful tonight}
{verse: Intro}
[G] [D] [C] [D]
 
{verse: Verse}
[G]It''s late in the [D]evening
[C]She''s wonderin'' what [D]clothes to wear
[G]She puts on her [D]make-up
[C]And brushes her [D]long blonde hair
 
{verse: Refrain}
[C]And then she [D]asks me, "Do [G]I look [Em]alright?"
And I say, [C]"Yes, you look [D]wonderful to[G]night"
 
{verse: Interlude}
[G] [D] [C] [D]
 
{verse: Verse}
[G]We go to a [D]party, [C]and everyone turns to [D]see
[G]This beautiful la[D]dy, [C]who''s walking a[D]round with me
 
{verse: Refrain}
[C]And then she [D]asks me, "Do you [G]feel al[Em]right?"
And I say, "[C]Yes, I feel [D]wonderful to[G]night"
 
{verse: Bridge}
I feel [C]wonderful be[D]cause I see the [G]love
light in your [Em]eyes
And the [C]wonder of it [D]all, is that you [C]just
don''t rea[D]lise how much I [G]love you

{verse: Interlude}
[G] [D] [C] [D]
 
{verse: Verse}
[G]It''s time to go [D]home now, [C]and I''ve got an [D]aching head
[G]So I give her the [D]car keys, [C]and she helps me [D]to bed

{verse: Refrain}
[C]And then I tell [D]her, as I [G]turn out the [Em]light
I say, "My [C]darling, you are [D]wonderful [G]tonight',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Wish you were here',30,NULL,0,NULL,'2026-09-15 08:45:59','2026-09-28 07:13:32','{title: Wish you were here}
{verse: Intro}
[Em] [G] [Em] [A] [G]

[C]So, so you think you can [D]tell,
Heaven from [Am]Hell, blue skies from [G]pain.
Can you tell a green [D]field from a cold steel [C]rail, a smile from a [Am]veil,
Do you think you can [G]tell?
 
{verse: Verse}
Did they get you to [C]trade your heroes for [D]ghosts,
Hot ashes for [Am]trees, hot air for [G]a cool breeze, cold comfort [D]for change,
And did you ex[C]change a walk on part in the [Am]war for a lead role in a [G]cage?
 
{verse: Instrumental}
[Em] [G] [Em] [G] [Em] [A] [Em] [A] [G]
 
{verse: Verse}
[C]How I wish, how I wish you were [D]here.
We''re just [Am]two lost souls swimming in a fish bowl, year after [G]year,
[D]Running over the same old ground. [C]What have we found?
The same old [Am]fears. Wish you were [G]here!
 
{verse: Instrumental}
[Em] [G] [Em] [G] [Em] [A] [Em] [A] [G]',NULL),
	 ('Whats Up',31,NULL,0,NULL,'2026-09-15 09:33:07','2026-10-18 11:46:14','{title: Whats Up}
{verse: Intro}
[G] [Am] [C] [G]

{verse: Verse}
[G]25 years and my life is still
[Am]Trying to get up that great big hill of [C]hope
For a desti[G]nation

[G]I realized quickly when I knew I should
[Am]That the whole world''s made up of this brotherhood of [C]man
For whatever that [G]means
 
{verse: Prechorus}
[G]And so I cry sometimes when I''m lying in bed
Just to [Am]get it all out, what''s in my head
And [C]I, I am feeling a little pe[G]culiar
And so I wake in the morning and I step outside
And I [Am]take a deep breath and I get real high
And I [C]scream from the top of my lungs,
What''s goin'' [G]on
 
{verse: Chorus}
And I say [G]hey.... [Am]hey....
I said [C]hey, what''s goin'' [G]on
And I say [G]hey.... [Am]hey....
I said [C]hey, what''s goin'' [G]on
 
{verse: Bridge}
[G]Ooh, [Am]ooh, oooohh, oooohh, what''s up...
[C]Ooh, ooh, oooohh, [G]oooohh, what''s up...
 
{verse: Verse}
[G]And I try, oh my God, do I [Am]try
I try all the [C]time in this insti[G]tution
And I pray, oh my God, do I [Am]pray
I pray every single [C]day for a revo[G]lution!
 
{verse: Prechorus}
[G]And so I cry sometimes when I''m lying in bed
Just to [Am]get it all out, what''s in my head
And [C]I, I am feeling a little pe[G]culiar
And so I wake in the morning and I step outside
And I [Am]take a deep breath and I get real high
And I [C]scream from the top of my lungs,
What''s goin'' [G]on
 
{verse: Chorus}
And I say [G]hey.... [Am]hey....
I said [C]hey, what''s goin'' [G]on
And I say [G]hey.... [Am]hey....
I said [C]hey, what''s goin'' [G]on

{verse: Outro}
[G]25 years and my life is still
[Am]Trying to get up that great big hill of [C]hope
For a desti[G]nation',NULL),
	 ('Sweet child of mine',32,NULL,0,NULL,'2026-09-15 10:09:59','2026-10-05 07:05:34','{title: Sweet child of mine}
{verse: Intro}
[D] [C] [G] [D]
 
{verse: Verse}
[D]She''s got a smile that it seems to me
re[C]minds me of childhood memories,
Where [G]everything was as fresh as the bright blue [D]sky

[D]Now and then When I see her face
she [C]takes me away to that special place,
and if I [G]stared too long,
I''d probably break down and [D]cry
 
{verse: Chorus}
[Am]Woah, woah, [C]woah, sweet child o'' [D]mine
[Am]Woah, oh, oh, [C]oh, sweet love of [D]mine
 
{verse: Verse}
[D]She''s got eyes of the bluest skies,
as [C]if they thought of rain
I [G]hate to look into those eyes
and see a nounce of [D]pain

[D]Her hair reminds me of a warm safe place
where [C]as a child I''d hide,
And [G]pray for the thunder and the rain
to quietly pass me [D]by
 
{verse: Chorus}
[Am]Woah, woah, [C]woah, sweet child o'' [D]mine
[Am]Woah, oh, oh, [C]oh, sweet love of [D]mine

[Am]Woah, woah, [C]woah, sweet child o'' [D]mine
[Am]Woah, oh, oh, [C]oh, sweet love of [D]mine
 
{verse: Bridge}
[Em]Where do we go? [G]Where do we go now?
[Am]Where do we go? [C] [D]
[Em]Where do we go? [G]Where do we go?
[Am]Where do we go now? [C] [D]
Em               G
[Em]Where do we go? [G]Sweet child, where do we go now?
Am               C  D
[Am]Where do we go? [C] [D]
[Em]Where do we go? [G]Where do we go?
[Am]Where do we go? [C] [D]
[Em]Where do we go? [G]Where do we go?
[Am]Where do we go? [C] [D]
 
[E]No, [D]no, [B]no, [Am]no, [G]no, [F]no, [Em]no
Sweet [G]child, sweet [Am]chii[C]illd[D]ddd of [D]mine','D-DU-UDU'),
	 ('Zombie',27,NULL,0,NULL,'2026-09-15 10:26:06','2026-09-28 07:16:17','{title: Zombie}
{verse: Intro}
[Em] [C] [G] [D]     x4
 
{verse: Verse}
[Em]Another [C]head hangs lowly, [G]child is slowly ta[D]ken
[Em]And the violence [C]caused such silence, [G]who are we mis[D]taken
But you [Em]see it''s not me, it''s not [C]my family
In your [G]head, in your head, they are fi[D]ghting

With their [Em]tanks and their bombs and their [C]bombs and their guns
in your [G]head, in your head, they are cry[D]ing
 
{verse: Chorus}
In your [Em]head, in your [C]head, zo[G]mbie, zombie, zo[D]mbie
What''s in your [Em]head, in your [C]head, zo[G]mbie, zombie, zo[D]mbie
 
{verse: Instrumental}
[Em] [C] [G] [D]     x2
 
{verse: Verse}
[Em]Another [C]mother''s breaking [G]heart is taking o[D]ver
[Em]When the violence [C]causes silence, [G]we must be mis[D]taken

It''s the [Em]same old theme since [C]1916
In your [G]head, in your head, they''re still fi[D]ghting

With their [Em]tanks and their bombs and their [C]bombs and their guns
in your [G]head, in your head, they are dy[D]ing
 
{verse: Chorus}
In your [Em]head, in your [C]head, zo[G]mbie, zombie, zo[D]mbie
What''s in your [Em]head, in your [C]head, zo[G]mbie, zombie, zo[D]mbie',NULL),
	 ('Nothing Else Matters',33,NULL,0,NULL,'2026-09-15 13:43:22','2026-09-28 07:16:47','{title: Nothing Else Matters}
{verse: Verse}
[Em]So close no matter [D]how [C]far
[Em]Couldn''t be much more [D]from the [C]heart
[Em]Forever trusting [D]who we [C]are
[G]and [B7]nothing else [Em]matters
 
[Em]Never opened my[D]self this [C]way
[Em]Life is ours, we live it [D]our [C]way
[Em]All these words I don''t [D]just [C]say
[G]and [B7]nothing else [Em]matters
 
[Em]Trust I seek and I [D]find in [C]you
[Em]Every day for us [D]something [C]new
[Em]Open mind for a [D]different [C]view
[G]and [B7]nothing else [Em]matters [C] [A]
 
{verse: Chorus}
[D]Never cared for what they [C]do [A]
[D]Never cared for what they [C]know [A]
[D]But I [Em]know
 
{verse: Verse}
[Em]So close no matter [D]how [C]far
[Em]Couldn''t be much more [D]from the [C]heart
[Em]Forever trusting [D]who we [C]are
[G]and [B7]nothing else [Em]matters [C] [A]
 
{verse: Chorus}
[D]Never cared for what they [C]do [A]
[D]Never cared for what they [C]know [A]
[D]But I [Em]know
 
{verse: Verse}
[Em]Never opened my[D]self this [C]way
[Em]Life is ours, we live it [D]our [C]way
[Em]All these words I don''t [D]just [C]say
[G]and [B7]nothing else [Em]matters 

[Em]Trust I seek and I [D]find in [C]you
[Em]Every day for us [D]something [C]new
[Em]Open mind for a [D]different [C]view
[G]and [B7]nothing else [Em]matters [C] [A]
 
{verse: Chorus}
[D]Never cared for what they [C]say [A]
[D]Never cared for games they [C]play [A]
[D]Never cared for what they [C]do [A]
[D]Never cared for what they [C]know [A]
[D]But I [Em]know
 
{verse: Verse}
[Em]So close no matter [D]how [C]far
[Em]Couldn''t be much more [D]from the [C]heart
[Em]Forever trusting [D]who we [C]are
[G]and [B7]nothing else [Em]matters',NULL),
	 ('You and I',34,NULL,0,NULL,'2026-09-15 14:07:01','2026-09-28 07:24:18','{title: You and I}
{verse: Intro}
[Bm] | [C] [E] | [Am] | [Dm]  [C]  [G]
 
{verse: Verse}
[C]I lose co[Am]ntrol, [Dm]because of you [G]babe
[C]I lose con[Am]troll, [Dm]when you look at me [G]like this
[C]There''s something in your [Am]eyes that is [Dm]sayin'' to[G]night
I''m not a [C]child anymore, life has [Am]opened the door to a [Dm]new  exciting [G]life
 
{verse: Verse}
[C]I lose co[Am]ntrol, [Dm]when I''m close to you [G]babe
[C]I lose co[Am]ntrol, don''t [Dm]look at me like [G]this
[C]There''s something in your [Am]eyes, is this [Dm]love at first [G]sight
Like a [C]flower that grows life just [Am]wants you to know
all [Dm]the secrets of [G]life
 
{verse: Prechorus}
[Dm]It''s all written down in your [Em]lifelines
[Dm]It''s written down inside your [G]heart
 
{verse: Chorus}
[C]You and [Am]I, [Dm]just have a [G]dream
[C]To find our [Am]love a place
where [Dm]we can hide [G]away
[C]You and [Am]I, [Dm]were just [G]made
[C]to love each [Am]other now
for[Dm]ever and a [G]day
 
{verse: Instrumental}
[C] [E] | [Am] | [Dm]  [C]  [G]
 
{verse: Verse}
[C]I lose co[Am]ntrol, [Dm]because of you [G]babe
[C]I lose co[Am]ntrol, [Dm]don''t look at me [G]like this
[C]There''s something in your [Am]eyes that is [Dm]sayin'' to[G]night
I''m so [C]curious for more just like [Am]never before
in my [Dm]innocent [G]life
 
{verse: Prechorus}
[Dm]It''s all written down in your [Em]lifelines
[Dm]It''s written down inside your [G]heart
 
{verse: Chorus}
[C]You and [Am]I, [Dm]just have a [G]dream
[C]To find our [Am]love a place
where [Dm]we can hide [G]away
[C]You and [Am]I, [Dm]were just [G]made
[C]to love each [Am]other now
for[Dm]ever and a [G]day
 
{verse: Bridge}
[Am]Time stands still
[F]When days of innocence are [G]falling for the night
[Am]I love you girl, I always will
[F]I swear I''m there for you [E]till the day I die (yeah!)
 
{verse: Chorus}
(full-tone up) x2
[D]You and [Bm]I, [G]just have a [A]dream
[D]To find our [Bm]love a place
where [Em]we can hide [A]away
[D]You and [Bm]I, [G]were just [A]made
[D]To love each [Bm]other now
for[Em]ever and a [A]day',NULL),
	 ('Sound of silence',35,NULL,0,NULL,'2026-09-15 14:21:08','2026-09-28 07:24:36','{title: Sound of silence}
{verse: Verse}
[Em]Hello darkness, my old [D]friend,
I''ve come to talk with you [Em]again,
Because a vision softly[C] cree[G]ping,
Left its seeds while I was[C] slee[G]ping,
And the [C]vision that was planted in [G]my brain
Still [Em]remains
Within the [D]sound of [Em]silence.
 
{verse: Verse}
In restless dreams I walked [D]alone
Narrow streets of cobble[Em]stone,
''neath the halo of [C]a street [G]lamp,
I turned my collar to the [C]cold and [G]damp
When my [C]eyes were stabbed by the flash of a neon [G]light
That split the [Em]night
And touched the [D]sound of [Em]silence.
 
{verse: Verse}
And in the naked light I [D]saw
Ten thousand people, maybe [Em]more.
People talking without[C] spea[G]king,
People hearing without[C] liste[G]ning,
People writing [C]songs that voices never [G]share
And no one [Em]dare
Disturb the [D]sound of [Em]silence.
 
{verse: Verse}
Fools said I, you do not [D]know
Silence like a cancer [Em]grows.
Hear my words that I might[C] teach [G]you,
Take my arms that I might[C] reach [G]you.
But my [C]words like silent raindrops [G]fell,
And echoed in the [D]wells of [Em]silence
 
{verse: Verse}
And the people bowed and [D]prayed
To the neon God they [Em]made.
And the sign flashed out [C]its warn[G]ing,
In the words that it [C]was form[G]ing.

And the sign said, the [C]words of the prophets
Are [Em]written on the [G]subway walls
And tenement halls.

And whispered in the [D]sounds of [Em]silence.
',NULL),
	 ('Come as you are',3,NULL,0,NULL,'2026-09-15 14:34:25','2026-09-28 07:27:38','{title: Come as you are}
{verse: Intro}
[Em] [D] [Em] [D] x2
 
{verse: Verse}
[Em]Come as you [D]are, as you [Em]were
As I [D]want you to [Em]be
As a [D]friend, as a [Em]friend
As an [D]old ene[Em]my
Take your [D]time, hurry [Em]up
Choice is [D]yours, don''t be [Em]late
Take a [D]rest as a [Em]friend
As an [D]old memo[E]ri[G]a
 
{verse: Prechorus}
Memo[D]ri[G]a
Memo[D]ri[G]a
Memo[D]ri[G]a
 
{verse: Verse}
[Em]Come doused in [D]mud, soaked in [Em]bleach
As I [D]want you to [Em]be
As a [D]trend, as a [Em]friend
As an [D]old memo[E]ri[G]a
 
{verse: Prechorus}
Memo[E]ri[G]a
Memo[E]ri[G]a
Memo[E]ri[G]a
 
{verse: Chorus}
[A]And I [C]swear that [A]I don''t have a [C]gun
No, I [A]don''t have a [C]gun
No, I [A]don''t have a [C]gun

{verse: Prechorus}
Memo[E]ri[G]a
Memo[E]ri[G]a
Memo[E]ri[G]a
 
{verse: Chorus}
[A]And I [C]swear that [A]I don''t have a [C]gun
No, I [A]don''t have a [C]gun
No, I [A]don''t have a [C]gun
No, I [A]don''t have a [C]gun
No, I [A]don''t have a [C]gun',NULL),
	 ('The man who sold the world',3,NULL,0,NULL,'2026-09-15 14:57:20','2026-10-16 07:09:47','{title: The man who sold the world}
[Intro] 
[F] [Dm]

{verse: Verse}
We passed upon the [A]stair
We spoke of was and [Dm]when
Although I wasn''t [A]there
He said I was his [F]friend
Which came as a surp[C]rise
I spoke into his [A]eyes
I thought you died a[Dm]lone
A long long time [C]ago
 
{verse: Chorus}
[C]Oh no, not [F]me
We [C#]never lost [F]control
You''re [C]face to [F]face
With the [C#]man who sold the world [A]
 
{verse: Interlude}
[A] [Dm] [F] [Dm]
 
{verse: Verse}
I laughed and shook his [A]hand
And made my way back [Dm]home
I searched for form and [A]land
For years and years I [F]roamed
I gazed a gazeless [C]stare
We walked a million [A]years
I must have died [Dm]alone
A long, long time [C]ago
 
{verse: Chorus}
[C]Oh no, not [F]me
We [C#]never lost [F]control
You''re [C]face to [F]face
With the [C#]man who sold the world [A]
 
{verse: Interlude}
[C]Oh no, not [F]me
We [C#]never lost [F]control
You''re [C]face to [F]face
With the [C#]man who sold the world [A]','DUDU-UDU'),
	 ('Ήτανε μια φορά',36,NULL,0,NULL,'2026-09-16 08:17:22','2026-10-26 13:02:43','{title: Ήτανε μια φορά}
[Dm] [C]
(εναλλακτικά)

{verse: Verse}
[Em]Ήτανε μια [D]φορά, μάτια μου, κι ένα και[Em]ρό
[Em]μια όμορφη κυ[D]ρά, αρχόντισσα, να σε χα[Em]ρώ
[Em]Μια μικροπαντρε[D]μένη, κόρη ξαν[Em]θή
[Em]τον κύρη της προ[D]σμένει, βράδυ-πρω[Em]ί

{verse: Verse}
[Em]Ένα Σάββατο [D]βράδυ, καλέ, μια Κυρια[Em]κή
[Em]τον ήλιο, το φε[D]γγάρι, καλέ, παρακα[Em]λεί
[Em]Ήλιε μου, φώτι[D]σέ τον, φεγγάρι [Em]μου
[Em]πάνε και μίλη[D]σέ του για χάρη [Em]μου

{verse: Verse}
[Em]Γυρίζει κι αρμε[D]νίζει, καλέ, τα πέλα[Em]γα
[Em]τους πειρατές θε[D]ρίζει, καλέ, και τους χα[Em]λά
[Em]στον ήλιο, στο φε[D]γγάρι και στη βρο[Em]χή
[Em]και μένανε μ'' α[D]φήνει έρμη και μονα[Em]χή

{verse: Verse}
[Em]Γαλέρα ανοίχτη[D]κε, μάτια μου, μες το νο[Em]τιά
[Em]στη μάχη ρίχτη[D]κε, μάτια μου, και στον καυ[Em]γά
[Em]Μέσα σ'' ένα σι[D]νάφι πειρατι[Em]κό
[Em]είδα φωτιά ν'' α[D]νάφτει και φονι[Em]κό',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Σταλιά σταλιά',37,NULL,0,NULL,'2026-09-16 10:24:08','2026-09-28 08:00:56','{title: Σταλιά σταλιά}
{verse: Verse}
[Am]Aγόρι μου, στολίδι μου
σαν γέ[Dm]ρνεις και μ'' αγγίζεις[Am] [Dm] [Am] [E] [Am]
[Am]Πιο πέρα κι απ'' τα πέρατα
του κό[Dm]σμου μ'' αρμενίζεις[Am] [Dm] [Am] [E] [Am]

{verse: Chorus}
[E]Σταλιά-σταλιά κι αχόρταγα
τα πίνω τα φι[Am]λιά σου
[E]Κουρνιάζω σαν αδύνατο
πουλί στην αγκα[Am]λιά σου

{verse: Verse}
[Am]Mατιά-ματιά τα μάτια σου
αγά[Dm]πη με χορταίνουν[Am] [Dm] [Am] [E] [Am]
[Am]Τη μέρα με πεθαίνουνε
τη νύ[Dm]χτα μ'' ανασταίνουν[Am] [Dm] [Am] [E] [Am]

{verse: Chorus}
[E]Σταλιά-σταλιά κι αχόρταγα
τα πίνω τα φι[Am]λιά σου
[E]Κουρνιάζω σαν αδύνατο
πουλί στην αγκα[Am]λιά σου

{verse: Verse}
[Am]Άσε να μπω στα χείλη σου
τη δί[Dm]ψα μου να σβήσω[Am] [Dm] [Am] [E] [Am]
[Am]και την καρδιά σου αγόρι μου
δροσιά [Dmνα την ποτίσω[Am] [Dm] [Am] [E] [Am]

{verse: Chorus}
[E]Σταλιά-σταλιά κι αχόρταγα
τα πίνω τα φι[Am]λιά σου
[E]Κουρνιάζω σαν αδύνατο
πουλί στην αγκα[Am]λιά σου',NULL),
	 ('Βρέχει φωτιά στην στράτα μου',44,NULL,0,NULL,'2026-09-17 06:53:48','2026-09-28 08:04:18','{title: Βρέχει φωτιά στην στράτου μου}

{verse: Verse}
[E]Βρέχει φωτιά στη [Dm]στρά[E]τα μου
φωτιά που μ'' έχει [Dm]κά[E]ψει
[Dm]Για τα φτωχά τα νιάτα [Am]μου [G]
κανένας δε θα [Dm]κλά[E]ψει

{verse: Chorus}
[Am]Η ζωή, η ζωή εδώ τε[G]λειώνει
σβήνει το κα[F]ντήλι [E]μου
[Am]κι η ψυχή, η ψυχή σαν χελι[G]δόνι
φεύγει απ'' τα [F]χείλη [E]μου

{verse: Verse}
[E]Κύμα πικρό στην [Dm]πλώρη [E]μου
και τα πανιά σκι[Dm]σμέ[E]να
[Dm]Ούτε αδελφός αγόρι [Am]μου [G]
δε νοιάστη[Dm]κε για σέ[E]να

{verse: Chorus}
[Am]Η ζωή, η ζωή εδώ τε[G]λειώνει
σβήνει το κα[F]ντήλι [E]μου
[Am]κι η ψυχή, η ψυχή σαν χελι[G]δόνι
φεύγει απ'' τα [F]χείλη [E]μου',NULL),
	 ('Καμμιά φορά',37,NULL,0,NULL,'2026-09-16 11:43:38','2026-09-28 08:01:12','{title: Καμμιά φορά}

{verse: Verse}
[Am]Καμιά φορά λέω ν'' αλλάξω ουρα[Dm]νό
μα [G]δεν, μα δεν υπά[C]ρχουν δρόμοι[E]
κι άλλη φο[Am]ρά σκέφτομαι πόσο [Dm]σ'' αγαπώ
και [G]σου, και σου ζητώ [C]συγγνώμη[E]

{verse: Verse}
[Am]Τώρα δεν είμαστε παιδιά
να ''χουμε φως μες στην καρδιά να μας σκε[Dm]πάζει
[G]μα σ'' αγαπώ σου το ''χω πει
κι η αγάπη σου σαν Κυριακή με ξεκου[C]ράζει [E]

{verse: Verse}
[Am]Καμιά φορά λέω ν'' αλλάξω ουρα[Dm]νό
μα [G]δεν, μα δεν υπά[C]ρχουν δρόμοι[E]
κι άλλη φο[Am]ρά σκέφτομαι πόσο [Dm]σ'' αγαπώ
και [G]σου, και σου ζητώ [C]συγγνώμη[E]

{verse: Verse}
[Am]Βλέπεις πώς άλλαξε ο καιρός
κι έγινε ο κόσμος βροχερός, όλο χα[Dm]λάζι
[G]μα σ'' αγαπώ σου το ''χω πει
κι αν όλα μοιάζουν φυλακή, δεν με [C]τρομάζει [E]

{verse: Verse}
[Am]Καμιά φορά λέω ν'' αλλάξω ουρα[Dm]νό
μα [G]δεν, μα δεν υπά[C]ρχουν δρόμοι[E]
κι άλλη φο[Am]ρά σκέφτομαι πόσο [Dm]σ'' αγαπώ
και [G]σου, και σου ζητώ [C]συγγνώμη[E]
 
Καμιά φορά[Am]',NULL),
	 ('Για κοίτα με στα μάτια λοιπόν',37,NULL,0,NULL,'2026-09-16 11:56:57','2026-09-28 08:01:31','{title: Για κοίτα με στα μάτια λοιπόν}
{verse: Intro}
[Am]  [G]  [Am]  [G]  [Am]  [G]  [F]  [C]
[Am]  [G]  [Am]  [G]  [Am]  [G]  [F]  [E]  [Am]

{verse: Verse}
[Am]Όταν σε κοι[E]τώ στα [Am]μάτια δεν [E]μπορείς να μου κρυφτείς
[Am]Κάτι σ'' έκα[E]νε να [Am]κλάψεις και να πικρα[E]θείς

{verse: Chorus}
Για [Dm]κοίτα με στα μάτια λοιπόν κι εξηγήσου
Που [Am]είναι το ζεστό το γλυκό το φιλί σου
Δεν [F]είχες μυστικά από μένα θυμήσου
Για [C]κοίτα με στα μάτια λοιπόν

Για [Dm]κοίτα με στα μάτια λοιπόν κι εξηγήσου
Που [Am]είναι το ζεστό το γλυκό το φιλί σου
Δεν [F]είχες μυστικά από μένα θυμήσου
Για [Am]κοίτα με στα μάτια λοιπόν

{verse: Verse}
[Am]Όταν σε κοι[E]τώ στα [Am]μάτια [E]μη τα ρίχνεις χαμηλά
[Am]Βάζω μέσα [E]στο μυαλό μου [Am]πράγματα τρε[E]λά

{verse: Chorus}
Για [Dm]κοίτα με στα μάτια λοιπόν κι εξηγήσου
Που [Am]είναι το ζεστό το γλυκό το φιλί σου
Δεν [F]είχες μυστικά από μένα θυμήσου
Για [C]κοίτα με στα μάτια λοιπόν
 
Για [Dm]κοίτα με στα μάτια λοιπόν κι εξηγήσου
Που [Am]είναι το ζεστό το γλυκό το φιλί σου
Δεν [F]είχες μυστικά από μένα θυμήσου
Για [Am]κοίτα με στα μάτια λοιπόν',NULL),
	 ('Γυάλινος κόσμος',38,NULL,0,NULL,'2026-09-16 12:08:43','2026-09-28 08:01:56','{title: Γυάλινος κόσμος}

{verse: Verse}
[D]Ποιός θα μου δώσει δύνα[G]μη
[D]Τον κόσμο αυτό ν'' αλλά[G]ξω
[G]Να φτιάξω όμορφες καρδιές
[C]Μεγάλες και πονετι[Am]κές
[D]Τις σκάρτες να πετά[G]ξω

{verse: Chorus}
[C]Να σου δώσω μια να σπάσεις
[G]Αχ βρε κόσμε [C]γυάλι[G]νε
[G]Και να φτιάξω μια και[C]νούρια
Κοινωνία [G]άλληνε

{verse: Verse}
[D]Να φτιάξω φίλο αληθι[G]νό,
[D]τον φίλο να πονά[G]ει
[G]Τα βάσανα και οι καημοί
[C]να λείψουνε απ'' [Am]τη ζωή
[D]κι όμορφη να κυλά[G]ει

{verse: Chorus}
[C]Να σου δώσω μια να σπάσεις
[G]Αχ βρε κόσμε [C]γυάλι[G]νε
[G]Και να φτιάξω μια και[C]νούρια
Κοινωνία [G]άλληνε

{verse: Verse}
[D]Και στης γυναίκας την καρ[G]διά
[D]να βάλω λίγη μπέ[G]σα
[G]να της ανάψω μια φωτιά,
[C]να καταστρέψω την ψευ[Am]τιά
[D]που ''χει στα στήθια μέ[G]σα

{verse: Chorus}
[C]Να σου δώσω μια να σπάσεις
[G]Αχ βρε κόσμε [C]γυάλι[G]νε
[G]Και να φτιάξω μια και[C]νούρια
Κοινωνία [G]άλληνε',NULL),
	 ('Πριν χαθεί το όνειρό μας',39,NULL,0,NULL,'2026-09-16 12:28:20','2026-09-28 08:02:16','{title: Πριν χαθεί το όνειρό μας}

{verse: Verse}
[Am]Χόρεψε μαζί μου α[Dm]πόψε
κάτω [E]απ το φεγγάρι
[Dm]Δες τα μάτια μου γεμίσαν
από σέ[E]νανε

{verse: Verse}
[Am]Χόρεψε για την α[Dm]γάπη
που ''ρθε να [E]σε πάρει
[Dm]χόρεψε για σένα μόνο
[E]και για μένα[Am]νε

{verse: Chorus}
[Am]Πριν χαθεί το όνειρό μας
και ξαναβρα[Dm]διάσου[E]με
άσε με να σ'' αγαπάω 
κι όπου φτάσου[E]με 

{verse: Verse}
[Am]Χόρεψε μαζί μου [Dm]τώρα
στου καη[E]μού την άκρη
[Dm]Πιες απόψε την ζωή μου
και αγά[E]πα με

{verse: Verse}
[Am]Χόρεψε για δυο αγά[Dm]πες
και μια χούφτα [E]δάκρυ
[Dm]έχουμε πολλά να πούμε
[E]που δεν τα ''[E]παμε

{verse: Chorus}
[Am]Πριν χαθεί το όνειρό μας
και ξαναβρα[Dm]διάσου[E]με
άσε με να σ'' αγαπάω
κι όπου φτάσου[E]με',NULL),
	 ('Τα δυο σου χέρια',40,NULL,0,NULL,'2026-09-16 12:53:42','2026-09-28 08:02:26','{title: Τα δυο σου χέρια}

{verse: Verse}
[Em]Τα δυο σου χέρια πήρανε
[Em]βεργούλες και με δείρανε
[G]Βεργούλες και με δείρανε
και την χαρά μου [Am]πήρανε[Em]

{verse: Verse}
[Em]Τα χέρια σου με κάψανε
[Em]που άλλον αγκαλιάσανε
[G]Που άλλον αγκαλιάσανε
και δεν με λογα[Am]ριάσανε[Em]

{verse: Verse}
[Em]M'' αυτά τα χέρια σου τα δυο
[Em]σκάψε την γης βαθιά να μπω
[G]Σκάψε την γης βαθιά να μπω
να μην σε βλέπω [Am]και πονώ[Em]',NULL),
	 ('Μια φωτοβολίδα',49,NULL,0,NULL,'2026-09-17 11:09:09','2026-09-28 08:06:50','{title: Μια φωτοβολίδα}

{verse: Verse}
[Am]Μια φωτοβο[F]λίδα [G]μες στη νύχτα [Dm]σκάει
[F]κι η καρδιά μου [Em]σπάει [F]μες στο φως σε [C]εί[Em]δα
[Am]Γίναν τα κο[F]μμάτια [G]μια καινούργια [Dm]γη
[F]μες στην αλλα[Em]γή [F]βλέπω μ'' άλλα [C]μά[Em]τια

{verse: Verse}
[Am]Μια φωτοβο[F]λίδα [G]μες στη νύχτα [Dm]σκάει
[F]κι η καρδιά μου [Em]σπάει [F]μες στο φως σε [C]εί[Em]δα
[Am]Γίναν τα κο[F]μμάτια [G]μια καινούργια [Dm]γη
[F]μες στην αλλα[Em]γή [F]βλέπω μ'' άλλα [C]μά[G]τια

{verse: Chorus}
[C]Όλα είναι ίδια [Am]αν δε τ'' αγα[F]πάς
[G]όλα μένουν [Dm]ίδια άμα δε τα [G]πας
[C]Κι όλα αυτά που [G]είναι [C]γίνονται ξα[F]νά
[G]μέσα απ'' τη δι[Dm]κιά σου τη μα[F]τιά
[G]μέσα απ'' τη δι[F]κιά σου τη μα[Am]τιά

{verse: Verse}
[Am]Μια φωτογρα[F]φία [G]κομματάκια [Dm]δυο
[F]έχω να σε [Em]δω [F]χρόνια αστεία-α[C]στεί[Em]α
[Am]Πιάνω την κο[F]λλάω [G]σε ξανακοι[Dm]τώ
[F]πιο όμορφη θαρ[Em]ρώ [F]δείχνεις μου όσο [C]πά[G]ω

{verse: Chorus}
[C]Όλα είναι ίδια [Am]αν δε τ'' αγα[F]πάς
[G]όλα μένουν [Dm]ίδια άμα δε τα [G]πας
[C]Κι όλα αυτά που [G]είναι [C]γίνονται ξα[F]νά
[G]μέσα απ'' τη δι[Dm]κιά σου τη μα[F]τιά
[G]μέσα απ'' τη δι[F]κιά σου τη μα[Am]τιά

{verse: Verse}
[Am]Στην καρδιά σου [F]καίει [G]μια μικρή φω[Dm]τιά
[F]κι από τη μα[Em]τιά [F]ένα φως που [C]ρέ[Em]ει
[Am]Σα φωτοβο[F]λίδα [G]μες στη νύχτα [Dm]σκάει
[F]κι ας ξαναγυρ[Em]νάει [F]πίσω η σε[C]λί[Em]δα',NULL),
	 ('Κι αν περπατώ',14,NULL,0,NULL,'2026-09-16 13:35:44','2026-09-28 08:03:00','{title: Κι αν περπατώ}

{verse: Verse}
[Am]Κι αν περπα[Em]τώ, κι αν περπα[Am]τώ, [F]ω, [G]ω, [Am]ω
[Am]Δεν ξέρω [Em]πού πηγαί[Am]νω
[Dm]Ο δρόμος [E]με ακολου[Am]θεί, Χρι[Dm]στέ και Παναγιά
[E]Κοντά σου πάντα μέ[Am]νω, [G]ω, [C]ω, ω
[Dm]Ο δρόμος [E]με ακολου[Am]θεί, Χρι[Dm]στέ και Παναγιά
[E]Κοντά σου πάντα μέ[Am]νω, [F]ω, [G]ω, [Am]ω

{verse: Verse}
[Am]Δέντρο κα[Em]μένο απ'' τη φω[Am]τιά, [F]ω, [G]ω, [Am]ω
[Am]Γίνηκε [Em]το κορμί [Am]μου
[Dm]Μα στην καρ[E]διά μου έχω δρο[Am]σιά, Χρι[Dm]στέ και Παναγιά
[E]Όταν σε δω καλή [Am]μου, [G]ω, [C]ω, ω
[Dm]Μα στην καρ[E]διά μου έχω δρο[Am]σιά, Χρι[Dm]στέ και Παναγιά
[E]Όταν σε δω καλή [Am]μου, [F]ω, [G]ω, [Am]ω

{verse: Verse}
[Am]Φαρμάκι [Em]μου ''γινε η ζω[Am]ή, [F]ω, [G]ω, [Am]ω
[Am]στο δρόμο [Em]που πηγαί[Am]νω
[Dm]Ο πόνος [E]με ακολου[Am]θεί, Χρι[Dm]στέ και Παναγιά
[E]Μακριά σου αργοπεθαί[Am]νω, [G]ω, [C]ω, ω
[Dm]Ο πόνος [E]με ακολου[Am]θεί, Χρι[Dm]στέ και Παναγιά
[E]Μακριά σου αργοπεθαί[Am]νω, [F]ω, [G]ω, [Am]ω',NULL),
	 ('Πούλα με',42,NULL,0,NULL,'2026-09-16 13:46:34','2026-09-28 08:03:17','{title: Πούλα με}

{verse: Verse}
[Em]Πούλα με ακόμα μια φο[D]ρά, δεν με πει[Em]ράζει
Δεν με πει[Am]ράζει που θα [Bm]μείνω μονα[Em]χός
Δεν με πει[Am]ράζει που τα μάτια σου σ'' αυ[Bm]τόν θα θυσι[Em]άζεις
γιατί α[C]πόψε το κορ[D]μί σου θα ''ναι α[Em]λλού

{verse: Verse}
[Em]Θα'' ναι σε [Am]κάτι ξεχα[Bm]σμένα καλο[Em]καίρια
θα ''ναι στις [Am]νύχτες της α[Bm]τέλειωτης σιω[Em]πής
θα ''ναι στα [Am]φιλμ της χα[Bm]ράς και της μι[Em]ζέριας
θα ''ναι σε ό[C]λα που πε[D]ράσαμε μα[Em]ζί

{verse: Chorus}
[Am]Πούλα με λοι[Bm]πόν στο ξανα[Em]λέω
[Am]πούλα με για [Bm]λίγη σιγου[Em]ριά
[Am]πούλα με πο[Bm]λύ φθηνά δεν [Em]ξέρω
ίσως [C]αύριο, [D]να ''ναι αρ[Em]γά

{verse: Verse}
[Em]Κι αν σε βλέπω αδιάφορα ξε[D]ρά, δεν με πει[Em]ράζει
[Em]δεν με πει[Am]ράζει κι αν τα [Bm]χείλη σου γε[Em]λούν
μια καλη[Am]νύχτα αν μου [Bm]πεις δεν με πει[Em]ράζει
γιατί [C]απόψε το κορ[D]μί σου θα ''ναι [Em]αλλού

{verse: Chorus}
[Am]Πούλα με λοι[Bm]πόν στο ξανα[Em]λέω
[Am]πούλα με για [Bm]λίγη σιγου[Em]ριά
[Am]πούλα με πο[Bm]λύ φθηνά δεν [Em]ξέρω
ίσως [C]αύριο, [D]να ''ναι αρ[Em]γά',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Η αλάνα',11,NULL,0,NULL,'2026-09-16 14:01:40','2026-09-28 08:03:31','{title: Η αλάνα}

{verse: Verse}
[Em]Σ'' έστησαν σε μια γωνιά, κι ήσουνα [F]νέο παλι[Em]κάρι
[Em]Σ'' έστησαν σε μια γωνιά, κι ήτανε [F]τέσσεροι φα[Em]ντάροι
[Am]Σ'' έστησαν σε μια γωνιά, και σημα[Dm]δεύαν την καρ[Em]διά σου
[Am]Σ'' έστησαν σε μια γωνιά, κι ήταν πρω[Dm]ί και παγω[Em]νιά

{verse: Chorus}
[Em]Σε καρτερούσε η ζωή και μια παραδουλεύτρα [F]μάνα
Κι έγινες κείνο το πρω[Em]ί κόκκινο [F]κρίνο στην α[Em]λάνα

{verse: Verse}
[Em]Σ'' έστησαν σε μια γωνιά, κι έκλαιγε η [F]μοίρα σου παρ[Em]έκει
[Em]Σ'' έστησαν σε μια γωνιά, κι είχε κι ο [F]Χάροντας του[Em]φέκι
[Am]Σ'' έστησαν σε μια γωνιά, και τους κοι[Dm]τούσες και γε[Em]λούσες
[Am]Σ'' έστησαν σε μια γωνιά, κι ήταν πρω[Dm]ί και παγω[Em]νιά

{verse: Chorus}
[Em]Σε καρτερούσε η ζωή και μια παραδουλεύτρα [F]μάνα
Κι έγινες κείνο το πρω[Em]ί κόκκινο [F]κρίνο στην α[Em]λάνα',NULL),
	 ('Νταλίκα',6,NULL,0,NULL,'2026-09-16 14:12:22','2026-09-28 08:03:47','{title: Νταλίκα}

{verse: Verse}
[Am]Ζόρικος κρεμανταλάς
ο καιρός που κουβα[G]λάς
[F]Η ζωή σου μια ντα[G]λίκα
με μπαγκάζια [F]και με [E]ΙΚΑ

{verse: Verse}
[Am]Τώρα απόχτησες καβούκι
και αμάξι σπορ μο[G]ντέλο
[F]Τώρα σκάλωσες στο [G]λούκι
κι είσ'' αλλιώτι[F]κο κα[E]πέλο

{verse: Verse}
[Am]Η ζωή σου ντούμπλε-φας
μέσα κι έξω τη φο[G]ράς
[F]Η καρδούλα σου γκαζιέρα
δίχως γκάζι [F]και α[E]γέρα

{verse: Verse}
[Am]Μες στο κόλπο είσαι χωμένος
και γλιτώνεις παρά [G]τρίχα
[F]Τώρα είσαι βολεμένος
και σου κόψα[F]νε το [E]βήχα

{verse: Verse}
[Am]Κι αν θυμάσαι τα παλιά
ψέματα και μπλα-μπλα-[G]μπλα
[F]Η μαγκιά σου ναφθαλίνη
με κασμίρι [F]και λου[E]στρίνι

{verse: Verse}
[Am]Τώρα κάνεις μαύρη πλάκα
κι όλο τρως απ'' την κου[G]τάλα
[F]Τώρα μάγκωσε η φάκα
και σε κλείσα[F]νε στη [E]γυάλα',NULL),
	 ('Όταν συμβεί στα πέριξ',6,NULL,0,NULL,'2026-09-17 06:39:24','2026-09-28 08:03:55','{title: Όταν συμβεί στα πέριξ}

{verse: Verse}
[C]Γιατί ρωτάτε να σάς πω, αφού σάς είναι πια γνωστό
Όταν συμ[F]βεί στα πέριξ, φωτιές να [C]καίνε   | 2x
[G]γλεντούν οι μάγκες με καη[C]μό              | 2x

{verse: Verse}
[C]Φωτιές ανάβει στο μυαλό ένα ζεϊμπέκικο γλυκό
Αυτοί χο[F]ρεύουνε κι εγώ σφυ[C]ρίζω   | 2x
[G]της αγάπης το σκο[C]πό              | 2x

{verse: Verse}
[C]Η νύχτα φέρνει την αυγή κι ο μπαγλαμάς μου κελαηδεί
Ένα κε[F]λάηδισμα, το ίδιο [C]πάντα   | 2x
[G]στης αγάπης το σκο[C]πό            | 2x',NULL),
	 ('Μούφαγες όλα τα δαχτυλίδια',43,NULL,0,NULL,'2026-09-17 06:47:25','2026-09-28 08:04:03','{title: Μούφαγες όλα τα δαχτυλίδια}

{verse: Verse}
[Am]Από πιτσιρίκα σε λέγανε μπαμπέσα
κι έλαχε σε σένα να [E]δώκω λίγη [Am]μπέσα
[F]Μου ''φαγες όλα τα δαχτυ[Dm]λίδια         | 2x
και κοιμάμαι τώρα, [E]τώρα στα σα[Am]νίδια  | 2x

{verse: Verse}
[Am]Ό,τι και αν είχα προτού να σε γνωρίσω
όλα στα ''χω [E]δώσει για να σ'' ευχαρι[Am]στήσω
[F]Κι ύστερα από τόσα δαχτυλίδια                | 2x
μ'' έχεις και κοιμάμαι, [E]κοιμάμαι στα σα[Am]νίδια  | 2x

{verse: Verse}
[Am]Μπράβο σου, τ'' αξίζεις, που μ'' έχεις καταφέρει
και πόσο αντέχω [E]ακόμα, ένας θεός το [Am]ξέρει
[F]Δεν με νοιάζει για τα δαχτυλίδια         | 2x
μόνο που κοιμάμαι, [E]κοιμάμαι στα σα[Am]νίδια  | 2x',NULL),
	 ('Δυο πόρτες έχει η ζωή',38,NULL,0,NULL,'2026-09-17 06:58:56','2026-09-28 08:04:41','{title: Δυο πόρτες έχει η ζωή}

{verse: Verse}
[C]Το τελευταίο βράδυ μου
[Dm]απόψε [G]το περνά[C]ω
[Em]κι όσοι με πίκραναν πολύ
[F]τώρα που φεύγω απ'' τη ζωή
[C]όλους τους συγχωρνάω

{verse: Chorus}
[C]Όλα είναι ένα ψέμα
μια ανάσα [F]μια πνο[C]ή
[F]σα λουλούδι κάποιο [C]χέρι
θα μάς κόψει [F]μιαν αυ[C]γή

{verse: Verse}
[C]Εκεί που πάω δεν περνά
[Dm]το δάκρυ [G]και ο πό[C]νος
[Em]τα βάσανα και οι καημοί
[F]εδώ θα μείνουν στη ζωή
[C]κι εγώ θα φύγω μόνος

{verse: Chorus}
[C]Όλα είναι ένα ψέμα
μια ανάσα [F]μια πνο[C]ή
[F]σα λουλούδι κάποιο [C]χέρι
θα μάς κόψει [F]μιαν αυ[C]γή

{verse: Verse}
[C]Δυο πόρτες έχει η ζωή
[Dm]άνοιξα [G]μια και [C]μπήκα
[Em]σεργιάνισα ένα πρωινό
[F]κι ώσπου να ''ρθει το δειλινό
[C]από την άλλη βγήκα

{verse: Chorus}
[C]Όλα είναι ένα ψέμα
μια ανάσα [F]μια πνο[C]ή
[F]σα λουλούδι κάποιο [C]χέρι
θα μάς κόψει [F]μιαν αυ[C]γή',NULL),
	 ('Πριγκηπέσσα',45,NULL,0,NULL,'2026-09-17 07:05:09','2026-09-28 08:05:13','{title: Πριγκηπέσσα}
{verse: Intro}
[Em] [Am] [F] [Dm] [Em]

{verse: Verse}
[Em]Άλλα θέλω κι άλλα κάνω πώς να σου το [Am]πω
[Dm]έλεγα περνούν τα χρόνια [G]θα συμμορφω[Em]θώ
[Em]Μα είναι δώρο άδωρο ν'' αλλάξεις χαρα[Am]κτήρα
τζάμπα κρατάς λο[Em]γαριασμό [Dm]τζάμπα σωστός με το στα[Em]νιό

{verse: Interlude}
[Em] [Am] [F] [Dm] [Em]

{verse: Chorus}
[Dm]Έξω φυσάει αέρας κι όμως μέ[Em]σα μου
[Dm]μέσα σ'' αυτό το σπίτι [G]πριγκιπέσσα [Em]μου
το φως σου και το φως χορεύουν γύρω [Am]μας
απίστευτος ο [Em]κόσμος  [Dm]κι ο χαρακτήρας [Em]μας

{verse: Verse}
[Em]Άλλα θέλω κι άλλα κάνω κι έφτασα ως ε[Am]δώ
[Dm]λάθη στραβά και πάθη [G]μ'' έβγαλαν σω[Em]στό
[Em]Ξημερώματα στο δρόμο ρίχνω πετο[Am]νιά
πιάνω τον [Em]εαυτό μου [Dm]και χάνω το μυα[Em]λό μου

{verse: Chorus}
[Dm]Έξω φυσάει αέρας κι όμως μέ[Em]σα μου
[Dm]μέσα σ'' αυτό το σπίτι [G]πριγκιπέσσα [Em]μου
το φως σου και το φως χορεύουν γύρω [Am]μας
απίστευτος ο [Em]κόσμος  [Dm]κι ο χαρακτήρας [Em]μας',NULL),
	 ('Ο Τούρκος',46,NULL,0,NULL,'2026-09-17 07:19:09','2026-09-28 08:05:35','{title: Ο Τούρκος}

{verse: Verse}
[Am]Μου γράφεις δεν θα ''ρθεις για διακοπές
Χρωστάς μαθήματα μου λες
Φωτογρα[E]φίες στέλνεις απ'' το [Am]Λούβρο
Και άλλες [E]με τον γάτο σου τον [Am]Τούρκο

{verse: Verse}
[Am]Κι ο Τούρκος να πηδάει στα σκαλιά
Και ύστερα παιχνίδι να σου κάνει
Στη γάμπα [E]σου να τρέμει μια ου[Am]ρά
Αυτός ο [E]Τούρκος Τούρκο θα με [Am]κάνει
Στη γάμπα [Dm]σου να παίζει μια ου[Am]ρά
Αυτός ο [E]Τούρκος Τούρκο θα με [Am]κάνει

{verse: Chorus}
Ζηλεύω [F]το μικρό σου το γα[Am]τί
Στα πόδια [F]σου κοιμάται όταν δια[Am]βάζεις
Δεν ξέρω [F]αν κοι[G]μάστε και μα[C]ζί
Ή μ'' άλλον [E]στο κρεβάτι το αλ[Am]λάζεις
Δεν ξέρω [Dm]αν κοιμάστε και μα[Am]ζί
Ή μ'' άλλον [E]στο κρεβάτι το αλ[Am]λάζεις

{verse: Verse}
[Am]Μου γράφεις πως σου έλειψα πολύ
Μου στέλνεις χάρτινο φιλί
Το χρόνο [E]σου μετράς για το πτυ[Am]χίο
Το γράμμα [E]μου σου φάνηκε α[Am]στείο
[Am]Κι ο Τούρκος στη μοκέτα αραχτός
Κουβέντα με τους Γάλλους σου να πιάνει
Να πίνει [E]και να τρώει ότι [Am]τρως
Αυτός ο [E]Τούρκος Τούρκο θα με [Am]κάνει   ] 2x

{verse: Chorus}
Ζηλεύω [F]το μικρό σου το γα[Am]τί
Στα πόδια [F]σου κοιμάται όταν δια[Am]βάζεις
Δεν ξέρω [F]αν κοι[G]μάστε και μα[C]ζί
Ή μ'' άλλον [E]στο κρεβάτι το αλ[Am]λάζεις
Δεν ξέρω [Dm]αν κοιμάστε και μα[Am]ζί
Ή μ'' άλλον [E]στο κρεβάτι το αλ[Am]λάζεις

{verse: Verse}
Συγχώρα [F]με που γίνομαι μι[Am]κρός
Μ'' ανάγκη [F]να σε νιώσω είναι με[Am]γάλη
Μακριά σου [F]νιαου[G]ρίζω μονα[C]χός              | 2x
Μα C''est la [Dm]vie  που λένε και οι [Am]Γάλλοι   | 2x',NULL),
	 ('Ρίτα Ριτάκι',47,NULL,0,NULL,'2026-09-17 10:49:05','2026-09-28 08:05:54','{title: Ρίτα Ριτάκι}

{verse: Verse}
Πα[G]λεύει το πο[Em]τάμι στη [C]θάλασσα να [D]βγει
Κι ο [G]ποιητής γυ[Em]ρεύει τη [C]μούσα του να [D]βρει
Το [G]κύμα ψάχνει [Em]να ''βρει την [C]άκρη του για[D]λού
[G]Κι εγώ γυρεύω ε[Em]σένανε
ε[Am]σένανε που [C]μ'' έστησες ξα[D]νά στο ραντε[A]βού

{verse: Verse}
Έ[G]ψαχνα να ''βρω [Em]το μπελά μου[C] και τελικά τον [D]βρήκα
Και [G]πήγα και α[Em]γάπησα έ[Am]να μωρό, τη [D]Ρίτα
[G]Ρίτα δεκαοχ[Em]τώ χρονών [Am]κι εγώ σαράντα [D]πέντε
[G]Ρίτα εσύ ''σαι [Em]στην αρχή [Am]κι εγώ στο παρα[D]πέντε

{verse: Chorus}
[G]Ρίτα-Ρι[Em]τάκι, [C]κανένα δε φο[D]βάσαι
[G]Ρίτα-Ρι[Em]τάκι, [C]τίποτα δε θυ[D]μάσαι
[G]Ρίτα-Ρι[Em]τάκι, [Am]απόψε πού κοι[D]μάσαι

{verse: Verse}
Μου [G]το ''χες πει πο[Em]λλές φορές ό[C]τι δε μ'' αγα[D]πούσες
Συ[G]γγνώμη, δεν κα[Em]τάλαβα ό[Am]τι το εννο[D]ούσες
Γι αυ[G]τό λοιπόν σε [Em]χαιρετώ [C]και φεύγω δίχως [D]λόγια
[G]Με το κεφάλι [Em]μου ψηλά [C]και την ψυχή στα [D]πόδια

{verse: Chorus}
[G]Ρίτα-Ρι[Em]τάκι, [C]κανένα δε φο[D]βάσαι
[G]Ρίτα-Ρι[Em]τάκι, [C]τίποτα δε θυ[D]μάσαι
[G]Ρίτα-Ρι[Em]τάκι, [Am]απόψε πού κοι[D]μάσαι',NULL),
	 ('Απόψε λέω να μην κοιμηθούμε',48,NULL,0,NULL,'2026-09-17 10:56:09','2026-09-28 08:06:20','{title: Απόψε λέω να μην κοιμηθούμε}

{verse: Chorus}
[C]Απόψε λέω να κάνουμε ένα [Dm]πάρτι
στην [F]άμμο με ρα[G]διάκι φορη[C]τό
[C]Στο λέω πως δε γουστάρω άλλος [Dm]να ''ρθει
Το [F]πάρτι είναι για [G]δύο, για μάς τους [C]δυο

{verse: Verse}
[C]Απόψε το φεγγάρι θα φο[Dm]ράει
το [F]φως απ'' τη δι[G]κή σου τη μορ[C]φή
[C]Το μόνο που θ'' ακούσεις να μι[Dm]λάει
θα ''ναι η [F]φωνή του βραδι[G]νού εκφωνη[C]τή

{verse: Chorus}
[F]Απόψε λέω [G]να μην κοιμη[C]θούμε
[F]Να πάμε κατευ[G]θείαν για δου[C]λειά
[A]Απόψε στ'' ακρογιάλι θα τη [Dm]βρούμε
Θα πιούμε όλες τις μπύρες αγκα[G]λιά

{verse: Verse}
[C]Θα φύγουμε απ'' το θόρυβο της [Dm]πόλης
μια [F]νύχτα που δεν [G]έζησε κα[C]νείς
[C]Απόψε θα ζηλέψει ο Κηλαη[Dm]δόνης
το [F]πάρτι που θα [G]κάνουμε ε[C]μείς

{verse: Chorus}
[F]Απόψε λέω [G]να μην κοιμη[C]θούμε
[F]Να πάμε κατευ[G]θείαν για δου[C]λειά
[A]Απόψε στ'' ακρογιάλι θα τη [Dm]βρούμε
Θα πιούμε όλες τις μπύρες αγκα[G]λιά

{verse: Verse}
[C]Απόψε και με λίγη φαντα[Dm]σία
θα [F]μοιάζει με φιλ[G]μάκι γαλλι[C]κό
[C]Χρειάζεται αυτή η διαδικα[Dm]σία
μήπως μπο[F]ρέσω και σου [G]πω το σ'' αγα[C]πώ

{verse: Chorus}
[F]Απόψε λέω [G]να μην κοιμη[C]θούμε
[F]Να πάμε κατευ[G]θείαν για δου[C]λειά
[A]Απόψε στ'' ακρογιάλι θα τη [Dm]βρούμε
Θα πιούμε όλες τις μπύρες αγκα[G]λιά',NULL),
	 ('Παραμυθάκι μου',50,NULL,0,NULL,'2026-09-17 12:38:48','2026-09-28 08:07:06','{title: Παραμυθάκι μου}

{verse: Verse}
[Am]Σου ''παν πως είμαι μπελαλής
[F]άντρας βαρύς και ντερτι[E]λής
δεν λογα[Dm]ριάζω, κι ούτε ρίχνω τεμε[F]νά    | 2x
δεν κάνω κράτει πουθε[E]νά                | 2x

{verse: Chorus}
[Dm]Παραμυ[Am]θάκι μου [E]μην με μα[Am]λώνεις
[Dm]παραθυ[Am]ράκι μου [E]μην μου σφα[Am]λάς
[Dm]παραμυ[Am]θάκι μου [E]μη βαλα[Am]ντώνεις
[Dm]και την καρ[Am]δούλα σου [E]μην την χα[Am]λάς

{verse: Verse}
[Am]Σου ''παν πως έδιωξα πολλές
[F]κι όταν αρχίνησες να [E]κλαις
σου ''παν να φύγεις από μένα μακριά    | 2x
λες και έχει η αγάπη γιατρειά         | 2x

{verse: Chorus}
[Dm]Παραμυ[Am]θάκι μου [E]μην με μα[Am]λώνεις
[Dm]παραθυ[Am]ράκι μου [E]μην μου σφα[Am]λάς
[Dm]παραμυ[Am]θάκι μου [E]μη βαλα[Am]ντώνεις
[Dm]και την καρ[Am]δούλα σου [E]μην την χα[Am]λάς',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Με ένα όνειρο τρελό',51,NULL,0,NULL,'2026-09-17 12:45:30','2026-09-28 08:07:20','{title: Με ένα όνειρο τρελό}

{verse: Verse}
[Am]Μ'' ένα όνειρο τρελό, όνειρο [Dm]απατηλό
ξεκι[F]νήσαμε κι οι δυο [E]μας
Και στου [Dm]δρόμου τα μισά σβήσαν [C]τ'' άστρα τα χρυσά
ξαφνι[Am]κά από τον [Dm]ουρανό  [Am]μας

{verse: Chorus}
[F]Ποια μοίρα με ζη[G]λεύει, ποιο μάτι φθονε[C]ρό
και [F]χάθηκε μια α[G]γάπη προτού να τη χα[F]ρώ
[F]Σαν πλοίο που ναυάγησε, σα [G]νούφαρο που μάδη[C]σε   | 2x
στης [F]λίμνης μέσα [C]το θολό νερό                   | 2x

{verse: Verse}
[Am]Με ελπίδες λιγοστές, έστω και [Dm]απατηλές
να γυ[F]ρίσεις περιμέ[E]νω
Ίσως [Dm]βγει αληθινό τ'' όνει[C]ρό μου το τρελό
τ'' όνει[Am]ρό μου το να[Dm]υαγισμέ[Am]νο

{verse: Chorus}
[F]Ποια μοίρα με ζη[G]λεύει, ποιο μάτι φθονε[C]ρό
και [F]χάθηκε μια α[G]γάπη προτού να τη χα[F]ρώ
[F]Σαν πλοίο που ναυάγησε, σα [G]νούφαρο που μάδη[C]σε   | 2x
στης [F]λίμνης μέσα [C]το θολό νερό                   | 2x',NULL),
	 ('Τα λερωμένα τα άπλυτα',43,NULL,0,NULL,'2026-09-17 12:51:42','2026-09-28 08:07:30','{title: Τα λερωμένα τα άπλυτα}

{verse: Verse}
[E]Τα λερωμένα, τ'' άπλυτα, τα παραπετα[Am]μέ---[E]να   ] 2x
[A]Μάσ'' τα και φύγε, [E]φίλε μου, δεν κάνεις πια για [Dm]μέ--[Am]να
[A]Μάσ'' τα και φύγε, [E]φίλε μου, δεν κάνεις πια για [Am]μέ---[E]να

{verse: Verse}
[E]Κοντά σε μένα έβγαλες τα μπατιρήμα[Am]τά [E]σου   ] 2x
[A]Να φύγεις τώρα [E]και θα δω τ'' αποτελέσμα[Dm]τά [Am]σου
[A]Να φύγεις τώρα [E]και θα δω τ'' αποτελέσμα[Am]τά [E]σου

{verse: Verse}
[E]Κάθε Σαββάτο εύρισκες τα ρούχα σου στην [Am]τρί[E]χα   ] 2x
[A]και την αχαριστία σου [E]για πληρωμή μου [Dm]εί[Am]χα
[A]και την αχαριστία σου [E]για πληρωμή μου [Am]εί[E]χα

{verse: Verse}
[E]Τα λερωμένα, τ'' άπλυτα δεν θα τα ξανα[Am]πλύ[E]νω   ] 2x
[A]και μη σε νοιάζει [E]στο εξής εγώ τι θ'' απο[Dm]γί[Am]νω
[A]και μη σε νοιάζει [E]στο εξής εγώ τι θ'' απο[Am]γί[E]νω',NULL),
	 ('Έκλαψα χθες',14,NULL,0,NULL,'2026-09-17 12:56:47','2026-09-28 08:07:57','{title: Έκλαψα χθες}
{verse: Intro}
[Am] [Dm] [E] [Am] [F] [Dm] [E] [Am]

{verse: Verse}
[Am]Έκλαψα χθες σαν μέτρησα τις [F]πίκρες της ψυχής [C]μου
κι [Am]εσύ δεν [E]ήσουν πλάι [Dm]μου, αστέρι της ζωής [Am]μου
κι [Am]εσύ δεν [E]ήσουν πλάι [Dm]μου, αστέρι [Am]της [E]ζωής [Am]μου

{verse: Verse}
[Am]Έκλαψα χθες σαν μέτρησα τις [F]νύχτες που είμαι μό[C]νος
Τις [Am]νύχτες [E]που σ'' αναζη[Dm]τώ και με καρφώνει ο πό[Am]νος
Τις [Am]νύχτες [E]που σ'' αναζη[Dm]τώ και με καρ[Am]φώνει ο [E]πό[Am]νος',NULL),
	 ('Let it be',52,NULL,0,NULL,'2026-09-17 13:22:39','2026-09-28 07:30:21','{title: Let it be}
{verse: Intro}
[C] [G] [Am] [F] [C] [G] [F] [C] [Dm] [C]

{verse: Verse}
[C]When I find myself in [G]times of trouble, [Am]Mother Mary [F]comes to me
[C]Speaking words of [G]wisdom, let it [F]be[C]
And in my hour of [G]darkness, she is [Am]standing right in [F]front of me
[C]Speaking words of [G]wisdom, let it [F]be[C]
 
{verse: Chorus}
Let it [Am]be, let it [G]be, let it [F]be, let it [C]be
Whisper words of [G]wisdom, let it [F]be[C]
 
{verse: Verse}
[C]And when the broken [G]hearted people, [Am]living in the [F]world agree
[C]There will be an [G]answer, let it [F]be[C]
For though they may be [G]parted, there is [Am]still a chance that [F]they will see
[C]There will be an [G]answer, let it [F]be[C]
 
{verse: Chorus}
Let it [Am]be, let it [G]be, let it [F]be, let it [C]be
[C]There will be an [G]answer, let it [F]be[C]
Let it [Am]be, let it [G]be, let it [F]be, let it [C]be
Whisper words of [G]wisdom, let it [F]be[C]
 
{verse: Verse}
And [C]when the night is [G]cloudy,
There is [Am]still a light that [F]shines on me
[C]Shine on till to[G]morrow, let it [F]be[C]
[C]I wake up to the [G]sound of music, [Am]Mother Mary co[F]mes to me
[C]Speaking words of [G]wisdom, let it [F]be[C]
 
{verse: Chorus}
Let it [Am]be, let it [G]be, let it [F]be, let it [C]be
[C]There will be an [G]answer, let it [F]be[C]
Let it [Am]be, let it [G]be, let it [F]be, let it [C]be
Whisper words of [G]wisdom, let it [F]be[C]',NULL),
	 ('Γύφτισσα μέρα',14,NULL,0,NULL,'2026-09-17 13:43:47','2026-09-28 08:08:11','{title: Γύφτισσα μέρα}

{verse: Verse}
[Am]Γύφτισσα μέρα [E]στο παλιό μουράγιο
[Am]βλέπω τη θάλασσα [E]χωρίς [Am]κουράγιο
[F]Βλέπω τα βράχια κι έχω μια [C]λύπη    | 2x
[Dm]την Κυριακή αυτή [E]κάτι μου [Am]λείπει   | 2x

{verse: Chorus}
[F]Άσπρα βότσαλα [E]στον ήλιο [F]και στη θάλα[E]σσα   | 2x
την καρ[Dm]διά μου κυρια[Am]κάτικα την χάλασα     | 2x

{verse: Verse}
[Am]Γύφτισσα τύχη [E]πες μου τι με σώνει
[Am]τ'' απομεσήμερο, για [E]δες, ζυ[Am]γώνει
[F]Γύφτισσα μέρα στο γυμνό κορ[C]μί σου    | 2x
[DM]στην αμμουδιά να κυλι[E]στώ μα[Am]ζί σου   | 2x

{verse: Chorus}
[F]Άσπρα βότσαλα [E]στον ήλιο [F]και στη θάλα[E]σσα   | 2x
την καρ[Dm]διά μου κυρια[Am]κάτικα την χάλασα     | 2x',NULL),
	 ('Γειτονάκι μου',14,NULL,0,NULL,'2026-09-17 13:48:43','2026-09-28 08:08:36','{title: Γειτονάκι μου}

{verse: Verse}
[Am]Tη νύχτα που κοιμούνται τα πουλιά
[Dm]βγαίνουν κάτι έρημα παι[F]διά
[E]κι έρχονται στη πόρτα σου κρυ[Am]φά
[Am]T'' αστέρια που κοιτούν από ψηλά
[Dm]ξαγρυπνούν μαζί με τα παι[F]διά
[E]και σου νανουρίζουν τη καρ[Am]διά [G]

{verse: Chorus}
[C]Γειτονάκι [Dm]μου, [F]στη μικρή σου [C]πόρτα
[C]αστεράκι [Dm]μου, [C]ξενύχτησα κι ε[G]γώ
[C]αδερφάκι [Dm]μου, [F]το φεγγάρι [C]ρώτα
[C]γειτονάκι [Dm]μου, αχ [C]πόσο σ'' αγαπώ [E]

{verse: Verse}
[Am]Tην ώρα που γυρνώ απ'' τη δουλειά
[Dm]κάνω όρκο μέσα μου βα[F]θιά
[E]να μη ''ρθω στη πόρτα σου ξα[Am]νά
[Am]Mα όταν πέσει πάλι η νυχτιά
[Dm]η παλιά λαχτάρα μου ξυ[F]πνά
[E]και μου τυραννάει την καρ[Am]διά [C]

{verse: Chorus}
[C]Γειτονάκι [Dm]μου, [F]στη μικρή σου [C]πόρτα
[C]αστεράκι [Dm]μου, [C]ξενύχτησα κι ε[G]γώ
[C]αδερφάκι [Dm]μου, [F]το φεγγάρι [C]ρώτα
[C]γειτονάκι [Dm]μου, αχ [C]πόσο σ'' αγαπώ [E] | 2x',NULL),
	 ('Δελφίνι δελφινάκι',50,NULL,0,NULL,'2026-09-17 13:54:00','2026-09-28 08:08:52','{title: Δελφίνι δελφινάκι}

{verse: Verse}
[C]Καβάλα στο δελ[G]φίνι τον [F]κόσμο γύρι[C]σα
[Am]Είπα να σε ξε[Dm]χάσω, μα [G]σ'' αποθύμη[C]σα, σ'' απο[F]θύμη[C]σα

{verse: Chorus}
[C]Δελφίνι, δελφι[Dm]νάκι, [G]πά[F]με [C]πιο γρήγορα, πάμε πιο γρήγορα
[C]Να δω τα γυρι[Dm]στά της [G]τα [F]ματο[C]τσίνορα, τα ματοτσίνορα

{verse: Verse}
[C]Όπου και να γυρ[G]νούσα, ε[F]ρχόσουν πίσω [C]μου
[Am]λαβωματιά στο [Dm]στήθος το [G]πελαγί[C]σιο μου, πελα[F]γίσιο [C]μου

{verse: Chorus}
[C]Δελφίνι, δελφι[Dm]νάκι, [G]πά[F]με [C]πιο γρήγορα, πάμε πιο γρήγορα
[C]Να δω τα γυρι[Dm]στά της [G]τα [F]ματο[C]τσίνορα, τα ματοτσίνορα',NULL),
	 ('Το ακορντεόν',53,NULL,0,NULL,'2026-09-17 13:57:48','2026-09-28 08:09:00','{title: Το ακορντεόν}

{verse: Verse}
[D]Στη γειτονιά μου την παλιά είχα ένα [G]φίλο
που ήξε[D]ρε και έπαι[A]ζε τ'' ακορντε[D]όν
[D]Όταν τραγούδαγε, φτυστός ήταν ο [G]ήλιος
φωτιές στα [D]χέρια του άνα[A]βε τ'' ακορντε[G]όν

{verse: Verse}
[D]Μα ένα βράδυ σκοτεινό σαν όλα τ'' [G]άλλα
κράταγε [D]τσίλιες παίζο[A]ντας ακορντε[D]όν
[D]Γερμανικά καμιόνια στάθηκαν στη [G]μάντρα
και μια ρι[D]πή σταμάτησε τ'' ακορντεόν

{verse: Verse}
[D]Τ'' αρχινισμένο σύνθημα πάντα μου [G]μένει
όποτε α[D]κούω από [A]τότε ακορντε[D]όν
[D]Κι έχει σα στάμπα τη ζωή μου σημα[G]δέψει    | 2x
Δεν θα πε[D]ρά-, δεν θα πε[A]ράσει ο φασι[D]σμός   | 2x',NULL),
	 ('Κάποτε θαρθουν να σου πουν',2,NULL,0,NULL,'2026-09-17 14:04:05','2026-10-07 08:35:37','{title: Κάποτε θαρθουν να σου πουν}
{verse: Intro}
[Am] [Dm] [G] [C] [F] [E]

{verse: Verse}
[Am]Κάποτε θα ''ρθουν να σου [Dm]πουν
πως σε πι[G]στεύουν, σ'' αγα[C]πούν
και [F]πως σε [E]θέ[Am]νε

{verse: Chorus}
[F]Έχε το νου σου στο παι[C]δί
[F]κλείσε την πόρτα με [E]κλειδί
ψέματα λέ[Am]νε

{verse: Verse}
[Am]Κάποτε θα ''ρθουν γνωστι[Dm]κοί
λογάδες [G]και γραμματι[C]κοί
για [F]να σε [E]πεί[Am]σουν

{verse: Chorus}
[F]Έχε το νου σου στο παι[C]δί
[F]κλείσε την πόρτα με [E]κλειδί
θα σε πουλή[Am]σουν

{verse: Verse}
[Am]Και όταν θα ''ρθουν οι και[Dm]ροί
που θα'' χει [G]σβήσει το κε[C]ρί
στην [F]καται[E]γί[Am]δα

{verse: Chorus}
Υπερα[F]σπίσου το παι[C]δί
[F]γιατί αν γλιτώσει το παι[E]δί
υπάρχει ελπί[Am]δα',NULL),
	 ('Αθήνα μου',54,NULL,0,NULL,'2026-09-18 08:04:10','2026-10-12 12:44:18','{title: Αθήνα μου}
{verse: Intro}
[Am] [C] [G] [Dm] [F] [G] [Am]

{verse: Verse}
Χαμένος [Am]κάπου στα στενά προς Φιλοπάππου
εδώ που η [C]πόλη καταφέρνει να [G]μην βιάζεται
στο κέντρο [Dm]άρχισε ο γύρος του θανάτου, βράδυ [E]Σαββάτου
Ένας [Am]αέρας να τρυπάει το κορμί μου, εγώ βρε[C]γμένος πιο πολύ απ'' την [G]καμπαρτίνα μου
[Dm]μα σε ψάχνω απεγνωσμένα [F]στην Α[G]θήνα [Am]μου

{verse: Verse}
Από το [Am]πάρκο με έχει πάρει το ντουμάνι
απ'' τα μπα[C]λκόνια γιασεμί και νυχτο[G]λούλουδα
μια ξε[Dm]κούρδιστη λατέρνα ίσα που πιάνει το Τσι[E]τσάνη
Τόσα [Am]χρόνια κάθε βράδυ και δε φτάνει
κάποιος [C]θα έλεγε πως έγινε ρου[G]τίνα μου
[Dm]μα σε ψάχνω απεγνωσμένα [F]στην Α[G]θήνα [Am]μου

{verse: Verse}
Λύκος στη [Am]νύχτα η μοναξιά μου που ουρλιάζει
απόψε [C]μέχρι και ο καιρός μαζί μου [G]τα ''βαλε
και αφού η [Dm]βροχή ποτέ δεν έγινε χαλάζι, γλυκο[E]χαράζει
Έχουν [Am]περάσει μήνες που είσαι μακριά μου
και έχει θο[C]λώσει η κούκλα που είχα στη [G]βιτρίνα μου
[Dm]μα σε ψάχνω απεγνωσμένα [F]στην Α[G]θήνα [Am]μου

{verse: Verse}
Χτυπάει η [Am]καμπάνα πένθιμα του Λουμπαρδιάρη
σα να μου [C]λέει πως και σήμερα το [G]χάσαμε
έχει γυ[Dm]ρίσει στη φωλιά του το φεγγάρι και εγώ [E]χαμπάρι
Σ'' ένα πα[Am]γκάκι με τα χέρια μαξιλάρι
με έχει δε[C]μένο το μυαλό στη γκιλο[G]τίνα μου
[Dm]μα σε ψάχνω απεγνωσμένα [F]στην Α[G]θήνα [Am]μου

{verse: Verse}
Λύκος στη [Am]νύχτα η μοναξιά μου που ουρλιάζει
απόψε [C]μέχρι και ο καιρός μαζί μου [G]τα ''βαλε
και αφού η [Dm]βροχή ποτέ δεν έγινε χαλάζι, γλυκο[E]χαράζει
Έχουν [Am]περάσει μήνες που είσαι μακριά μου
και έχει θο[C]λώσει η κούκλα που είχα στη [G]βιτρίνα μου
[Dm]μα σε ψάχνω απεγνωσμένα [F]στην Α[G]θήνα [Am]μου
[Dm]μα σε ψάχνω απεγνωσμένα [F]στην Α[G]θήνα [Am]μου',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Ο προσκυνητής',61,NULL,0,NULL,'2026-09-18 10:21:39','2026-09-28 08:13:17','{title: Ο προσκυνητής}
{verse: Intro}
[F] [Am]

{verse: Verse}
[Am]Τα βουνά περνάω [F]και της θάλασσες περ[Am]νώ
κάποιον αγαπάω[F]
[Am]Δυο ευχές κρατάω [F]και δυο τάματα κρα[Am]τώ
περπατώ και [F]πάω

{verse: Chorus}
[Dm]Κάποιος είπε πως η [Am]αγάπη σ'' ένα αστέρι κατοι[Em]κεί
αύριο βράδυ θα ''μαι [F]κει
[Dm]Κάποιος είπε πως ο [Am]έρωτας για μια στιγμή κρα[Em]τά
αύριο βράδυ θα ''ναι αρ[Am]γά

{verse: Interlude}
[F] [Am] [F]

{verse: Verse}
[Am]Στα πουλιά μιλάω [F]και στα δέντρα τραγου[Am]δώ
κάποιον αγαπάω[F]
[Am]Κι όταν τραγουδάω [F]προσευχές παραμι[Am]λώ
περπατώ και [F]πάω

{verse: Chorus}
[Dm]Κάποιος είπε πως ο [Am]δρόμος είναι η φλέβα της φω[Em]τιάς
ψυχή μου πάντα να κυ[F]λάς
[Dm]Κάποιος είπε πως τα[Am]ξίδι είναι μόνο η προσευ[Em]χή
καρδιά μου να ''σαι ζωντα[F]νή

{verse: Outro}
[F] [Am] [F]',NULL),
	 ('Μου σπάσανε τον μπαγλαμά',40,NULL,0,NULL,'2026-09-18 08:11:05','2026-09-28 08:10:10','{title: Μου σπάσανε τον μπαγλαμά}

{verse: Verse}
[Am]Μου σπάσανε [E]το μπαγλα[Am]μά, κάτι παλιόμα[E]γκες εχτές αρ[Am]γά
[Dm]το σκάσανε και φύγα[Am]νε,  τα τέλια μ'' [E]απομείνα[Am]νε

{verse: Chorus}
[Am]Ντρίγκι ντρίγκι, ντρίγκι ντρίγκι [A]μου ''διωχνε τον [Dm]πόνο
[E]Ντρίγκι ντρίγκι και κυλούσε η παλιοζω[Am]ή
[Am]Ντρίγκι ντρίγκι, (4x) [A]μου ''διωχνε τον [Dm]πόνο
[E]Ντρίγκι ντρίγκι και κυλούσε η παλιοζω[Am]ή

{verse: Verse}
[Am]Τον είχα σαν [E]μικρό παι[Am]δί και βασιλιά [E]μες στο τσαρ[Am]δί
[Dm]Αυτός με παρηγόρα[Am]γε, αυτός με [E]καταλάβαι[Am]νε

{verse: Chorus}
[Am]Ντρίγκι ντρίγκι, ντρίγκι ντρίγκι [A]μου ''διωχνε τον [Dm]πόνο
[E]Ντρίγκι ντρίγκι και κυλούσε η παλιοζω[Am]ή
[Am]Ντρίγκι ντρίγκι, (4x) [A]μου ''διωχνε τον [Dm]πόνο
[E]Ντρίγκι ντρίγκι και κυλούσε η παλιοζω[Am]ή

{verse: Verse}
[Am]Με τις γλυκές [E]του τις πε[Am]νιές μου γιάτρευε [E]πολλές πλη[Am]γές
[Dm]Τώρα στο έρμο μου τσαρ[Am]δί, αχ ποιος θα [E]με παρηγο[Am]ρεί

{verse: Chorus}
[Am]Ντρίγκι ντρίγκι, ντρίγκι ντρίγκι [A]μου ''διωχνε τον [Dm]πόνο
[E]Ντρίγκι ντρίγκι και κυλούσε η παλιοζω[Am]ή
[Am]Ντρίγκι ντρίγκι, (4x) [A]μου ''διωχνε τον [Dm]πόνο
[E]Ντρίγκι ντρίγκι και κυλούσε η παλιοζω[Am]ή',NULL),
	 ('Χθες το βράδυ στην ταβέρνα',44,NULL,0,NULL,'2026-09-18 08:45:51','2026-09-28 08:10:30','{title: Χθες το βράδυ στην ταβέρνα}

{verse: Verse}
[Bm]Χθες το βράδυ στην ταβέρνα ήμουν σκεπτικός
Καθι[Em]σμένος στη γωνιά μου, μελαγχολικός
Γέμι[D]ζα το ποτηράκι και το έπινα
Και σκε[Em]πτόμουνα πως ήμουν και πως έγι[Bm]να

{verse: Chorus}
Ζούσα μια [Bm]ξέγνοιαστη ζωή πριν σε γνωρίσω
Προτού μ'' α[Em]νάψεις τη φωτιά μες τη καρδιά
Μες την τα[A]βέρνα τώρα βρίσκομαι για [Dm]σένα
Πίνω μα [Bm]η σκέψη μου σε σένα τριγυρνά

{verse: Verse}
Με έχουν [Bm]χάσει οι δικοί μου και οι φίλοι μου
Και το [Em]γέλιο έχει σβήσει απ'' τα χείλη μου
Την [D]ταβέρνα τώρα έχω μόνη συντροφιά
Και για [Em]σένανε δε θέλω να μου λένε [Bm]πια

{verse: Chorus}
Ζούσα μια [Bm]ξέγνοιαστη ζωή πριν σε γνωρίσω
Προτού μ'' α[Em]νάψεις τη φωτιά μες τη καρδιά
Μες την τα[A]βέρνα τώρα βρίσκομαι για [Dm]σένα
Πίνω μα [Bm]η σκέψη μου σε σένα τριγυρνά',NULL),
	 ('Κόκκινο γαρύφαλο',9,NULL,0,NULL,'2026-09-18 08:53:46','2026-09-28 08:10:47','{title: Κόκκινο γαρύφαλλο}

{verse: Verse}
[G]Για να με γνωρίσεις μες στο [D]πλήθος
[Em]φόρεσα γαρύφαλλο στο [Bm]στήθος
[C]από μια γιορ[D]τή που μόλις [G]τέλειωσε
[C]μια γιορτή που [D]δίστασες να [G]πας

{verse: Chorus}
[G]Κόκκινο γα[D]ρύφαλλο, κόκκινο γα[G]ρύφαλλο
πάνω στο που[C]κάμισο, στο [D]μέρος της καρ[G]διάς
[G]Κόκκινο γα[D]ρύφαλλο, κόκκινο γα[G]ρύφαλλο
πάρ'' το από το [C]στήθος μου, ε[D]λπίδες να κρα[G]τάς

{verse: Verse}
[G]Ρώτησα χαμένη μες στο [D]πλήθος
[Em]ποιος φοράει γαρύφαλλο στο [Bm]στήθος
[C]κι ήρθα να το [D]πάρω με τα [G]χέρια μου
[C]είναι αυτά [D]τα χέρια που αγα[G]πάς

{verse: Chorus}
[G]Κόκκινο γα[D]ρύφαλλο, κόκκινο γα[G]ρύφαλλο
πάνω στο που[C]κάμισο, στο [D]μέρος της καρ[G]διάς
[G]Κόκκινο γα[D]ρύφαλλο, κόκκινο γα[G]ρύφαλλο
πάρ'' το από το [C]στήθος μου, ε[D]λπίδες να κρα[G]τάς',NULL),
	 ('Το σημάδι',9,NULL,0,NULL,'2026-09-18 09:02:04','2026-09-28 08:11:35','{title: Το σημάδι}

{verse: Verse}
[G]Θέλω να κρύψω την αλήθεια πως με είχες όλη νύχτα
τον τρε[D]λό στην αγκα[G]λιά σου
και ο ι[D]δρώτας της α[C]γάπης
είχε [G]κάτι από φωτιά

{verse: Verse}
[G]Θέλω να κρύψω πως ξημέρωνε και ήμουνα
α[D]κόμα στα φι[G]λιά σου
και ''γώ σου [D]κάρφωσα τον [C]ήλιο
πριν να [G]φύγω στα μαλλιά

{verse: Chorus}
Μα το ση[Em]μάδι στο λαιμό μου απ'' τα φι[C]λιά σου
θα μαρτυ[D]ράει πως με είχες αγκα[G]λιά σου
μα το ση[Em]μάδι στο λαιμό μου που θα [C]μένει
θα μαρτυ[D]ράει πως δεν είμαστε δύο [G]ξένοι

{verse: Verse}
[G]Θέλω να κρύψω στο κορμί μου τις γραμμές από τα χέρια
που γλυ[D]κά με τυρα[G]ννούσαν
κι αυτή την [D]φλέβα που χτυ[C]πούσε
όλη [G]νύχτα στο λαιμό

{verse: Verse}
[G]Θέλω να κρύψω όσα είπαμε την ώρα
που από [D]πόθο σε ζη[G]τούσα
και πως χα[D]νόμουνα α[C]πόψε
σ'' ένα [G]δρόμο αμαρτωλό

{verse: Chorus}
Μα το ση[Em]μάδι στο λαιμό μου απ'' τα φι[C]λιά σου
θα μαρτυ[D]ράει πως με είχες αγκα[G]λιά σου
μα το ση[Em]μάδι στο λαιμό μου που θα [C]μένει
θα μαρτυ[D]ράει πως δεν είμαστε δύο [G]ξένοι',NULL),
	 ('Το φιλαράκι',55,NULL,0,NULL,'2026-09-18 09:16:25','2026-09-28 08:11:36','{title: Το φιλαράκι}

{verse: Verse}
[Am]Στο τηλέφωνο φο[G]βάμαι να σε πάρω να σου[F] πω πόσο [G]μόνη νιώθω
[Am]Στους διαδρόμους του μυα[G]λού μου τώρα σε αναζη[F]τώ με με[G]γάλο πόθο

{verse: Verse}
[F]Δε την βρίσκω την [G]άκρη πουθε[C]νά και πες μου [Am]τι να κάνω
[F]Έχω γεμίσει ασφυκτι[G]κά με κα[C]πνό το δωμάτιο [Am]ως απάνω
και ο [Dm]χρόνος μου γε[G]λάει σαν μω[C]ρό

{verse: Chorus}
[F]Πού να γείρω το κορ[G]μί μου όταν γυρ[C]νάω απ'' τα μπαρ [Am]κι απ'' τα ξενύχτια
[F]Πού να βρω ένα φιλα[G]ράκι να μου [C]πει πως μ'' α[Am]γαπάει στ'' αλήθεια,
αφού κι [Dm]εσύ έχεις [G]εξαφανι[C]στεί

{verse: Verse}
[Am]Μοιάζει η νύχτα μακρι[G]ά σου να ''ναι ερεθιστι[F]κή σαν την [G]αμαρτία
[Am]Μα η μορφή σου δραπε[G]τεύει από κρυψώνα μυστι[F]κή με χτυ[G]πά με βία

{verse: Verse}
[F]Δε την βρίσκω την [G]άκρη πουθε[C]νά και πες μου [Am]τι να κάνω
[F]Έχω γεμίσει ασφυκτι[G]κά με κα[C]πνό το δωμάτιο [Am]ως απάνω
και ο [Dm]χρόνος μου γε[G]λάει σαν μω[C]ρό

{verse: Chorus}
[F]Πού να γείρω το κορ[G]μί μου όταν γυρ[C]νάω απ'' τα μπαρ [Am]κι απ'' τα ξενύχτια
[F]Πού να βρω ένα φιλα[G]ράκι να μου [C]πει πως μ'' α[Am]γαπάει στ'' αλήθεια,
αφού κι [Dm]εσύ έχεις [G]εξαφανι[C]στεί

{verse: Verse}
[Am]Κι ούτε συ έχεις τη [G]λύση να μου δώσεις που γυ[F]ρεύω τη [G]λύση που ζητάω
[Am]Μπλοκαρισμένος από [G]χρόνια στα δικά σου τα γρα[F]νάζια που για [G]μέρες τραγουδάω

{verse: Verse}
[F]Δε την βρίσκω την [G]άκρη πουθε[C]νά και πες μου [Am]τι να κάνω
[F]Έχω γεμίσει ασφυκτι[G]κά με κα[C]πνό το δωμάτιο [Am]ως απάνω
και ο [Dm]χρόνος μου γε[G]λάει σαν μω[C]ρό

{verse: Chorus}
[F]Πού να γείρω το κορ[G]μί μου όταν γυρ[C]νάω απ'' τα μπαρ [Am]κι απ'' τα ξενύχτια
[F]Πού να βρω ένα φιλα[G]ράκι να μου [C]πει πως μ'' α[Am]γαπάει στ'' αλήθεια,
αφού κι [Dm]εσύ έχεις [G]εξαφανι[C]στεί',NULL),
	 ('Το φλασάκι',56,NULL,0,NULL,'2026-09-18 09:35:42','2026-09-28 08:11:54','{title: Το φλασάκι}

{verse: Verse}
[G]Μελαγχόλησε......ες,      νιώθεις πεταμένος
Μες στην πόλη σου σα ξένος, βρε παι[Bm]δί μου αμάν
Στην καρ[Am]διά βάλε πατίνια [D] και δυο ρουλε[G]μάν

{verse: Verse}
Φύλλο [G]και φτερό......o,       στο μυαλό σου χιόνι
που τη σκέψη σου παγώνει, βρε παι[Bm]δί μου αμάν
Στην καρ[Am]διά βάλε πατίνια [D] και δυο ρουλε[G]μάν

{verse: Chorus}
[C]Βάλε στο μαγνητόφωνο τρα[G]γούδια που γουστάρεις
[C]Σκέψου την ώρα, τη στιγμή που [G]τη ρεβάνς θα πάρεις
[C]Σκέψου κορίτσια και γιορτές και [Am]πράμα που σαλεύει
[Em]κι ένα παιδί που μοναχό το [D]δρόμο του γυρεύει

{verse: Verse}
Κάτι [G]άστραψε......ε,      κάτι σα φλασάκι
Σα πικ-νικ μες στο δασάκι, μια γλυ[Bm]κιά φωτιά
Λάβε [Am]θέση για να πάρεις [D] πάλι την πρω[G]τιά

{verse: Verse}
Σα να [G]δρόσισε.......ε,       έρχεται βροχούλα
και μια άνοιξη νυφούλα, βρε παι[Bm]δί μου αμάν
Στην καρ[Am]διά βάλε πατίνια [D] και δυο ρουλε[G]μάν

{verse: Chorus}
[C]Βάλε στο μαγνητόφωνο τρα[G]γούδια που γουστάρεις
[C]Σκέψου την ώρα, τη στιγμή που [G]τη ρεβάνς θα πάρεις
[C]Σκέψου κορίτσια και γιορτές και [Am]πράμα που σαλεύει
[Em]κι ένα παιδί που μοναχό το [D]δρόμο του γυρεύει',NULL),
	 ('Μην τον ρωτάς τον ουρανό',57,NULL,0,NULL,'2026-09-18 09:40:53','2026-09-28 08:12:09','{title: Μην τον ρωτάς τον ουρανό}

{verse: Verse}
Λόγο στο [Am]λόγο και ξεχα[G]στήκαμε
μάς πήρε ο [Am]πόνος και νυχτω[G]θήκαμε
Σβήσε το [F]δάκρυ με το μα[C]ντήλι σου
να πιω τον [Dm]ήλιο μέσα απ'' τα [Am]χείλη σου [G]

{verse: Chorus}
[C]Mην τον ρωτάς τον ουρανό
το σύννεφο και το [G]φεγγάρι
[Am]το βλέμμα σου το σκοτεινό
κάτι απ'' τη νύχτα έχει [E]πάρει

{verse: Verse}
Ό,τι μάς [Am]βρήκε κι ό,τι μάς [G]λύπησε
σαν το μα[Am]χαίρι σκληρά μάς [G]χτύπησε
Kρύψε το [F]δάκρυ με το μα[C]ντήλι σου
να πιω τον [Dm]ήλιο μεσ'' απ τα [Am]χείλη σου [G]

{verse: Chorus}
[C]Mην τον ρωτάς τον ουρανό
το σύννεφο και το [G]φεγγάρι
[Am]το βλέμμα σου το σκοτεινό
κάτι απ'' τη νύχτα έχει [E]πάρει',NULL),
	 ('Μια αγάπη για το καλοκαίρι',58,NULL,0,NULL,'2026-09-18 09:45:48','2026-09-28 08:12:15','{title: Μια αγάπη για το καλοκαίρι}

{verse: Verse}
[Am]Μια αγάπη για το καλο[Em]καίρι θα ''μαι και [Am]γω
Να σου κρα[Em]τώ δροσιά στο [F]χέρι, να σε φι[Am]λώ
Θα μ'' αγαπάς σαν καλο[G]καίρι και σαν παι[C]δί
Μα θα μου [Am]φύγεις με τ'' α[E]γέρι και τη βρο[Am]χή
Θα μ'' αγαπάς σαν καλο[G]καίρι και σαν παι[C]δί
Μα θα μου [Am]φύγεις με τ'' α[E]γέρι και τη βρο[Am]χή

{verse: Verse}
[Am]Μια αγάπη για το καλο[Em]καίρι θα ''μαι και ''[Am]γω
Να σου κρα[Em]τώ δροσιά στο [F]χέρι, να σε φι[Am]λώ
Και σαν χαθεί το καλο[G]καίρι και σε ζη[C]τώ
θα μείνει [Am]μόνο ένα α[E]στέρι να το κοι[Am]τώ
Και σαν χαθεί το καλο[G]καίρι και σε ζη[C]τώ
θα μείνει [Am]μόνο ένα α[E]στέρι να το κοι[Am]τώ',NULL),
	 ('Πάρε με απόψε',59,NULL,0,NULL,'2026-09-18 10:00:43','2026-10-16 12:22:40','{title: Πάρε με απόψε}

{verse: Verse}
[Em]Πέφτουν τα [D]ψέματα βρο[Em]χή, [G]μα η αλήθεια σώ[Em]ζει
[C]Κι η μόνη αλήθεια [D]είσαι ε[Am]σύ, [D] η πιο γλυ[G]κιά ανταμοι[B7]βή
[Em]Εδώ οι κα[D]κίες ντύνο[Em]νται [G] λευκό αγγέλου ντύ[Em]μα
[C]Πάρε με απόψε [D]πάρε [Em]με, [G]ζεστό α[D]γάπης κύ[B7]μα

{verse: Verse}
[Em]Και σε περι[D]μέ[Em]νω, [D]τσιγάρο αναμμέ[Em]νο
Και σε περι[D]μέ[C]νω, στην αγκα[D]λιά σου να σω[Em]θώ

{verse: Verse}
[Em]Λυσσομα[D]νάει ο άνε[Em]μος, [G]  μα ο άνεμος δεν ξέ[Em]ρει
[C]Πως το κορίτσι [D]που θα ''[Em]ρθει [G] την άνοι[D]ξη θα φέ[B7]ρει

{verse: Chorus}
[Em]Και σε περι[D]μέ[Em]νω, [D]τσιγάρο αναμμέ[Em]νο
Και σε περι[D]μέ[C]νω, σαν ακρο[D]γυάλι ν'' ανοι[Em]χτώ 
 
[Em]Και σε περι[D]μέ[Em]νω, [D]τσιγάρο αναμμέ[Em]νο

[Em]Και σε περι[D]μένω [C]
[C]πάρε με α[D]πόψε πάρε [G]με
[C]στα μαγι[D]κά φτερά [G]σου
[C]βάλε με α[D]πόψε βάλε [G]με [B7]
[C]μέσα στην [D]αγκαλιά [Em]σου',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Μια φορά θυμάμαι',60,NULL,0,NULL,'2026-09-18 10:12:53','2026-09-28 08:12:50','{title: Μια φορά θυμάμαι}

{verse: Verse}
[Em]Νύχτα βροχερή κι άδειο το [Bm]χέρι
[Em]Ψάχνει να σε βρει, μα δεν το [D]ξέρει
πού θα σε [G]βρει [B]

{verse: Chorus}
[E]Μια φορά θυμάμαι μ'' αγα[F]πούσες
Τώρα βρο[E]χή
Μια φορά θυμάμαι μου μι[F]λούσες
[Em]Τώρα σιωπή

{verse: Verse}
[Em]Πέτρωσε η φωνή και πώς να [Bm]κλάψει
[Em]Που ''φυγες εσύ, έχουν α[D]νάψει
χίλιοι καη[G]μοί [B]

{verse: Chorus}
[E]Μια φορά θυμάμαι μ'' αγα[F]πούσες
Τώρα βρο[E]χή
Μια φορά θυμάμαι μου μι[F]λούσες
[Em]Τώρα σιωπή

{verse: Verse}
[Em]Θα ''ρθει το πρωί και θα πε[Bm]ράσει
[Em]Θα με λυπηθεί, θα με ξε[D]χάσει
όπως και [G]συ[B]

{verse: Chorus}
[E]Μια φορά θυμάμαι μ'' αγα[F]πούσες
Τώρα βρο[E]χή
Μια φορά θυμάμαι μου μι[F]λούσες
[Em]Τώρα σιωπή',NULL),
	 ('Φεύγω',68,NULL,0,NULL,'2026-11-06 08:56:44','2026-11-06 08:56:44','{title: Φεύγω}
{verse: Verse}
[Am]Kάποτε έχτιζα ένα όνειρο τη μέρα
[G]τώρα η στράτα μου δεν πάει παραπέρα
[F]φεύγω, [Em]τώρα [Am]φεύγω
 
{verse: Verse}
[Am]Kάποτε κοίταζα τον ήλιο μέσ'' τα μάτια
[G]κι αυτόν τον ήλιο μου τον κάνανε κομμάτια
[F]φεύγω, [Em]τώρα [Am]φεύγω
 
{verse: Verse}
[Am]Tώρα ο ουρανός δεν με φοβίζει όσο κι αν βρέχει
[G]τώρα η ελπίδα μου ταυτότητα δεν έχει
[F]φεύγω, [Em]τώρα [Am]φεύγω
 
{verse: Chorus}
[F]Φεύγω, φεύγω και παίρνω την [Em]καρδιά μου
κι ένα τραγούδι [F]συντροφιά μου, [Dm]φεύγω, [Am]φεύγω
[F]Φεύγω, κι αφήνω πίσω μου [Em]συντρίμμια
αρρωστημένους [F]και αγρίμια, [Dm]φεύγω, [Am]φεύγω
[F]φεύγω, [Em]τώρα [Am]φεύγω
 
{verse: Verse}
[Am]Δεν το αντέχω να βουλιάζω μέσ'' το ψέμα
[G]τώρα κατάλαβα πως ήμουν ένα δέμα
[F]φεύγω, [Em]τώρα [Am]φεύγω
 
{verse: Verse}
[Am]Θέλω να ζήσω τη ζωή μου έξω απ'' τα μέτρα
[G]τώρα που σκλήρυν'' η καρδιά μου σαν την πέτρα
[F]φεύγω, [Em]τώρα [Am]φεύγω
 
{verse: Verse}
[Am]Tώρα ο κόσμος κι οι φωνές δεν με τρομάζουν
[G]τώρα τα χέρια μου ένα σύνθημα χαράζουν
[F]φεύγω, [Em]τώρα [Am]φεύγω

{verse: Chorus}
[F]Φεύγω, φεύγω και παίρνω την [Em]καρδιά μου
κι ένα τραγούδι [F]συντροφιά μου, [Dm]φεύγω, [Am]φεύγω
[F]Φεύγω, κι αφήνω πίσω μου [Em]συντρίμμια
αρρωστημένους [F]και αγρίμια, [Dm]φεύγω, [Am]φεύγω
[F]φεύγω, [Em]τώρα [Am]φεύγω',NULL),
	 ('Αχ Ελλάδα',10,NULL,0,NULL,'2026-09-18 10:35:20','2026-09-28 08:13:43','{title: Αχ Ελλάδα}

{verse: Verse}
[Em]Χαρά στον Έλληνα που ελληνοξε[G]χνά
[Em]Και στο Σικάγο μέσα [D]ζει στη λευτε[Em]ριά
[Em]Εκείνος που δεν ξέρει και δεν αγα[G]πά
-- σάμπως φταις και συ καημένη --
[Em]και στην Αθήνα μέσα [D]ζει στη ξενι[Em]τιά

{verse: Chorus}
Αχ Ε[G]λλάδα σ'' αγα[Am]πώ και βα[G]θιά σ'' ευχαρι[Am]στώ
γιατί μ'' [G]έμαθες και [Am]ξέρω
Ν'' ανα[G]σαίνω όπου βρε[Am]θώ να πε[G]θαίνω όπου πα[Em]τώ
και να [G]μη σε [Am]υπο[Dm]φέ[Em]ρω

{verse: Chorus}
Αχ Ε[G]λλάδα θα στο [Am]πω πριν λα[G]λήσεις πετει[Am]νό
δεκα[G]τρείς φορές μ'' α[Am]ρνιέσαι .
Μ'' εκβι[G]άζεις μου κολ[Am]λάς σαν το [G]νόθο με πε[Em]τάς
μα κι α[G]πάνω [Am]μου κρε[Dm]μιέ[Em]σαι

{verse: Verse}
[Em]Η πιο γλυκιά πατρίδα είναι η καρ[G]διά
-- Οδυσσέα γύρνα κοντά μου -
[Em]που τ'' άγια χώματά της [D]πόνος και χα[Em]ρά
[Em]καθένας είναι ένας που σύνορο πο[G]νά
[Em]και εγώ είμαι ένας κανένας [D]που σας σεργια[Em]νά

{verse: Chorus}
Αχ Ε[G]λλάδα σ'' αγα[Am]πώ και βα[G]θιά σ'' ευχαρι[Am]στώ
γιατί μ'' [G]έμαθες και [Am]ξέρω
Ν'' ανα[G]σαίνω όπου βρε[Am]θώ να πε[G]θαίνω όπου πα[Em]τώ
και να [G]μη σε [Am]υπο[Dm]φέ[Em]ρω',NULL),
	 ('Τι σήμερα τι αύριο τι τώρα',62,NULL,0,NULL,'2026-09-18 11:09:30','2026-10-16 10:40:40','{title: Τι σήμερα τι αύριο τι τώρα}

{verse: Verse}
[Am]Τι σήμερα, τι αύριο, τι τώρα
ας καθα[A]ρίσουμε μια ώρα αρ[Dm]χήτερα
Του χωρισμού μας έφτασε η [E]ώρα
Μπο[F]ρεί και για τους δυο να ''ναι κα[E]λύτερα
ας καθαρίσουμε μια ώρα αρ[Am]χήτερα

{verse: Verse}
[Am]Τι σήμερα, τι αύριο, τι τώρα
κι αν περι[A]μένουμε, τι θα κερ[Dm]δίσουμε
Αφού η γκρίνια ξέσπασε σαν [E]μπόρα
στον [F]δρόμο αυτό κι οι δυο θα δυστυ[E]χήσουμε
Κι αν περιμένουμε, τι θα κερ[Am]δίσουμε

{verse: Verse}
[Am]Τι σήμερα, τι αύριο, τι τώρα
αφού δε γίνεται μαζί να [Dm]ζήσουμε
Κι αφού μάς πήρε πια η κατη[E]φόρα
κα[F]λύτερα από τώρα να χω[E]ρίσουμε
Αφού δε γίνεται μαζί να [Am]ζήσουμε',NULL),
	 ('Νύχτες μαγικές',62,NULL,0,NULL,'2026-09-18 12:03:27','2026-09-28 08:14:10','{title: Νύχτες μαγικές}

{verse: Verse}
[Am]Νύχτες μαγικές, ονειρε[G]μένες
αγάπες λάγνες, ξεχα[F]σμένες, στην ξενι[E]τιά
[Am]Τρέχει ο νους μου προς τα περα[G]σμένα
τα βράδια μου τ'' αγαπη[F]μένα, στην Αρα[E]πιά

{verse: Chorus}
[Am]Σάς μιλάω με καη[F]μό, με σπαρα[E]γμό
για τόσες [F]τρέλες που νοσταλ[E]γώ
[Dm]Αραπίνες [Am]λάγνες, ερωτιάρες
με ουίσκι, [E]με γλυκές κιθάρες, γλέντι και πο[Am]τό
[Dm]Αραπίνες, [Am]μάτια φλογισμένα
και κορμιά φι[E]δίσια, καμωμένα σαν εξωτι[Am]κά

{verse: Verse}
[Am]Κάθε βράδυ δυο μεγάλα [G]μάτια
αράπικα, σωστά δια[F]μάντια, αναζη[E]τώ
[Am]Μα δεν βρίσκω τέτοια μαγε[G]μένα
σαν τ'' άλλα τα ονειρε[F]μένα, γι αυτό θρη[E]νώ

{verse: Chorus}
[Am]Τραγουδάω με καη[F]μό, με σπαραγ[E]μό
τις τόσες [F]τρέλες που νοσταλ[E]γώ
[Dm]Αραπίνες, [Am]όνειρα σβησμένα
σαν εκείνα [E]τα ονειρεμένα, γλέντι και πο[Am]τό
[Dm]Αραπίνες, [Am]μάτια φλογισμένα
και κορμιά φι[E]δίσια, καμωμένα σαν εξωτι[Am]κά',NULL),
	 ('Το τσιγάρο',63,NULL,0,NULL,'2026-09-18 12:11:04','2026-10-16 12:24:02','{title: Το τσιγάρο}

{verse: Verse}
[Am]Χάραξε και δε νυ[E]στάζω, σκέφτομαι τι μου ''πες [Am]χτες
[Am]Άσε με να σε κοι[E]τάζω κι άμα ξημερώσει [Am]ό,τι θες

{verse: Verse}
[Am]Γύρισε να σ'' αγκα[E]λιάσω, τώρα ξέρω πως δε [Am]φταις
[Am]Άσε με να σε χο[E]ρτάσω κι άμα βγει ο ήλιος [Am]ό,τι θες

{verse: Chorus}
[Am]Στο τσιγάρο που κρα[Em]τώ, στον ένα μου Θε[Dm]ό
να μη δώσει να ξη[E]μερωθώ
[Am]Στο κορμί αυτό τ'' αγγελι[Em]κό, στο στόμα που φι[Dm]λώ   | 2x
έτσι μιά ζωή θα [E]σ'' αγαπώ                         | 2x

{verse: Verse}
[Am]Ξάπλωσε να σε [E]κρατήσω, κλείσαν όλες οι πλη[Am]γές
[Am]Άσε με να σε κοι[E]μήσω, κι αύριο για σένα ό,τι [Am]θες

{verse: Verse}
[Am]Γύρισε να σ'' αγκα[E]λιάσω, τώρα ξέρω πως δε [Am]φταις
[Am]Άσε με να σε χο[E]ρτάσω κι άμα ξημερώσει ό,τι [Am]θες

{verse: Chorus}
[Am]Στο τσιγάρο που κρα[Em]τώ, στον ένα μου Θε[Dm]ό
να μη δώσει να ξη[E]μερωθώ
[Am]Στο κορμί αυτό τ'' αγγελι[Em]κό, στο στόμα που φι[Dm]λώ   | 2x
έτσι μιά ζωή θα [E]σ'' αγαπώ                         | 2x',NULL),
	 ('Κάτι μου κρύβεις',49,NULL,0,NULL,'2026-09-18 12:19:02','2026-09-28 08:14:56','{title: Κάτι μου κρύβεις}
{verse: Intro}
[Am] [Em] [Dm] [G] [Am] [Dm] [Em] [Am] [Dm] [Em]

{verse: Verse}
[Em]Κάτι μου κρύβεις, την καρδιά σου δε μ'' α[Am]νοίγεις
κι όλο πε[F]ρνάει απ'' το μυαλό μου το κα[Em]κό
[Em]Πες μου τι τρέχει κι η καρδιά μου εμένα α[Am]ντέχει
Ό,τι κι αν [F]πεις, δεν φταις εσύ ούτε κι ε[Em]γώ

{verse: Chorus}
[Em]Πες μου αν άλλον αγα[F]πάς, πες μου αν σε χ[Em]άνω
Εγώ θα [Am]γράψω ένα τραγούδι παραπά[Em]νω
[Em]Δε θα μιλάνε οι στίχοι [F]για γυναίκες σκάρ[Em]τες
για κείνες [Am]που κρατάνε τις καρδιές σαν κάρ[Em]τες

{verse: Chorus}
Κι αν βρήκες [Em]άλλον ν'' αγα[F]πήσεις κι αν σε χά[Em]σω
θα βγω στους [Am]δρόμους και δεν ξέρω που θα φτά[Em]σω
Σε μέρη [Am]άγνωστα μονάχος θα γυρνά-[Em]ω
Να τραγουδά-[Em]ω

{verse: Verse}
[Em]Στα όνειρά μου δοκιμάζω την καρ[Am]διά μου
Σε βλέπω σ'' [F]άλλη αγκαλιά να ξενυ[Em]χτάς
[Em]Κι όλο μου λείπεις, είσαι δίπλα μου και λεί[Am]πεις [F] [Em]

{verse: Chorus}
[Em]Πες μου αν άλλον αγα[F]πάς, πες μου αν σε χ[Em]άνω
Εγώ θα [Am]γράψω ένα τραγούδι παραπά[Em]νω
[Em]Δε θα μιλάνε οι στίχοι [F]για γυναίκες σκάρ[Em]τες
για κείνες [Am]που κρατάνε τις καρδιές σαν κάρ[Em]τες

{verse: Chorus}
Κι αν βρήκες [Em]άλλον ν'' αγα[F]πήσεις κι αν σε χά[Em]σω
θα βγω στους [Am]δρόμους και δεν ξέρω που θα φτά[Em]σω
Σε μέρη [Am]άγνωστα μονάχος θα γυρνά-[Em]ω
Να τραγουδά-[Em]ω',NULL),
	 ('Για που τοβαλες καρδιά μου',49,NULL,0,NULL,'2026-09-18 12:28:10','2026-09-28 08:15:05','{title: Για που τοβαλες καρδιά μου}

{verse: Verse}
[Am]Για που [G]το ''βα[Am]λες κα[G]ρδιά μου [Am]μ'' ανοιχτά πα[G]νιά
[F]για ποια [G]πέλα[F]γα ου[G]ράνια, [F]άστρα μαγι[Am]κά
[Am]Για που [G]το ''βα[Am]λες καρ[G]διά μου [Am]μ'' ανοιχτά πανιά

{verse: Verse}
[Am]Για ποια [G]μακρι[Am]νή πα[G]τρίδα [Am]έρμη ξενι[G]τιά
[F]θάλασσα, [G]ουραν[F]ός μ'' α[G]στέρια [F]πουθενά στε[Am]ριά
[Am]Για που [G]το ''βα[Am]λες καρ[G]διά μου [Am]μ'' ανοιχτά πανιά

{verse: Verse}
[Am]Ποια α[G]γάπη, [Am]ποιο λι[G]μάνι, [Am]ποια παρηγο[G]ριά
[F]θα ''χεις [G]αγκα[F]λιά το [G]κύμα, [F]χάδι το νο[Am]τιά
[Am]Για που [G]το ''βα[Am]λες καρ[G]διά μου [Am]μ'' ανοιχτά πανιά',NULL),
	 ('Φάνης',47,NULL,0,NULL,'2026-09-18 12:57:08','2026-09-28 08:15:31','{title: Φάνης}

{verse: Verse}
[Em]Δυο χρόνια είχα να σε δω
[Bm]και σε συνάντησα ξανά μια Κυρια[Em]κή
[Em]Κερνούσες ούζα
και κονιάκ στο καφε[Bm]νείο
και τα καλά σου [C]φόραγες
σαν να ''τα[Bm]νε γιορ[Em]τή

{verse: Verse}
[Em]Δεν ήσουνα φα[C]ντάρος
για να σου πω
καλός πο[Em]λίτης
μα ούτε και που [C]γιόρταζες
για να σου πω χρόνια πο[Em]λλά

{verse: Verse}
Τρε[Am]λάδικο και φυλακή
δυο χρόνια και έξι [Em]μήνες
ήπια το ούζο κι είπα  γεια χα[Em]ρά

{verse: Verse}
Το ξέρω [Am]ζήτησες δουλειά
σε χίλια δυο αφεντι[Em]κά
κι όλοι ζη[C]τούσανε να δουν συστάσεις
προϋπηρε[Em]σία, μα μόλις [Am]είδανε κι αυτοί
πως είχες [Em]κίτρινο χαρτί σε διώξα[Am]νε
σαν το σκυλί κι ούτε σ'' α[Em]φήσανε να πεις
[Bm]μια δικαιολο[Em]γία

{verse: Verse}
Και είπες [Am]στην αρχή καλά
κι'' αλλού ε[Em]ζήτησες δουλειά
κι αλλού ξα[C]νά, κι αλλού τα ίδια και τα [Em]ίδια
Μα ήσουν [Am]άτυχος πολύ γιατί έπε[Em]σες
και σε εποχή που όλοι [Am]σφίγγαν το λουρί
κι εσύ είχες [Em]κίτρινο χαρτί
κι αυτό το [Bm]χρώμα ξέρεις φέρνει αλλερ[Em]γία

{verse: Verse}
Κι ερχότα[Bm]νε κι ο πυρετός κάθε που [Em]νύχτωνε
σε τυρα[Bm]ννούσε καλοκαίρι και [Em]χειμώνα
κι είναι μα[Am]ρτύριο φοβερό το βίτσιο [Em]αυτό
το βρωμερό που σου ''μα[Bm]θε στην φυλακή εκείνος
ο ψηλός από την Δραπε[Em]τσώνα
Σου λείπει η [Am]σκόνη η λευκή το ξέρεις [Em]πως δεν
φταις εσύ φωτιές σου [C]καίνε το κορ[Bm]μί, κουτάλι και βε[Em]λόνα

{verse: Verse}
Και έκα[Am]νες υπομονή γιατί φο[Em]βόσουν το κελί
Καλόπια[C]νες τη μοναξιά και τον ασβέστη που ''πεφτε
σαν χιόνι απ'' το τα[Bm]βάνι. Και μέχρι [Am]να σου βγει ψυχή
δεν θα ξε[Em]χάσεις μια στιγμή κάποια βρά[Am]δια στην
φυλακή φωνές και [Em]κλάματα, κι είπανε το [Am]άλλο το πρωί
στο 15[Em] το κελί ότι βι[Bm]άσαν οι παλιοί τον έφηβο τον [Em]Φάνη

{verse: Verse}
Κι όταν σε βρήκαν παγωμένο στο κελί σου
είπαν [C]αυτός είναι από ώρα πια νε[Em]κρός
και κάποιος έτρεξε τη[Bm]λέφωνο να [Em]πάρει

{verse: Verse}
Πέντε βδομάδες τώρα υ[Bm]πόφερες το [Em]ξέρω
το ξέρω [C]σου ''λειψε η σκόνη η λευ[Em]κή
και μου ''λεγες εκεί ξα[Bm]νά δεν θα γυ[Em]ρίσω
Βα[Am]ρέθηκα τις νύχτες τις λευκές
σαν άνθρωπος κι [Bm]εγώ θέλω να ζήσω

{verse: Verse}
[Em]Δυο χρόνια είχα να σε δω
[Bm]και σε συνάντησα ξανά μια Κυρια[Em]κή
[Em]Κερνούσες ούζα
και κονιάκ στο καφε[Bm]νείο
και τα καλά σου [C]φόραγες
σαν να ''τα[Bm]νε γιορ[Em]τή',NULL),
	 ('Αεροπλάνα',64,NULL,0,NULL,'2026-09-18 14:08:10','2026-10-06 14:48:02','{title: Αεροπλάνα}
{verse: Verse}
[Em]Πήρα το χαρ[Am]τί, ντύθηκα στα [C]μπλε
[D]Πέρασα την [Em]πύλη
[Em]Σε τόπο μακρι[Am]νό με τον άνε[C]μο
[D]Φίλο κι αδερ[Em]φό

{verse: Chorus}
[Am]Άν[D]να
Δεν [G]ήμουνα ε[C]γώ γι'' αερο[F]πλά[Em]να
[Am]Άν[D]να
Δεν [G]ήμουνα ε[C]γώ γι'' αερο[F]πλά[Em]να
[F]Άν[Am]να

{verse: Verse}
[Em]Ώρες στη σκο[Am]πιά τσιγάρο στα κλε[C]φτά
[D]Σκουπίδια μαγει[Em]ρεία
[Em]Μα κάτω απ'' την πλα[Am]γιά ο δρόμος ο φωτει[C]νός
[D]Δείχνει την πο[Em]ρεία

{verse: Chorus}
[Am]Άν[D]να
Δεν [G]ήμουνα ε[C]γώ γι'' αερο[F]πλά[Em]να
[Am]Άν[D]να
Δεν [G]ήμουνα ε[C]γώ γι'' αερο[F]πλά[Em]να
[F]Άν[Am]να

{verse: Verse}
[Em]Το παιχνίδι αυ[Am]τό θέατρο σω[C]στό
[D]Και γνωστοί οι [Em]ρόλοι
[Em]Βγάζω τη στο[Am]λή και το κράνος [C]μου
[D]Φεύγω για την [Em]πόλη

{verse: Chorus}
[Am]Άν[D]να
Δεν [G]ήμουνα ε[C]γώ γι'' αερο[F]πλά[Em]να
[Am]Άν[D]να
Δεν [G]ήμουνα ε[C]γώ γι'' αερο[F]πλά[Em]να
[F]Άν[Am]να','D-DU-UDU');
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Αχ να σε δω',49,NULL,0,NULL,'2026-09-18 14:19:35','2026-09-28 08:16:14','{title: Αχ να σε δω}

{verse: Verse}
[Em]Από τα βάθη της ψυχής κι από του νου τα [Am]ύψη
[Em]Απ'' το βυθό της θάλασσας ως τις βουνοκορ[Bm]φές
[Em]ψάχνω να σε βρω

{verse: Verse}
[Em]Μια σφαίρα υγρή γύρω απ'' τη γη, μια ουράνια δε[Am]ξαμενή
[Em]εκεί που λούζονται οι ψυχές, πριν να χαθούν στο [Bm]σύμπαν
με [C]ένα πήδο έ[D]να πρωί [C]να μπω με μια βου[Bm]τιά εκεί
Απ'' [C]τον βυθό, απ'' τον [D]πάτο να [C]δω τα πάνω [Bm]κάτω
να [C]βρω όλα τα χα[D]μένα, [C]ίσως να βρω κι ε[Bm]σένα

{verse: Chorus}
[Em]Αχ, να σε βρω, [Am]αχ, να σε βρω, [Em]μόνο για λίγο [Bm]να σε δω   | 2x
[Em]N'' ακούσω τη σκι[Am]ά σου να μου φωνάζει [Em]γεια σου          | 2x

{verse: Verse}
[Em]Ακούς στα δέντρα τα πουλιά, άνθρωποι είναι [Am]με φτερά
[Em]που φέρνουν τα μηνύματα από τον άλλο [Bm]κόσμο
Φυ[C]σάει αέρας [D]στα κλαδιά, [C]μου απαντούν ψι[Bm]θυριστά
[C]κι αυτό που ψάχνεις [D]θα στο πουν τα [C]πιο βαθιά πη[Bm]γάδια

{verse: Verse}
[Em]Έψαξα γη και ουρανό, μια περπατώ και [Am]μια πετώ
[Em]στων δύο κόσμων το κενό να βρω την χαρα[Bm]μάδα
Στα [C]βάθη των ωκ[D]εανών [C]ακούω τον ήχο [Bm]των σεισμών
[C]κι από την γη που [D]άνοιξε πε[C]ρνάω στον κάτω [Bm]κόσμο
[C]να βρω όλα τα χα[D]μένα, [C]ίσως να βρω κι ε[Bm]σένα

{verse: Chorus}
[Em]Αχ, να σε βρω, [Am]αχ, να σε βρω, [Em]μόνο για λίγο [Bm]να σε δω   | 2x
[Em]N'' ακούσω τη σκι[Am]ά σου να μου φωνάζει [Em]γεια σου          | 2x',NULL),
	 ('Εκεί στο Νότο',46,NULL,0,NULL,'2026-09-18 14:25:44','2026-09-28 08:16:34','{title: Εκεί στο Νότο}

{verse: Verse}
[Em]Εκεί στο Νότο
που τρίζει ο θάνατος κι η α[C]γάπη κάνει κρότο
σαν άδειο κάθισμα ταξίδεψα για [D]χρόνια
ψάχνοντας να βρω το κατάλληλο κορ[G]μί [B7]

{verse: Verse}
Εκεί στα [Em]φώτα
έβρισκε η νύχτα τα ση[C]μάδια της τα πρώτα
Είχα ξεμείνει από τσιγάρα και συ[D]μπόνια
και συ με κέρασες καπνό μ'' ένα φι[G]λί [B7]

{verse: Chorus}
Ποια [Am]πόλη, ποια [Em]χώρα
ποια θάλασσα σε ταξιδεύει [G]τώρα
σω[Am]παίνεις, θυ[Em]μάσαι
και μεθυ[D]σμένη μεσ'' τον ύπνο σου γε[G]λάς
Ποια [Am]πόλη, ποια [Em]χώρα
ποια [D]θάλασσα σε ταξιδεύει [Em]τώρα

{verse: Verse}
Εκεί στο [Em]Νότο
εκεί μου κλήρωσε ο [C]έρωτας στο Λόττο
κουλουριασμένος σαν τη σαύρα στη σκι[D]ά του
σα νόμισμα έπεφτα στο μαύρο σου βυ[G]θό [B7]

{verse: Verse}
Χλωμά κα[Em]ντήλια
άναβε η φτώχεια σου, τα [C]τάιζε με ζήλια
μα συλλαβίζαν "σ'' αγαπώ" τα βογκη[D]τά σου
σαν ένα άρρωστο στην κούνια του μω[G]ρό [B7]

{verse: Chorus}
Ποια [Am]πόλη, ποια [Em]χώρα
ποια θάλασσα σε ταξιδεύει [G]τώρα
σω[Am]παίνεις, θυ[Em]μάσαι
και μεθυ[D]σμένη μεσ'' τον ύπνο σου γε[G]λάς
Ποια [Am]πόλη, ποια [Em]χώρα
ποια [D]θάλασσα σε ταξιδεύει [Em]τώρα',NULL),
	 ('Της δικαιοσύνης ήλιε νοητέ',40,NULL,0,NULL,'2026-09-18 14:33:58','2026-09-28 08:16:42','{title: Της δικαιοσύνης ήλιε νοητέ}

{verse: Verse}
[Em]Της δικαιοσύνης ήλιε νοη[G]τέ [Em]και μυρσίνη ε[Am]σύ  δο[G]ξαστι[Em]κή
[Am]μη παρακα[Em]λώ σας [D]μη, [Am]μη παρακα[Em]λώ σας μη
[D]μη παρακα[G]λώ σας [Am]μη, λησμο[C]νάτε τη [G]χώ[D]ρα [Em]μου

{verse: Verse}
[Em]Αετόμορφα έχει τα ψηλά βου[G]νά [Em]στα ηφαίστεια [Am]κλήμα[G]τα σει[Em]ρά
[Am]και τα σπίτια [Em]πιο λευ[D]κά στου γλαυ[Am]κού το γει[Em]τόνεμα

{verse: Verse}
[Em]Τα πικρά μου χέρια με τον κεραυ[G]νό [Em]τα γυρίζω [Am]πίσω απ'' [G]τον και[Em]ρό
[Am]τους παλιούς μου [Em]φίλους κα[D]λώ με φο[Am]βέρες και [Em]μ'' αίματα

{verse: Verse}
[Em]Της δικαιοσύνης ήλιε νοη[G]τέ [Em]και μυρσίνη ε[Am]σύ  δο[G]ξαστι[Em]κή
[Am]μη παρακα[Em]λώ σας [D]μη, [Am]μη παρακα[Em]λώ σας μη
[D]μη παρακα[G]λώ σας [Am]μη, λησμο[C]νάτε τη [G]χώ[D]ρα [Em]μου',NULL),
	 ('Κοιλάδα των Τεμπών',45,NULL,0,NULL,'2026-09-18 14:49:02','2026-09-28 08:17:02','{title: Η κοιλάδα των Τεμπών}

{verse: Verse}
[Am]Μες την κοιλά- [C]όπως τα [Am]λέω
[Dm]μες την κοιλά[G]δα των Τε[Dm]μπών
[C]φόβος των μη[G]χανοδη[Am]γών

{verse: Verse}
[Am]Είναι ένας γέ- [C]όπως τα [Am]λέω
[Dm]είναι ένας γέ[G]ρο πλάτα[Dm]νος
[C]μαγκούφης και [G]παράφο[Am]ρος

{verse: Verse}
[Am]Που πίνει απ'' το [C]όπως τα [Am]λέω
[Dm]που πίνει απ'' το [G]θολό νε[Dm]ρό
[C]του ποτα[G]μού το ιε[Am]ρό

{verse: Verse}
[Am]Πίνει κι απλώ- [C]όπως τα [Am]λέω
[Dm]πίνει κι απλώ[G]νει ρίζω[Dm]μα
[C]βαθιά μέσα [G]στα ανείπω[Am]τα

{verse: Verse}
[Am]Κι όποτε παί- [C]όπως σας [Am]λέω
[Dm]κι όποτε παίρ[G]νει ανάπο[Dm]δες
[C]γέρνει και πέ[G]φτει στις γρα[Am]μμές

{verse: Verse}
[Am]Πιάνει το τρέ- [C]όπως τα [Am]λέω
[Dm]πιάνει το τρέ[G]νο από τ'' αυ[Dm]τί
[C]Μην την περνάς [G]τη Γευγε[Am]λή

{verse: Verse}
[Am]Μένα μου το [C]όπως τα [Am]λέω
[Dm]μένα μου το ''[G]πε ο Πηνει[Dm]ός
[C]το μυστι[G]κό ο φλύα[Am]ρος

{verse: Verse}
[Am]Πως ήταν ά- [C]όπως τα [Am]λέω
[Dm]πως ήταν ά[G]νθρωπος πα[Dm]λιά
[C]κι είχε παι[G]διά στην ξενι[Am]τιά',NULL),
	 ('Landing in London',65,NULL,0,NULL,'2026-09-19 14:32:40','2026-10-05 07:45:45','{title: Landing in London}
{verse: Verse}
[Em] I woke up today in [G]London
[Am]As the plane was touchin'' [Em]down
[Em]All I could think about was [G]Monday
[Am]And maybe I''d be back [Em]around

{verse: Verse} 
[Em]If this keeps me away much [C]longer
[D]I don''t know what I would [Em]do
[Em]You''ve got to understand it''s a [C]hard life
[D]That I''m goin'' [Em]through

{verse: Chorus}
[Em]And when the night falls in [C]around me
[Am]And I don''t think I''ll make it [Em]through
[Em]I''ll use your light to guide the [C]way
[D]''Cause all I think about is [Em]you

{verse: Verse}
[Em]Well LA''s gettin'' kinda [G]crazy (Brad)
[Am]And New York''s gettin'' kinda [Em]cold (Bob)
[Em]I''ll keep my head from getting [G]lazy (Brad)
[Am]I just can''t wait to get back home (Bob)
 
{verse: Verse}
[Em]All these days I''ve spent [C]away
[D]I''ll make up for this I [Em]swear
[Em]I need your love to hold [C]me up
[D]When it''s all too much to [Em]bear

{verse: Chorus}
[Em]And when the night falls in a[C]round me
[Am]And I don''t think I''ll make it [Em]through
[Em]I''ll use your light to guide the [C]way
[D]''Cause all I think about is [Em]you
 
{verse: Solo}
[C] [Am] [Em] [C] [Am] [Em]

{verse: Verse}
[Em]All these days I''ve spent [C]away
[D]I''ll make up for this I [Em]swear
[Em]I need your love to hold [C]me up
[D]When it''s all too much to [Em]bear

{verse: Chorus}
[Em]And when the night falls in [C]around me
[Am]And I don''t think I''ll make it [Em]through
[Em]I''ll use your light to guide the [C]way
[D]''Cause all I think about is [Em]you','D-D-UU-DUD'),
	 ('Tears of the Dragon',66,NULL,0,NULL,'2026-09-19 14:45:21','2026-09-28 07:33:28','{title: Tears of the Dragon}
{verse: Intro}
[Am] [C]   x2
 
{verse: Verse}
[Am]For too long now, [C]there were secrets in my [Am]mind
For too long now, [C]there were things I should have [Am]said
In the darkness, [C]I was stumbling for the [Am]door
To find a reason, [C]to find the time, the place, [Am]the hour
Waiting for the [Em]winter sun and the [G]cold light of [D]day
[Am]The misty ghost of [Em]childhood fears
The [G]pressure is building and I [D]can''t stay away.
 
{verse: Chorus}
I [Em]throw my[C]self in[G]to the [D]sea
Re[Em]lease the [C]wave
Let it [G]wash over [D]me
To [Em]face the [C]fear I [G]once bel[D]ieved
The [Em]tears of the [C]dragon for [G]you and for [D]me
 
{verse: Verse}
[Am]Where I was, [C]I had wings that couldn''t [Am]fly
Where I was, [C]I had tears I couldn''t [Am]cry
My emotions, [C]frozen in an icy [Am]lake
I couldn''t feel them [C]until the ice began to [Am]break
I have no power [Em]over this, you [G]know I''m a[D]fraid
[Am]The walls I built are [Em]crumbling, the [G]water is moving,
I''m [D]slipping away.
 
{verse: Chorus}
I [Em]throw my[C]self in[G]to the [D]sea
Re[Em]lease the [C]wave
Let it [G]wash over [D]me
To [Em]face the [C]fear I [G]once bel[D]ieved
The [Em]tears of the [C]dragon for [G]you and for [D]me
 
{verse: Verse}
[Am]Slowly I a[Em]wake, [G]slowly I [D]rise
[Am]The walls I built are [Em]crumbling,
The [G]water is moving, I''m [D]slipping away.
 
{verse: Chorus}
I [Em]throw my[C]self in[G]to the [D]sea
Re[Em]lease the [C]wave
Let it [G]wash over [D]me
To [Em]face the [C]fear I [G]once bel[D]ieved
The [Em]tears of the [C]dragon for [G]you and for [D]me
 
I [Em]throw my[C]self in[G]to the [D]sea
Re[Em]lease the [C]wave
Let it [G]wash over [D]me
To [Em]face the [C]fear I [G]once bel[D]ieved
The [Em]tears of the [C]dragon for [G]you and for [D]me',NULL),
	 ('Όταν χαράζει',67,NULL,0,NULL,'2026-09-21 07:39:20','2026-09-28 08:17:30','{title: Όταν χαράζει}

{verse: Verse}
[Am]Όταν χα[Em]ράζει, ο πρώτος στεναγμός
[Dm]βγαίνει απ'' τα [G]πιο σφιγμένα [Am]χείλη
[Am]Σαν πετα[Em]λούδα στην κάμαρη πετά
[Dm]ψάχνοντας [G]άνοιγμα να [C]φύγει [Em]

{verse: Interlude}
[Am] [Dm] [G] [Am]
[Am] [Dm] [F] [Am]

{verse: Verse}
[Am]Αν είσαι [Em]μόνος, αν είσαι αδύναμος
[Dm]η χαραυ[G]γή θα σε ξε[Am]κάνει
[Am]Έχει το [Em]μύρο, έχει τη σιγαλιά
[Dm]έχει τον [G]ήλιο τον [C]αλάνη [Em]

{verse: Interlude}
[Am] [Dm] [G] [Am]
[Am] [Dm] [F] [Am]

{verse: Verse}
[Am]Καινούρια [Em]μέρα, καινούριος ποταμός
[Dm]στις εκβο[G]λές του θα προ[Am]σφέρει
[Am]όσα χα[Em]θήκαν, όσα ξεχάστηκαν
[Dm]κι όσα γι'' αυ[G]τά κανείς δεν [C]ξέρει [Em]

{verse: Interlude}
[Am] [Dm] [G] [Am]
[Am] [Dm] [F] [Am]

{verse: Verse}
[Am]Πίσω απ'' τους [Em]λόφους, πίσω απ'' τα βλέφαρα
[Dm]υπάρχει [G]τόπος και για [Am]σένα
[Am]Χωρίς Βα[Em]στίλη, χωρίς ανάθεμα
[Dm]χωρίς τα [G]χείλη τα σφι[C]γμένα [Em]

{verse: Interlude}
[Am] [Dm] [G] [Am]
[Am] [Dm] [F] [Am]',NULL),
	 ('Μαρέσει να μην λέω πολλά',69,NULL,0,NULL,'2026-09-21 08:08:59','2026-09-28 08:18:54','{title: Μαρέσει να μην λέω πολλά}

{verse: Verse}
[Am]Μ'' αρέσει να μη λέω πο[G]λλά, μη λέω πο[Am]λλά
Μ'' αρέσει να κοιτάω ψη[G]λά, κοιτάω ψη[C]λά
στ'' α[G]τέλειωτα τρα[Am]γούδια

{verse: Verse}
[Am]Με τη σκιά μου να πε[G]τώ, να πε[Am]τώ
να πιάνω αστέρια στο βυ[G]θό, στο βυ[C]θό
βυ[G]θό της μουσι[Am]κής σου

{verse: Verse}
[Am]Κι όταν θα πέφτει η παγω[G]νιά, παγω[Am]νιά
να κάνω κύκλους σαν ο[G]λό-
ολόγιο[C]μο φε[G]γγάρι στη σκη[Am]νή σου

{verse: Verse}
[Am]Να ''ταν τα φώτα τα θα[G]μπά, τα θα[Am]μπά
να ''ταν αστέρια φωτει[G]νά, φωτει[C]νά
στα [G]χέρια να στ'' α[Am]φήσω

{verse: Verse}
[Am]Μάτια μου ψάξε να με [G]βρεις, να με [Am]βρεις
μαζί στους δρόμους της σιω[G]πής, μονα[C]χός
θα [G]σβήνω τη μορ[Am]φή σου',NULL),
	 ('Κάνε κάτι να χάσω το τραίνο',15,NULL,0,NULL,'2026-09-21 07:44:48','2026-09-28 08:17:43','{title: Κάνε κάτι να χάσω το τραίνο}

{verse: Verse}
[Em]Αυτό το τσιγάρο που [F]καίει είναι το τελευ[Em]ταίο
[Em]Τα μάτια σου κλείσε, [F]δεν θέλω να δεις ότι [Em]κλαίω
[Am]γιατί είναι μοιραίο να [Em]φύγω σε [F]λίγο, σε λίγο, σε [Em]λίγο

{verse: Chorus}
[C]Κάνε κάτι λοιπόν να χάσω το [Em]τρένο       2x
Αγκάλια[Am]σέ με, φίλη[Em]σέ με μέσα στα [Dm]χέρια σου τα δυο φυ[Em]λάκισέ με
[C]Κάνε κάτι λοιπόν να χάσω το [Em]τρένο
[C]Κάνε κάτι να [G]χάσω το [Am]τρένο

{verse: Verse}
[Em]Αυτό το τσιγάρο που [F]καίει σε λίγο θα [Em]σβήσει
[Em]Μια στάλα κουράγιο που [F]έχω κι αυτό θα μ'' α[Em]φήσει
[Am]γιατί είναι μοιραίο να [Em]φύγω σε [F]λίγο, σε λίγο, σε [Em]λίγο

{verse: Chorus}
[C]Κάνε κάτι λοιπόν να χάσω το [Em]τρένο       2x
Αγκάλια[Am]σέ με, φίλη[Em]σέ με μέσα στα [Dm]χέρια σου τα δυο φυ[Em]λάκισέ με
[C]Κάνε κάτι λοιπόν να χάσω το [Em]τρένο
[C]Κάνε κάτι να [G]χάσω το [Am]τρένο',NULL),
	 ('Είμαι αιτός χωρίς φτερά',40,NULL,0,NULL,'2026-09-21 07:50:15','2026-10-16 07:54:00','{title: Είμαι αιτός χωρίς φτερά}

{verse: Verse}
[Am]Σαν τον αϊτό είχα φτερά, [G]ω, [F]ω, [E]ω
[G]και πέταγα, και πέταγα πολύ ψη[C]λά
[Am]Μα ένα χέρι λα[Em]τρεμένο, [Am]ένα χέρι λατρευ[E]τό
[Am]μου τα κόβει τα [Em]φτερά μου, [Am]για να μην ψηλά πε[Em]τώ

{verse: Chorus}
[Am]Είμ'' αητός χωρίς φτε[Dm]ρά, χω[E]ρίς αγάπη και χα[Am]ρά
[Am]Χωρίς αγάπη και χα[Dm]ρά, [E]είμ'' αητός χωρίς φτε[Am]ρά

{verse: Verse}
[Am]Το χέρι αυτό το λατρευτό, [G]ω, [F]ω, [E]ω
[G]μες στη ζωή, μες στη ζωή θα τ'' αγα[C]πώ
[Am]Ό,τι και να μου ''χει [Em]κάνει, [Am]όλα τού τα συγχω[E]ρώ
[Am]Με φτερούγες τσακι[Em]σμένες, [Am]πάντα εγώ θα τ'' αγα[E]πώ

{verse: Chorus}
[Am]Είμ'' αητός χωρίς φτε[Dm]ρά, χω[E]ρίς αγάπη και χα[Am]ρά
[Am]Χωρίς αγάπη και χα[Dm]ρά, [E]είμ'' αητός χωρίς φτε[Am]ρά',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Όνειρο ήτανε',61,NULL,0,NULL,'2026-09-21 07:56:01','2026-09-28 08:18:15','{title: Όνειρο ήτανε}

{verse: Verse}
[Em]Ο ουρανός ανάβει τα φώτα [Am]τίποτα πια δεν θα ''ναι όπως πρώτα
Ξη[Em]μέρωσε πάλι [F] [Dm] [Em]

{verse: Verse}
[Em]Ξυπνάω στο φως τα μάτια ανοίγω για [Am]λίγο νεκρός χαμένος για λίγο
Ξη[Em]μέρωσε πάλι [F] [Dm] [Em]

{verse: Chorus}
Κι [Am]έχεις χαθεί μαζί με τον ύπνο μα[Em]ζί με του ονείρου τον πολύχρωμο κύκνο
[F]Μην ξημερώνεις ουρα[E]νέ
[Am]Άδεια η ψυχή μου το δωμάτιο άδειο κι [Em]από τ'' όνειρό μου ακούω καθάριο
Το λυ[F]γμό της να λέει όνειρο ήτα[Em]νε [F]όνειρο ήτα[Em]νε

{verse: Verse}
[Em]Θα ξαναρθείς μόλις νυχτώσει και [Am]τ'' όνειρο πάλι την αλήθεια θα σώσει
[Em]Θα ''μαι κοντά σου [F] [Dm] [Em]
[Em]Μόνο εκεί σε βλέπω καλή μου ε[Am]κεί ζυγώνεις κι ακουμπάς τη ψυχή μου
[Em]Με τα φτερά σου [F] [Dm] [Em]

{verse: Chorus}
[Am]Μα το πρωί χάνεσαι φεύγεις α[Em]νοίγω τα μάτια μου κι αμέσως πεθαίνεις
[F]Μην ξημερώνεις ουρα[Em]νέ
[Am]Άδεια η ψυχή μου το δωμάτιο άδειο κι [Em]από τ'' όνειρό μου ακούω καθάριο
Το λυ[F]γμό της να λέει όνειρο ήτα[Em]νε [F]όνειρο ήτα[Em]νε',NULL),
	 ('Το χρυσό κουρέλι',68,NULL,0,NULL,'2026-09-21 07:59:55','2026-09-28 08:18:25','{title: Το χρυσό κουρέλι}

{verse: Verse}
[Am]Το χρυσό κουρέλι
που στα μαλλιά της [E]φόραγε η Νεφέλη
να ξεχωρίζει απ'' [Am]όλους μες στ'' αμπέλι
ήρθανε δυο μι[E]κροί, μικροί αγγέλοι
και το κλέψα[Am]νε

{verse: Verse}
[Am]Δυο μικροί αγγέλοι
που στα όνειρά τους [E]θέλαν τη Νεφέλη
να την ταΐζου[Am]νε ρόδι και μέλι
να μη θυμάται, [E]να ξεχνάει τι θέλει
την πλανέψα[Am]νε

{verse: Verse}
[Dm]Υάκινθοι και κρίνα
της κλέψαν το άρω[Am]μά και το φοράνε
κι οι έρωτες πε[E]τώντας σαϊτιές
την περιγε[Am]λούν

{verse: Verse}
[Dm]Μα ο καλός ο Δίας
της παίρνει το νε[Am]ρό της εφηβείας
την κάνει σύννε[E]φο και τη σκορπά
για να μη τη [Am]βρουν
 
Λα, λα, λα...',NULL),
	 ('Τι γλυκό να σαγαπούν',68,NULL,0,NULL,'2026-09-21 08:04:38','2026-09-28 08:18:42','{title: Τι γλυκό να σαγαπούν}
{verse: Intro}
[Dm] [E] [Dm] [Am] [Dm] [E] [Am]

{verse: Verse}
[Am]Μάτια μου με[Dm]γάλα
[Am]Μάτια μελα[F]γχο[G]λι[Am]κά
[Am]Ήπια στάλα-[Dm]στάλα
[Am]Τα βαθιά σας [F]μυ[G]στι[Am]κά

{verse: Chorus}
[Am]Τι γλυκό να σ'' αγα[Dm]πούν
[E]και να σου το λέ[Am]νε
[Am]μάτια που μελαγχο[Dm]λούν
[E]και κρυφά σου κλαι[Am]νε
και κρυ[Dm]φά, και κρυ[Am]φά
και κρυ[E]φά σου σιγο[Am]κλαίνε
και κρυ[Dm]φά, και κρυ[Am]φά
και κρυ[E]φά σου σιγο[Am]κλαίν

{verse: Verse}
[Am]Άντρας μου δι[Dm]κός μου
[Am]θεέ μου γλυκιά α[F]πα[G]ντο[Am]χή
[Am]Η καρδιά του [Dm]κόσμου
[Am]Στην καρδούλα μου [F]α[G]ντη[Am]χεί

{verse: Chorus}
[Am]Τι γλυκό να σ'' αγα[Dm]πούν
[E]και να σου το λέ[Am]νε
[Am]μάτια που μελαγχο[Dm]λούν
[E]και κρυφά σου κλαι[Am]νε
και κρυ[Dm]φά, και κρυ[Am]φά
και κρυ[E]φά σου σιγο[Am]κλαίνε
και κρυ[Dm]φά, και κρυ[Am]φά
και κρυ[E]φά σου σιγο[Am]κλαίν',NULL),
	 ('Ανόητες αγάπες',47,NULL,0,NULL,'2026-09-21 08:12:44','2026-09-28 08:19:12','{title: Ανόητες αγάπες}

{verse: Verse}
[Am]Τα φέραμε από ''δω, [G]τα φέραμε από ''κει
[F]Άντε ξανά τα ίδια, [E]τα ίδια απ'' την αρχή
[Am]Τα φέραμε απ ''δω, [G]τα φέραμε από ''κει
[F]Εγώ ξανά στο τίποτα [E]στο γενικά εσύ

{verse: Chorus}
[C]Νύχτες δίχως όνομα, [G]νύχτες χωρίς σκοπό
[Dm]Χαμένοι από χέρι,  [E]χαμένοι και οι δυο
[C]Ανόητες αγάπες [G]ανόητα φίλια
[F]Λόγια, λόγια, λόγια, [E]λόγια ψεύτικα
[F]Λόγια  λόγια ψεύτι[Am]κα

{verse: Verse}
[Am]Τώρα τι να σου πω, [G]τι να μου πεις κι εμένα
[F]Έτσι όπως παίξαμε κι οι δυο [E]με ζαριά πειραγμένα
[Am]Τα φέραμε από ''δω, [G]τα φέραμε από ''κει
[F]Εγώ ξανά στο τίποτα, [E]στο γενικά εσύ

{verse: Chorus}
[C]Νύχτες δίχως όνομα, [G]νύχτες χωρίς σκοπό
[Dm]Χαμένοι από χέρι,  [E]χαμένοι και οι δυο
[C]Ανόητες αγάπες [G]ανόητα φίλια
[F]Λόγια, λόγια, λόγια, [E]λόγια ψεύτικα
[F]Λόγια  λόγια ψεύτι[Am]κα',NULL),
	 ('Έλα ψυχούλα μου',46,NULL,0,NULL,'2026-09-21 08:19:55','2026-09-28 08:19:48','{title: Έλα ψυχούλα μου}
{verse: Intro}
[Am] [G]

{verse: Verse}
Είσαι [Am]τόσο παι[G]δί κατά [Am]βάθος
είσαι [Am]τόσο κα[G]λό κατά [Am]λάθος
είσαι [F]τόσο αφελής που άμα [C]θέλεις μπορείς
όσα [Dm]χάνουν οι ξύπνιοι να [E]βρεις.

{verse: Verse}
Είσαι [Am]τόσο α[G]στείο μορ[Am]τάκι
σου φι[Am]λάω και [G]το δαχτ[Am]λάκι
που'' χει [F]πάθει ζημιά τι τον [C]θες τον καβγά
τι τον [Dm]θες αφού πιάνεις λα[E]βράκι.

{verse: Chorus}
Έλα ψυ[Am]χούλα μου έλα καρδούλα μου
[F]ξέρω δεν είσαι ότι [C]δείχνεις.
Άλλοι σε [Dm]παίξανε  άλλοι σε μπλέξανε
κλάψε [G]γιατί όταν κλαις μικρο[E]δείχνεις.

{verse: Chorus}
Δάγκωσ'' τα [Am]χείλη σου είμαι μαντήλι σου
[F]σβήνω τον πάγο απ'' το [C]βλέμμα.
Έλα στρα[Dm]βάδι μου πιάσου απ'' το χάδι μου
κατά ε[G]δώ μη σε πάρει το [E]ρέμα.

{verse: Verse} 
Μη πο[Am]ζάρεις σα [g]μούτρο σε [Am]μένα
δε σε [Am]παίζω με [G]φύλλα κρυ[Am]μμένα
βρίσκω αυ[F]τή τη ρωγμή που η ζω[C]ή η ωμή
το χα[Dm]μένο λατρεύει κορ[E]μί.

{verse: Verse}
Δεν υ[Am]πάρχουν νε[G]ρά του Ιορ[Am]δάνη
κι όταν [Am]πιάνεις μω[G]ρό μου λι[Am]μάνι
μην την [F]ψάχνεις πολύ όλοι οι [C]αμαρτωλοί
όλοι [Dm]είναι απ'' το ίδιο χαρ[E]μάνι

{verse: Chorus}
Έλα ψυ[Am]χούλα μου έλα καρδούλα μου
[F]ξέρω δεν είσαι ότι [C]δείχνεις.
Άλλοι σε [Dm]παίξανε  άλλοι σε μπλέξανε
κλάψε [G]γιατί όταν κλαις μικρο[E]δείχνεις.

{verse: Chorus}
Δάγκωσ'' τα [Am]χείλη σου είμαι μαντήλι σου
[F]σβήνω τον πάγο απ'' το [C]βλέμμα.
Έλα στρα[Dm]βάδι μου πιάσου απ'' το χάδι μου
κατά ε[G]δώ μη σε πάρει το [E]ρέμα.',NULL),
	 ('Τσιγάρο ατέλειωτο',45,NULL,0,NULL,'2026-09-21 08:24:26','2026-09-28 08:20:01','{title: Τσιγάρο ατέλειωτο}

{verse: Verse}
[Am]Θα περπατήσω μοναχός κι αυτό το [Bm]βράδυ
[G]μήπως και βρω της λησμονιάς σου το νε[Bm]ρό
[C]και σε υπόγεια σκοτεινά θα βρω ση[Am]μάδι
[Bm]μ'' ένα ποτήρι ως της αυγής τον πανικό

{verse: Chorus}
[G]Τσιγάρο ατέλειωτο, βαρύ η μονα[C]ξιά μου       | 2x
[Am]μοιάζει γυναίκα κουρασμένη απ'' το [Bm]δρόμο     | 2x
[C]Ρίχνει το γέλιο της και κάθεται κο[Am]ντά μου   | 2x
[Bm]κερνά τα επόμενα και με χτυπάει στον ώμο    | 2x

{verse: Verse}
[Am]Σ'' ένα ποτήρι με φυτίλι αναμ[Bm]μένο
[G]βλέπω τα μάτια σου και κλαίω σιωπη[Bm]λά
[C]και το μυαλό μου που ''ναι πάλι θολω[Am]μένο
[Bm]στριφογυρνά των τραγουδιών σου τη θηλιά

{verse: Chorus}
[G]Τσιγάρο ατέλειωτο, βαρύ η μονα[C]ξιά μου       | 2x
[Am]μοιάζει γυναίκα κουρασμένη απ'' το [Bm]δρόμο     | 2x
[C]Ρίχνει το γέλιο της και κάθεται κο[Am]ντά μου   | 2x
[Bm]κερνά τα επόμενα και με χτυπάει στον ώμο    | 2x',NULL),
	 ('Παλιομισοφόρια',40,NULL,0,NULL,'2026-09-21 08:43:45','2026-09-28 08:20:19','{title: Παλιομισοφόρια}

{verse: Verse}
[D]Ένα βράδυ στην Καστέλα
σε μια όμορ[A]φη κο[D]πέλα
[D]που ''παιρνε τ'' απεριτίφ της
ρίχτηκε ένας [A]τσίφτης απ'' την Κοκκι[D]νιά

{verse: Verse}
[D]Δεν εγνώριζε όμως ότι
τα ''χε μ'' [A]ένα πειραι[D]ώτη
[D]Πειραιώτη ντερμπεντέρη
σίδερο στο [A]χέρι, άσο στη μπου[D]νιά

{verse: Chorus}
[Em]Αχ, ρε παλιομισο[D]φόρια, τι τραβάν για σάς τ'' [A]αγόρια   | 2x
τι τραβάν για σάς τ'' α[D]γόρια                          | 2x

{verse: Verse}
[D]Αλλά και ο κοκκινιώτης
ήταν παλι[A]κάρι [D]πρώτης
[D]Και στο τέλος και οι δύο
στο νοσοκο[A]μείο πήγαν σηκω[D]τοί

{verse: Verse}
[D]Και οι δύο σε αφασία
μα ε[A]κείνη σημα[D]σία
[D]που τους έφαγ'' η μαρμάγκα
και με άλλο [A]μάγκα έκανε χα[D]ρτί

{verse: Chorus}
[Em]Αχ, ρε παλιομισο[D]φόρια, τι τραβάν για σάς τ'' [A]αγόρια   | 2x
τι τραβάν για σάς τ'' α[D]γόρια                          | 2x',NULL),
	 ('Για το καλό μου',18,NULL,0,NULL,'2026-09-21 08:50:47','2026-09-28 08:20:42','{title: Για το καλό μου}

{verse: Verse}
[Am]Eίδα ένα κόσμο να γκρε[G]μίζεται [C]μπροστά μου
είδα να [D]γίνεται γιαπί η γειτο[F]νιά μου, [G]για το κα[Am]λό μου
[Am]Eίδα τα δέντρα που σκαρ[G]φάλωνα κομ[C]μένα
σε φορτη[D]γό τα όνειρά μου φορτω[F]μένα, [G]για το κα[Am]λό μου

{verse: Verse}
[C]Eίδα το δάσκαλο να με χτυπάει με ζήλο
[C]είδα τα χέρια μου πρησμένα από το ξύλο
[Am]Είδα τα νεύρα μου σι[E]γά-σιγά να [Am]σπάνε
με καλοσύνη και στορ[E]γή να με χτυ[F]πάνε [G]

{verse: Chorus}
Για το κα[Am]λό μου, για το κα[E]λό μου
ώσπου δεν [Am]άντεξε στο τέλος το μυα[F]λό μου
Πήρε α[C]νάποδες στροφές για το κα[F]λό μου
και είμαι [C]στο θάλαμο εννιά για το κα[G]λό μου
στην ηρε[F]μία, για να [G]βρω τον εαυ[Am]τό μου

{verse: Verse}
[Am]Eίδα να κόβουν τη μπου[G]κιά για την μπου[C]κιά μου
ρούχα να [D]φτιάχνουν απ'' τα ρούχα [F]τα παλιά μου, [G]για το κα[Am]λό μου
[AM]Eίδα τη μάνα μου να [G]κλαίει απελπι[C]σμένα
είδα το [D]γέρο μου να φεύγει [F]για τα ξένα, [G]για το κα[Am]λό μου

{verse: Verse}
[C]Eίδα τους φίλους μου να σκίζονται για μένα
[C]είδα να θέλουν να ξεκόψω από σένα
[Am]Είδα χαράματα να [E]με τραβάν στο [Am]τμήμα
για να γλιτώσω το κε[E]λί να πω το [F]ποίημα [G]

{verse: Chorus}
Για το κα[Am]λό μου, για το κα[E]λό μου
ώσπου δεν [Am]άντεξε στο τέλος το μυα[F]λό μου
Πήρε α[C]νάποδες στροφές για το κα[F]λό μου
και είμαι [C]στο θάλαμο εννιά για το κα[G]λό μου
στην ηρε[F]μία, για να [G]βρω τον εαυ[Am]τό μου

{verse: Chorus}
Για το κα[Am]λό μου, για το κα[E]λό μου
έχει μου[Am]διάσει το κορμί και το [F]μυαλό μου
ενέσεις, [C]χάπια, ηλεκτροσόκ για το κα[F]λό μου
Σήμερα [C]πήρανε νεκρό τον διπλα[G]νό μου
ενώ πα[C]λεύω για να βρω τον εαυ[G]τό μου
κι έχω κρυ[F]μμένο το σου[G]γιά για το κα[Am]λό μου',NULL),
	 ('Θα σαγαπώ',57,NULL,0,NULL,'2026-09-21 09:00:33','2026-10-07 09:17:47','{title: Θα σαγαπώ}

{verse: Verse}
Ώσπου η [Am]γη να μη γυρίζει [F]πια
Ώσπου [Dm]το φως να γίνει σκο[G]τεινιά
Ώσπου [Am]κι αυτός ο ήλιος να [F]σβηστεί
Ώσπου [Dm]ο χρόνος πια να ξε[E]χαστεί
Θα σ'' α[Am]γαπώ

{verse: Verse}
Ώσπου [Am]στα μάτια σου να δω [F]φωτιές
Ώσπου [Dm]κι εσύ σαν κεραυνός [G]θα καις
Ώσπου [Am]να πάψει η ανατο[F]λή
Θα σ'' αγα[Dm]πώ και πάλι πιο [E]πολύ
Θα σ'' αγα[Am]πώ

{verse: Chorus}
Θα σ'' αγα[F]πώ όσο κανείς δεν αγα[Dm]πάει
Θα σ'' α[C]γαπώ
Με μιαν α[F]γάπη που ο νους σου δε χω[Dm]ράει
Θα σ'' αγα[E]πώ

{verse: Verse}
Ώσπου η [Am]γη να μη γυρίζει [F]πια
Ώσπου [Dm]το φως να γίνει σκο[G]τεινιά
Ώσπου [Am]κι αυτός ο ήλιος να [F]σβηστεί
Ώσπου [Dm]ο χρόνος πια να ξε[E]χαστεί
Θα σ'' α[Am]γαπώ

{verse: Verse}
Ώσπου [Am]στα μάτια σου να δω φω[F]τιές
Ώσπου [Dm]κι εσύ σαν κεραυνός [G]θα καις
Ώσπου [Am]να πάψει η ανατο[F]λή
Θα σ'' αγα[Dm]πώ και πάλι πιο πο[E]λύ
Θα σ'' αγα[Am]πώ

{verse: Chorus}
Θα σ'' αγα[F]πώ όσο κανείς δεν αγα[Dm]πάει
Θα σ'' α[C]γαπώ
Με μιαν α[F]γάπη που ο νους σου δε χω[Dm]ράει
Θα σ'' αγα[E]πώ

{verse: Verse}
Πέρα από [Am]κει που φτάνει η αντο[F]χή
Θα σ'' α[Dm]γαπώ και πάλι πιο πο[G]λύ
Μέχρι το [Am]θάνατο και πιο μα[F]κριά
Μέχρι να [Dm]πεις πεθαίνω τώρα [E]πια
Θα σ'' αγα[Am]πώ',NULL),
	 ('Γιατί γλυκιά μου κλαις',70,NULL,0,NULL,'2026-09-21 09:04:27','2026-09-28 08:21:24','{title: Γιατί γλυκιά μου κλαις}
{verse: Intro}
[Em] [Am] [D] [Em]

{verse: Verse}
[Em]Γιατί γλυκιά μου [D]κλαις, για[Em]τί γλυκιά μου [D]κλαις
για[G]τί γλυκιά μου [Am]κλαις και [D]σήμερα και [G]χτες
και [Em]την καρδιά μου [D]σκίζεις, χω[Em]ρίς να μου το λες

{verse: Verse}
[G]Θαρρείς δεν σ'' αγαπώ, θαρρείς δεν σ'' αγαπώ
θαρ[Em]ρείς δεν σ'' αγα[Am]πώ μα ε[D]γώ όμως προτι[G]μώ
τη [Em]μαύρη γης να [D]πάρω, πα[Em]ρά να σ'' αρνηθώ

{verse: Verse}
[Em]Γιατί γλυκιά μου [D]κλαις, για[Em]τί γλυκιά μου [D]κλαις
για[G]τί γλυκιά μου [Am]κλαις και [D]σήμερα και [G]χτες
και [Em]την καρδιά μου [D]σκίζεις, χω[Em]ρίς να μου το λες

{verse: Verse}
[G]Και να ''χα δυο καρδιές, και να ''χα δυο καρδιές
και [Em]να ''χα δυο καρ[Am]διές, ε[E]σένα δυο φο[G]ρές
και [Em]πάλι θ'' αγα[D]πούσα, γλυ[Em]κιά μου και μην κλαις

{verse: Verse}
[G]Θαρρείς δεν σ'' αγαπώ, θαρρείς δεν σ'' αγαπώ
θαρ[Em]ρείς δεν σ'' αγα[Am]πώ μα ε[D]γώ όμως προτι[G]μώ
τη [Em]μαύρη γης να [D]πάρω, πα[Em]ρά να σ'' αρνηθώ

{verse: Verse}
[G]Και να ''χα δυο καρδιές, και να ''χα δυο καρδιές
και [Em]να ''χα δυο καρ[Am]διές, ε[E]σένα δυο φο[G]ρές
και [Em]πάλι θ'' αγα[D]πούσα, γλυ[Em]κιά μου και μην κλαις',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Μη γυρίσεις',47,NULL,0,NULL,'2026-09-21 09:12:41','2026-09-28 08:21:46','{title: Μη γυρίσεις}
{verse: Intro}
[Em] [C] [D]

{verse: Verse}
[D]Για θυμήσου καλά
[C]Μήπως έχεις χαθεί μέσα σε [Bm]δρόμους που [Em]καίνε
[C] [D] Βάλε εσύ μια φωνή
[C]Και αν δεν είμαι εκεί [Bm]Χάρη να μη με [Em]λένε

{verse: Verse}
[D]Δεν είναι η ανάγκη
[C]Δεν είναι η μοναξιά που ε[Bm]κεί θα με [Em]φέρει
[D]Έχω αντέξει πολλά
[C]Δε με ξέρεις καλά κα[Bm]νείς δε με [Em]ξέρει

{verse: Chorus}
[Em][C]Μη γυρίσεις,   [D]τίποτα μη ζη[Bm]τήσεις
[Em]Για ένα [C]βράδυ   [D]μη με χαρα[Bm]μίσεις
[Em][C]Μη γυρίσεις,   [D]τίποτα μη ζη[Bm]τήσεις
[Em]Για ένα [C]βράδυ   [D]μη με χαρα[Em]μίσεις [Em]

{verse: Verse}
[D]Μπαίνω μες στη σκιά
[C]Με τυφλώνει το φως, μ''  αρρω[Bm]σταίνουν οι [Em]λέξεις
[D]Έχω βαρεθεί
[C]Δε θέλω να εξηγώ πρέπει ε[Bm]σύ να δια[Em]λέξεις

{verse: Verse}
[D]Όμως στο λέω ξανά
[C]Μήπως έχεις χαθεί μέσα σε [Bm]δρόμους που [Em]καίνε
[D]Βάλε εσύ μια φωνή
[C]Και αν δεν είμαι εκεί [Bm]Χάρη να μη με [Em]λένε

{verse: Chorus}
[Em][C]Μη γυρίσεις,   [D]τίποτα μη ζη[Bm]τήσεις
[Em]Για ένα [C]βράδυ   [D]μη με χαρα[Bm]μίσεις
[Em][C]Μη γυρίσεις,   [D]τίποτα μη ζη[Bm]τήσεις
[Em]Για ένα [C]βράδυ   [D]μη με χαρα[Em]μίσεις [Em]',NULL),
	 ('Όλου του κόσμου οι κυριακές',68,NULL,0,NULL,'2026-09-21 09:17:38','2026-10-26 10:53:34','{title: Όλου του κόσμου οι κυριακές}

{verse: Verse}
[Am]Όλες του κόσμου οι [E]Κυριακές λάμπουν στο πρόσω[Am]πό σου
[Am]Τι χρώματα, τι [E]μουσικές μες στο χαμόγε[Am]λό σου
[Dm]Τι χρώματα, τι [A]μουσικές μες στο χαμόγε[Dm]λό σου
[E]Όλες του κόσμου οι Κυριακές λάμπουν στο πρόσω[Am]πό σου

{verse: Chorus}
Σαν τη φω[E]τιά είσαι ζε[Dm]στός, είσαι ο [E]ίδιος ο Χριστός
Ένας Χρι[E]στός της γειτο[Dm]νιάς, που ξέρει [B7]τι θα πει χιο[Am]νιάς

{verse: Verse}
[Am]Τι όμορφο να [E]σ'' αγαπώ και να σε καρτε[Am]ράω
[Am]Να σου γλυκαίνω [E]τον καημό, να σε παρηγο[Am]ράω
[Dm]Να σου γλυκαίνω [A]τον καημό, να σε παρηγο[Dm]ράω
[E]Τι όμορφο να σ'' αγαπώ και να σε καρτεράω

{verse: Chorus}
Σαν τη φω[E]τιά είσαι ζε[Dm]στός, είσαι ο [E]ίδιος ο Χριστός
Ένας Χρι[E]στός της γειτο[Dm]νιάς, που ξέρει [B7]τι θα πει χιο[Am]νιάς',NULL),
	 ('Όλα σε θυμίζουν',68,NULL,0,NULL,'2026-09-21 09:24:30','2026-09-28 08:22:18','{title: Όλα σε θυμίζουν}

{verse: Verse}
[Em]Όλα σε θυμίζουν, απλά κι αγαπημέ[F]να
[Dm]πράγματα δικά σου, [F]καθημερι[Em]νά
[Em]Σα να περιμένουν και αυτά μαζί με μέ[F]να
[Dm]να ''ρθεις κι ας χαράξει [F]για στερνή φο[Em]ρά

{verse: Verse}
[Em]Όλη μας η αγάπη την [Dm]κάμαρα γεμί[Am]ζει
σαν ένα τραγού[Dm]δι που λέγαμε κι οι [Em]δυο
[Em]Πρόσωπα και λόγια και [Dm]τ'' όνειρο που τρί[Am]ζει
[Em]σαν θα ξημερώ[Dm]σει τι θα ''ναι αληθι[Em]νό

{verse: Chorus}
[Em]Όλα σε θυμίζουν, απλά κι αγαπημέ[F]να
[Dm]πράγματα δικά σου, [F]καθημερι[Em]νά
[Em]Σα να περιμένουν και αυτά μαζί με μέ[F]να
[Dm]να ''ρθεις κι ας χαράξει [F]για στερνή φο[Em]ρά

{verse: Verse}
[Em]Όλα σε θυμίζουν, κι οι πιο καλοί μας φί[F]λοι
[Dm]άλλος στην ταβέρνα, [F]άλλος σινε[Em]μά
[Em]Μόνη μου διαβάζω, το γράμμα που ''χες στεί[F]λει
[Dm]πριν να φιληθούμε [F]πρώτη μας φο[Em]ρά

{verse: Verse}
[Em]Όλα σε θυμίζουν, απλά κι αγαπημέ[F]να
[Dm]πράγματα δικά σου, [F]καθημερι[Em]νά
[Em]Σα να περιμένουν και αυτά μαζί με μέ[F]να
[Dm]να ''ρθεις κι ας χαράξει [F]για στερνή φο[Em]ρά

{verse: Chorus}
[Em]Όλη μας η αγάπη την [Dm]κάμαρα γεμί[Am]ζει
σαν ένα τραγού[Dm]δι που λέγαμε κι οι [Em]δυο
[Em]Πρόσωπα και λόγια και [Dm]τ'' όνειρο που τρί[Am]ζει
[Em]σαν θα ξημερώ[Dm]σει τι θα ''ναι αληθι[Em]νό',NULL),
	 ('Μάφησες σαν πόλη τουρκεμένη',68,NULL,0,NULL,'2026-09-21 09:28:52','2026-09-28 08:22:32','{title: Μάφησες σαν πόλη τουρκεμένη}

{verse: Verse}
[Am]Μ'' άφησες σαν πόλη τουρκεμένη
μα το [F]δάκρυ γέλιο [Am]το ''ντυσα
[Am]Γύρισες μετά να δεις τι μένει
κι είπες [F]πως φρι[Am]χτά σε πρόδωσα

{verse: Chorus}
[F]Ύστερα βαριά [Em]πήρες το [F]δρόμο
ύστερα εγώ δεν είχα [Dm]τίπο[C]τα
[F]γέλιο ήρθε μόνο [EM]γέλιο με το [F]χρόνο
κι είπες πως σε πρόδωσα α[Dm]λύπη[E]τα

{verse: Verse}
[Am]Μ'' άφησες σαν πόλη τουρκεμένη
μα κρα[F]σί τον πόνο [Am]κέρασα
[Am]κι όταν δεν με είδες δακρυσμένη
είπες [F]πως φριχτά [Am]σε γέλασα

{verse: Chorus}
[F]Ύστερα βαριά [Em]πήρες το [F]δρόμο
ύστερα εγώ δεν είχα [Dm]τίπο[C]τα
[F]γέλιο ήρθε μόνο [EM]γέλιο με το [F]χρόνο
κι είπες πως σε πρόδωσα α[Dm]λύπη[E]τα',NULL),
	 ('Ποιος να συγκριθεί μαζί σου',9,NULL,0,NULL,'2026-09-21 09:38:07','2026-09-28 08:22:45','{title: Ποιος να συγκριθεί μαζί σου}

{verse: Verse}
[E]Ποιός να συγκριθεί μα[Am]ζί σου
[F]κι από το νου μου να σε [C]σβήσει
Ποιος στο βάθος της ψυ[Am]χής μου
[F]θα τολμήσει να σ'' α[Em]γγίξει

{verse: Chorus}
[G]Μετά από σένα [C]που, πες μου να πάω [G]που
μετά από σένα [Dm]τι, τι ν'' αγαπή[Am]σω τι
Μετά από σένα [F]ποιόν,  ποιόν αν πιστέψω [Em]ποιόν
μετά από σένα [Dm]πως, να ζήσω άλλο [E]πως
Ποίος να συγκριθεί μα[Am]ζί σου

{verse: Verse}
[E]Ποίος να συγκριθεί μα[Am]ζί σου
[F]όταν φύγεις μακρι[C]ά μου
Ποίος τη θέση σου να [Am]πάρει
[F]στο κορμί και στην καρ[Em]διά μου

{verse: Chorus}
[G]Μετά από σένα [C]που, πες μου να πάω [G]που
μετά από σένα [Dm]τι, τι ν'' αγαπή[Am]σω τι
Μετά από σένα [F]ποιόν,  ποιόν αν πιστέψω [Em]ποιόν
μετά από σένα [Dm]πως, να ζήσω άλλο [E]πως
Ποίος να συγκριθεί μα[Am]ζί σου',NULL),
	 ('Κάνε λιγάκι υπομονή',6,NULL,0,NULL,'2026-09-21 09:42:27','2026-09-28 08:22:53','{title: Κάνε λιγάκι υπομονή}

{verse: Verse}
[Am]Μην απελπίζεσαι και δεν θ'' αργήσει
κοντά σου [Dm]να ''ρθει μια χαραυ[E]γή
[G]Καινούργια α[C]γάπη να σου ζη[E]τήσει  | 2x
Κάνε λι[Am]γάκι υπομονή              | 2x

{verse: Verse}
[Am]Διώξε τα σύννεφα απ'' την καρδιά σου
και μες στο [Dm]κλάμα μη ξαγρυ[E]πνάς
[G]Τι κι αν δεν [C]βρίσκεται στην αγκα[E]λιά σου  | 2x
θα ''ρθει μια [Am]μέρα, μην το ξεχνάς         | 2x

{verse: Verse}
[Am]Γλυκοχαράματα θα σε ξυπνήσει
κι ο έρω[Dm]τάς σας θ'' αναστη[E]θεί
[G]Καινούργια α[C]γάπη θα ξανα[E]ζήσεις  | 2x
κάνε λι[Am]γάκι υπομονή             | 2x',NULL),
	 ('Ρίξε κόκκινο στη νύχτα',46,NULL,0,NULL,'2026-09-21 09:54:57','2026-09-28 08:23:14','{title: Ρίξε κόκκινο στη νύχτα}

{verse: Verse}
[A]Σκληρή, πικρή βροχή
βράδυ Σα[G]ββάτο
το δε[A]λτίο των εννιά πουλάει
τη μοναξιά μου
τη ζωή μου που γλι[G]στράει

{verse: Verse}
[D]Μα υπάρχω ακόμα είμ'' ακόμα ε[A]δώ
[D]Παίρνω ανάσα και χρώμα σε τροχιά άλλη πε[E]τώ

{verse: Chorus}
[A]Ρίξε κόκκινο στη νύχτα
ρίξε λάδι στη φωτιά
[G]Ωωωωωωω, [D]ωωωωωωωω, ωω
[A]Απ'' όσα έχω ζήσει
ζητάω πιο πολλά
[G]Ωωωωωωω, [D]ωωωωωωωω, ωω

{verse: Verse}
[A]Ζεστή η παλιά σκουριά
βρέχει α[G]πόψε
Το δελ[A]τίο των εννιά πουλάει
τοίχοι που πέφτουν
στα ερείπια γλε[G]ντάει

{verse: Verse}
[D]Μα υπάρχω ακόμα είμ'' ακόμα ε[A]δώ
[D]Παίρνω ανάσα και χρώμα σε τροχιά άλλη πε[E]τώ

{verse: Chorus}
[A]Ρίξε κόκκινο στη νύχτα
ρίξε λάδι στη φωτιά
[G]Ωωωωωωω, [D]ωωωωωωωω, ωω
[A]Απ'' όσα έχω ζήσει
ζητάω πιο πολλά
[G]Ωωωωωωω, [D]ωωωωωωωω, ωω',NULL),
	 ('The house of the rising sun',71,NULL,0,NULL,'2026-09-21 10:12:11','2026-09-28 07:34:27','{title: The house of the rising sun}
{verse: Intro}
[Am] [C] [D] [F]
[Am] [E] [Am] [E]
 
{verse: Verse}
There [Am]is a [C]house in [D]New Or[F]leans
They [Am]call the [C]Risin'' [E]Sun
And it''s [Am]been the [C]ruin of [D]many a poor [F]boy.
And [Am]God, I [E]know I''m [Am]one.
 
{verse: Instrumental}
[C] [D] [F]
[Am] [E] [Am] [E]
 
{verse: Verse}
My [Am]mother [C]was a [D]tailor. [F]
She [Am]sewed my [C]new blue [E]jeans.
My [Am]father [C]was a [D]gamblin'' [F]man
[Am]Down in [E]New Or-[Am]leans.
 
{verse: Instrumental}
[C] [D] [F]
[Am] [E] [Am] [E]
 
{verse: Verse}
Now, the [Am]only [C]thing a [D]gambler [F]needs
Is a [Am]suitcase [C]and a [E]trunk
And the [Am]only t[C]ime that [D]he''s satis[F]fied
Is [Am]when he''s [E]on a [Am]drunk
 
{verse: Instrumental}
[C] [D] [F]
[Am] [E] [Am] [E]
 
{verse: Verse}
Oh, [Am]Mother, [C]tell your [D]children [F]
Not to [Am]do what [C]I have [E]done.
[Am]Spend your [C]lives in [D]sin and mise[F]ry
In the [Am]house of [E]the risin'' [Am]sun.
 
{verse: Instrumental}
[C] [D] [F]
[Am] [E] [Am] [E]
 
{verse: Verse}
Well, I''ve [Am]got one [C]foot on the [D]platform, [F]
the [Am]other [C]foot on the [E]train.
I''m [Am]goin'' [C]back to [D]New Or[F]leans
To [Am]wear that [E]ball and [Am]chain.
 
{verse: Instrumental}
[C] [D] [F]
[Am] [E] [Am] [E]',NULL),
	 ('The temple of the King',72,NULL,0,NULL,'2026-09-21 11:18:17','2026-09-30 14:26:57','{title: Temple of the King}
{verse: Intro}
[Am] [G] [Dm] [Am]

{verse: Verse}
[C]One day in the [G]year of the fox
Came a [Dm]time remembered [Am]well
When the [F]strong young man
Of the [G]rising sun heard the
[Am]Tolling of the great black bell

{verse: Verse} 
[C]One day in the [G]year of the fox when the
[E]Bell began to [Am]ring, it meant the
[F]Time had come for the [G]one to go to the
[Am]Temple of the King

{verse: Chorus}
[Dm]There in the middle of the circle, he stands
[Am]Searching, Seeking,
With [G]just one touch of his trembling hand
The [Am]answer will be found

{verse: Chorus}
[Dm]Daylight waits while the old man sings
[Am]Heaven, help me,
[G]Just like a rush of thousand wings 
It [E]shines upon the One
And the [F]day has [G]just [Am]begun
 
{verse: Instrumental}
[Am] [F] [G] [Am]
[Am] [G] [Dm] [F] [Am]

{verse: Verse}
[C]One day in the [G]year of the fox
Came a [Dm]time remembered [Am]well
When the [F]strong young man
Of the [G]rising sun heard the
[Am]Tolling of the great black bell

{verse: Verse}
[C]One day in the [G]year of the fox when the
[E]Bell began to [Am]sing, it meant the
[F]Time had come for the [G]one to go to the
[Am]Temple of the King
 
[Dm]There in the middle of people he stands
[Am]Seeing, feeling
[G]Just a wave of the strong right hand
He''s [E]gone, to the
[F]Temple [F]of the [Am]King
 
{verse: Instrumental}
[Am] [F] [G] [Am]
[Am] [G] [Dm] [F] [Am]

{verse: Chorus}
[Dm]Far from the circle of the edge of the world
He''s [Am]hoping, wondering
[G]Thinking back of the stories he''s heard
[Am]what he''s going to see
[Dm]There in the middle of the circle he lies
[Am]Heaven, help me
[G]All could see by the shine in his eyes
The [E]answer has been found

{verse: Chorus}
[Dm]Back with the people in the circle he stands
[Am]Giving, feeling
With [G]just one touch of the strong right hand they [E]know
Of the [F]Temple [G]and the [Am]King
 
{verse: Instrumental}
[Am] [F] [G] [Am]
[Am] [G] [Dm] [F] [Am]',NULL),
	 ('Good Riddance',73,NULL,0,NULL,'2026-09-21 11:25:43','2026-09-28 07:35:12','{title: Good Riddance}
{verse: Intro}
[G] [C] [D]
[G] [C] [D]
 
{verse: Verse}
[G]Another turning point, a [C]fork stuck in the [D]road
[G]Time grabs you by the wrist, [C]directs you where to [D]go
[Em]So make the [D]best of this [C]test and don''t ask [G]why
[Em]It''s not a [D]question but a [C]lesson learned in [G]time
 
{verse: Chorus}
It''s [Em]something unpre[G]dictable but [Em]in the end it''s [G]right
I [Em]hope you had the [D]time of your [G]life
 
{verse: Interlude}
[G] [C] [D]
[G] [C] [D]
 
{verse: Verse}
[G]So take the photographs and [C]still frames in your [D]mind
[G]Hang it on a shelf, in [C]good health and good [D]time
[Em]Tattoos of [D]memories and [C]dead skin on [G]trial
[Em]For what it''s [D]worth it was [C]worth all the [G]while
 
{verse: Chorus}
It''s [Em]something unpre[G]dictable but [Em]in the end it''s [G]right
I [Em]hope you had the [D]time of your [G]life

It''s [Em]something unpre[G]dictable but [Em]in the end it''s [G]right
I [Em]hope you had the [D]time of your [G]life',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Ready for love',74,NULL,0,NULL,'2026-09-21 11:55:44','2026-10-26 11:15:34','{title: Ready for love}
{verse: Verse}
[Am]Walkin'' down this [C]rocky road
[D]Wonderin'' where my [C]life is leading
[Am]Rollin'' on [C]to the bitter [D]end
[Am]Finding out a[C]long the way [D]what it takes to [C]keep love living
[Am]You should know [C]how it feels my [D]friend
 
{verse: Chorus}
[Am]Oo I want you to sta[D]y
[Am]Oo I want you to[C]day [D]
I''m [Am]ready for love oh baby I''m [D]ready for love
[Am]Ready for love oh baby I''m [D]ready for love
 
[C] [G] [Am]Oh [G] [F]
      
[G]For your [Am]love
 
{verse: Verse}
[Am]Now I''m on my [C]feet again
[D]Better things are [C]bound to happen
[Am]All my dues surely must be [D]paid
[Am]Many miles and [C]many tears
[D]Times were hard but [C]now they''re changing
[Am]You should know [C]that I''m not a[D]fraid
 
{verse: Chorus}
[Am]Oo I want you to sta[D]y
[Am]Oo I want you to[C]day [D]
I''m [Am]ready for love oh baby I''m [D]ready for love
[Am]Ready for love oh baby I''m [D]ready for love
 
[C] [G] [Am]Oh [G] [F]
      
[G]For your [Am]love',NULL),
	 ('Wind of change',34,NULL,0,NULL,'2026-09-21 12:26:14','2026-09-28 07:36:13','{title: Wind of change}
{verse: Intro}
[F] [Dm] x2
[Am] [Dm] [Am] [G]
 
{verse: Verse}
[C]I follow the Mosk[Dm]va,
Down to Gorky [C]Park,
Listening to the [Dm]wind of [Am]chan[G]ge...
[C]An August summer [Dm]night,
Soldiers passing [C]by,
Listening to the [Dm]wind of [Am]chan[G]ge...
 
{verse: Interlude}
[F] [Dm] x2
[Am] [Dm] [Am] [G]
 
{verse: Verse}
[C]The world is closing [Dm]in,
Did you ever [C]think,
That we could be so [Dm]close, like [Am]bro[G]thers?
[C]The future''s in the [Dm]air,
I can feel it every[C]where,
Blowing with the [Dm]wind of [Am]chan[G]ge...
 
{verse: Chorus}
[C]Take [G]me to the [Dm]magic of the [G]moment
On a [C]glory [G]night
Where the [Dm]children of to[G]morrow
Dream a[Am]way
[F]In the wind of [G]change [C]
 
{verse: Verse}
[C]Walking down the [Dm]street
Distant memo[C]ries
Are buried in the [Dm]past fo[Am]re[G]ver
[C]I follow the Mosk[Dm]va
Down to Gorky [C]Park
Listening to the [Dm]wind of [Am]chan[G]ge...
 
{verse: Chorus}
[C]Take [G]me to the [Dm]magic of the [G]moment
On a [C]glory [G]night
Where the [Dm]children of to[G]morrow
Share their [Am]dreams
[F]with you and[G]me [C]
 
[C]Take [G]me to the [Dm]magic of the [G]moment
On a [C]glory [G]night
Where the [Dm]children of to[G]morrow
Dream a[Am]way
[F]In the wind of [G]change [C]
 
{verse: Bridge}
[Am]The wind of change blows [G]straight
Into the face of [Am]time
Like a stormwind that will [G]ring
The freedom bell for peace of [C]mind
Let your balalaika [Dm]sing
What my guitar wants to [E]say
 
{verse: Solo}
[F] [G] [E] [Am] [F] [G] [Am]
[F] [G] [E] [Am] [Dm] [E]
 
{verse: Chorus}
[C]Take [G]me to the [Dm]magic of the [G]moment
On a [C]glory [G]night
Where the [Dm]children of to[G]morrow
Share their [Am]dreams
[F]with you and[G]me [C]
 
[C]Take [G]me to the [Dm]magic of the [G]moment
On a [C]glory [G]night
Where the [Dm]children of to[G]morrow
Dream a[Am]way
[F]In the wind of [G]change [C]
 
{verse: Outro}
[F] [Dm] x2
[Am] [Dm]',NULL),
	 ('Παράνομή μου αγάπη',7,NULL,0,NULL,'2026-09-21 13:31:50','2026-10-12 13:24:06','{title: Παράνομή μου αγάπη}

{verse: Verse}
[Em]Τόσες και τόσες α[Dm]γάπες μου [Em]τύχαν
καμιά δεν [G]στέριω[Dm]σα κα[Em]μιά
[Am]μα η δική σου, που είναι πα[Dm]ράνομη
σαν τον μα[G]γνήτη [Dm]με τρα[Em]βά
[Em]Σε κάθε [Am]βήμα μου, σε κάθε [G]σκέψη
με κουμα[Gm]ντάρει με κυβερ[Em]νά

{verse: Chorus}
[Em]Παράνομή μου α[Dm]γάπη, πικρό μου [Em]ριζικό
απ'' όλα μου τα [G]λάθη [Gm]είσαι το [Em]πιο γλυκό

{verse: Verse}
[Em]Ήθελα να ''ξερα [Dm]τι μου ''χεις [Em]κάνει
και σαν θε[G]ό μου [Dm]σ'' αγα[Em]πώ
[Am]αφού το βλέπω, εγώ από [Dm]σένανε
ποτέ στε[G]φάνι [Dm]δεν θα [Em]δω
[Em]θαρρείς η [Am]μοίρα μου μ'' έχει τυ[G]φλώσει
κι όπου και [Gm]να ''σαι σ'' ακολου[Em]θώ

{verse: Chorus}
[Em]Παράνομή μου α[Dm]γάπη, πικρό μου [Em]ριζικό
απ'' όλα μου τα [G]λάθη [Gm]είσαι το [Em]πιο γλυκό',NULL),
	 ('Fast Car',75,NULL,0,NULL,'2026-09-21 13:50:16','2026-09-28 07:38:30','{title: Fast Car}
{verse: Intro}
[C] [G] [Em] [D]       x4
 
{verse: Verse}
[C]You got a fast [G]car.
[Em]I want a ticket to [D]anywhere.
[C]Maybe we make a [G]deal,
[Em]Maybe together we can [D]get somewhere.
[C]Any place is [G]better.
[Em]Starting from zero, [D]got nothing to lose.
[C]Maybe we''ll make some[G]thing,
[Em]Me myself, I got nothing to [D]prove.
 
{verse: Instrumental}
[C] [G] [Em] [D]       x2
 
{verse: Verse}
[C]You got a fast [G]car
[Em]I got a plan to [D]get us out of here:
[C]I been working at the co[G]nvenience store,
[Em]Managed to save just a [D]little bit of money.
[C]Wont''t have to drive too [G]far
[Em]Just across the border and [D]into the city,
[C]You and I can [G]both get jobs
[Em]And finally see what it [D]means to be living.
 
{verse: Instrumental}
[C] [G] [Em] [D]       x2
 
{verse: Verse}
[C]You see my old [G]man''s got a problem:
[Em]He live with the [D]bottle, that''s the way it is.
[C]He says his body''s too [G]old for working,
[Em]His body''s too young to [D]look like his.
[C]My mama went off [G]and left him,
[Em]she wanted more from[D] life than he could give,
[C]I said, "Somebody''s got to [G]take care of him."
[Em]So I quit school and [D]that''s what I did.
 
{verse: Instrumental}
[C] [G] [Em] [D]       x2
 
{verse: Verse}
[C]You got a fast [G]car
[Em]But is it fast enough so we can fly [D]away?
[C]We gotta make a de[G]cision:
[Em]Leave tonight or live and [D]die this way.
 
{verse: Instrumental}
[C] [G] [Em] [D] [C] [G]
 
{verse: Chorus}
[Em]I re[D]member when we were [C]driving, driving in your car,
The [G]speed so fast I felt like I was drunk,
[Em]City lights lay out before us
And your [D]arm felt nice wrapped ''round my shoulder.
And [C]I_____[Em] had a [D]feeling that I belonged
And [C]I_____[Em] had a [D]feeling I could be [C]someone, [D]be someone, be someone.
 
{verse: Instrumental}
[C] [G] [Em] [D]       x2
 
{verse: Verse}
[C]You got a fast [G]car
[Em]And we go cruising to enter[D]tain ourselves;
[C]You still ain''t got a [G]job
[Em]And I work in a market as a [D]checkout girl.
[C]I know things will get [G]better:
[Em]You''ll find work and [D]I''ll get promoted,
[C]We''ll move out of the [G]shelter
[Em]Buy a bigger house and [D]live in the suburbs.
 
{verse: Instrumental}
[C] [G] [Em] [D] [C] [G]
 
{verse: Chorus}
[Em]I re[D]member when we were [C]driving, driving in your car,
The [G]speed so fast I felt like I was drunk,
[Em]City lights lay out before us
And your [D]arm felt nice wrapped ''round my shoulder.
And [C]I_____[Em] had a [D]feeling that I belonged
And [C]I_____[Em] had a [D]feeling I could be [C]someone, [D]be someone, be someone.
 
{verse: Instrumental}
[C] [G] [Em] [D]       x2
 
{verse: Verse}
[C]You got a fast [G]car
[Em]And I got a job that [D]pays all our bills.
[C]You stay out drinking [G]late at the bar,
[Em]See more your friends than you [D]do your kids.
[C]I''d always hoped for [G]better,
[Em]Thought maybe together you and me [D]would find it,
[C]I got no plans, I ain''t going [G]nowhere,
[Em]so take your fast car and keep on [D]driving.
 
{verse: Instrumental}
[C] [G] [Em] [D] [C] [G]
 
{verse: Chorus}
[Em]I re[D]member when we were [C]driving, driving in your car,
The [G]speed so fast I felt like I was drunk,
[Em]City lights lay out before us
And your [D]arm felt nice wrapped ''round my shoulder.
And [C]I_____[Em] had a [D]feeling that I belonged
And [C]I_____[Em] had a [D]feeling I could be [C]someone, [D]be someone, be someone.

 
{verse: Instrumental}
[C] [G] [Em] [D]       x2
 
{verse: Verse}
[C]You got a fast [G]car
[Em]But is it [D]fast enough so you can fly away?
[C]You gotta make a de[G]cision:
[Em]Leave tonight or live and [D]die this way.
 
{verse: Outro}
[C] [G] [Em] [D]       x3
[C] [G]',NULL),
	 ('Ανάθεμά σε',77,NULL,0,NULL,'2026-09-24 08:56:16','2026-09-28 08:24:16','{title: Ανάθεμά σε}

{verse: Verse}
[Am]Σ'' έχω ώρες-ώρες μα το θεό
τόσο πο[G]λύ ανά[Am]γκη
[Dm]πού τρέχουν απ'' [Am]τα μάτια μου
[G]θάλασσες και πελά[Am]γη

{verse: Verse}
[Am]Στείλε ένα γράμμα μια συλλαβή
αν [G]έχεις τον θεό [Am]σου
[Dm]πού κρέμομαι απ'' τα [Am]χείλη σου
[G]κι είμαι στο έλεος [Am]σου

{verse: Chorus}
[Am]Ανάθεμά σε, [G]δε με λυ[Am]πάσαι
[G]πού καίγομαι και λιώ[C]νω
[Dm]πού μ'' έκανες και [Am]σ'' αγαπώ
[G]και τώρα μαραζώ[Am]νω

{verse: Verse}
[Am]Κλειδώθηκαν οι σκέψεις μου
μες [G]του μυαλού τα υπό[Am]γεια
[Dm]αχ πόσα θέλω [Am]να σου πω
[G]μα δεν υπάρχουν λό[Am]για

{verse: Verse}
[Am]Ανάθεμά σε, [G]δε με λυ[Am]πάσαι
[G]πού καίγομαι και λιώ[C]νω
[Dm]πού μ'' έκανες και [Am]σ'' αγαπώ
[G]και τώρα μαραζώ[Am]νω

{verse: Chorus}
[Dm]πού μ'' έκανες και [Am]σ'' αγαπώ
[G]και τώρα μαραζώ[Am]νω',NULL),
	 ('Boulevard of broken dreams',73,NULL,0,NULL,'2026-09-22 07:04:43','2026-10-08 09:23:34','{title: Boulevard of broken dreams}
[Em]I walk a [G]lonely road
The [D]only one that [A]I have ever [Em]known
Don''t know [G]where it goes
But [D]it''s home to [A]me and I walk a[Em]lone
I walk this [G]empty street
[D]On the Boule[A]vard of Broken [Em]Dreams
Where the [G]city sleeps
and [D]I''m the only [A]one and I walk [Em]alone

[Em] [G] [D] [A] -  x2
 
[C]My [G]shadow''s the [D]only one that [Em]walks beside me
[C]My [G]shallow [D]heart''s the only [Em]thing that''s beating
[C]Some[G]times I [D]wish someone out [Em]there will find me
[C]''Til [G]then I [B7]walk alone
 
[Em] [G] [D] [A] -  x2
       
[Em]I''m walking [G]down the line
[D]That divides me [A]somewhere in my [Em]mind
On the [G]border line
[D]Of the edge and [A]where I walk [Em]alone
 
Read be[G]tween the lines
[D]What''s fucked up and [A]everything''s al[Em]right
Check my [G]vital signs
To [D]know I''m still [A]alive and I walk [Em]alone
 
I walk [D]alone
I walk [Em]alone
 
I walk [D]alone
I walk [Em]a...
 
[C]My [G]shadow''s the [D]only one that [Em]walks beside me
[C]My [G]shallow [D]heart''s the only [Em]thing that''s beating
[C]Some[G]times I [D]wish someone out [Em]there will find me
[C]''Til [G]then I [B7]walk alone

Ah-[Em]ah, Ah-[G]ah, Ah-[D]ah, Aaah-[Em]ah
 
[Em]I walk this [G]empty street
[D]On the Boule[A]vard of Broken [Em]Dreams
[Em]Where the [G]city sleeps
And [D]I''m the only [A]one and I walk [Em]a...
 
[C]My [G]shadow''s the [D]only one that [Em]walks beside me
[C]My [G]shallow [D]heart''s the only [Em]thing that''s beating
[C]Some[G]times I [D]wish someone out [Em]there will find me
[C]''Til [G]then I [B7]walk alone',NULL),
	 ('Something in the way',3,NULL,0,NULL,'2026-09-22 09:03:04','2026-10-29 11:28:30','{title: Something in the way}
{verse: Intro}
[Em] [C]
 
{verse: Verse}
[Em]Underneath the [C]bridge
[Em]Tarp has sprung a [C]leak
And an [Em]animal I''ve [C]trapped
[Em]All become my [C]pets
And I''m [Em]living off of [C]grass
And the [Em]drippings from the [C]ceiling
And its [Em]O.K. to eat [C]fish
Cause they [Em]don''t  have any [C]feelings

{verse: Chorus}
[Em]Something in the [C]way
[Em]Mmmm......
[Em]Something in the [C]way
[Em]Mmmm......
 
{verse: Verse}
[Em]Underneath the [C]bridge
[Em]Tarp has sprung a [C]leak
And an [Em]animal I''ve [C]trapped
[Em]All become my [C]pets
And I''m [Em]living off of [C]grass
And the [Em]drippings from the [C]ceiling
And its [Em]O.K. to eat [C]fish
Cause they [Em]don''t  have any [C]feelings
 
{verse: Chorus}
[Em]Something in the [C]way
[Em]Mmmm......
[Em]Something in the [C]way
[Em]Mmmm......','D-D-D-UDUDU'),
	 ('Wonderwall',76,NULL,0,NULL,'2026-09-23 06:33:26','2026-09-28 07:42:29','{title: Wonderwall}
{verse: Intro}
[Em] [G] [D] [A]
 
{verse: Verse}
[Em]Today is [G]gonna be the day
That they''re [D]gonna throw it back to [A]you
[Em]By now you [G]should''ve somehow
Rea[D]lised what you gotta [A]do
[Em]I don''t believe that [G]anybody
[D]Feels the way I [A]do about you [C]now [D]
 
{verse: Verse}
[Em]Backbeat the [G]word is on the street
That the [D]fire in your heart is [A]out
[Em]I''m sure you''ve [G]heard it all before
But you [D]never really had a [A]doubt
[Em]I don''t believe that [G]anybody [D]feels
The way I [A]do about you [Em]now [G] [D] [A]
 
{verse: Prechorus}
And [C]all the roads we [D]have to walk are [Em]winding
And [C]all the lights that [D]lead us there are [Em]blinding
[C]There are many [D]things that I would
[G]Like to [D]say to [Em]you
But I don''t know [A]how
 
{verse: Chorus}
Because [C]maybe [G]
You''re [Em]gonna be the one that [C]saves me [G]
And [Em]after [C]all [G]
You''re my [Em]wonder[C]wall [G]
 
{verse: Verse}
[Em]Today was [G]gonna be the day
But they''ll [D]never throw it back to [A]you
[Em]By now you [G]should''ve somehow
Rea[D]lised what you''re not to [A]do
[Em]I don''t believe that [G]anybody
[D]Feels the way I [A]do
About you [Em]now [G] [D] [A]
 
{verse: Prechorus}
And [C]all the roads that [D]lead you there are [Em]winding
And [C]all the lights that [D]lead us there are [Em]blinding
[C]There are many [D]things that I would
[G]Like to [D]say to [Em]you
But I don''t know [A]how
 
{verse: Chorus}
Because [C]maybe [G]
You''re [Em]gonna be the one that [C]saves me [G]
And [Em]after [C]all [G]
You''re my [Em]wonder[C]wall [G]',NULL),
	 ('Μη μου ξαναφύγεις πια μάγκα μου',6,NULL,0,NULL,'2026-09-23 06:41:25','2026-09-28 08:23:59','{title: Μη μου ξαναφύγεις πια μάγκα μου}

{verse: Verse}
[G]Το ''ξερα μια μέρα πως θα ''ρθεις
και τις τρέλες σου θα βαρεθείς

{verse: Chorus}
[Am]Μη [Em]μου [B]ξαναφύγεις [Em]πια, [D]μάγκα [G]μου
[Am]Μεί[Em]νε [B]μες στην αγκα[Em]λιά μου
[Am]Μη [Em]μου [B]ξαναφύγεις [Em]πια, [D]μάγκα [G]μου
[Am]Μεί[Em]νε [B]μες στην αγκα[Em]λιά μου

{verse: Verse}
[G]Ήταν άδικος ο χωρισμός
και ανυπολόγιστα σκληρός

{verse: Chorus}
[Am]Μη [Em]μου [B]ξαναφύγεις [Em]πια, [D]μάγκα [G]μου
[Am]Μεί[Em]νε [B]μες στην αγκα[Em]λιά μου
[Am]Μη [Em]μου [B]ξαναφύγεις [Em]πια, [D]μάγκα [G]μου
[Am]Μεί[Em]νε [B]μες στην αγκα[Em]λιά μου

{verse: Verse}
[G]Βρέθηκα στη στράτα της ζωής
δίχως μάνα, δίχως συγγενείς

{verse: Chorus}
[Am]Μη [Em]μου [B]ξαναφύγεις [Em]πια, [D]μάγκα [G]μου
[Am]Μεί[Em]νε [B]μες στην αγκα[Em]λιά μου
[Am]Μη [Em]μου [B]ξαναφύγεις [Em]πια, [D]μάγκα [G]μου
[Am]Μεί[Em]νε [B]μες στην αγκα[Em]λιά μου',NULL),
	 ('Sweet home Alabama',22,NULL,0,NULL,'2026-09-23 07:35:56','2026-09-28 07:43:11','{title: Sweet home Alabama}
{verse: Intro}
[D] [C] [G]  x4
 
{verse: Verse}
[D]Big [C]wheels keep on [G]turning
[D]Carry me [C]home to see my [G]kin
[D]Singing [C]songs about the [G]south land
[D]I miss ole ''[C]bamy once [G]again and I think it''s a sin
 
{verse: Interlude}
[D] [C] [G]  x2
 
{verse: Verse}
[D]Well, I heard [C]Mr Young sing a[G]bout her
[D]Well, I heard old [C]Neil put her [G]down
[D]Well, I hope Neil [C]Young will re[G]member
[D]A southern [C]man don''t need him [G]around, anyhow
 
{verse: Chorus}
[D]Sweet [C]home Ala[G]bama [D], where the [C]skies are so [G]blue
[D]Sweet [C]home Ala[G]bama [D], Lord, I''m [C]coming home to [C]you

{verse: Interlude}
[D] [C] [G]  x2

{verse: Verse}
[D]In Birmin[C]gham they love the [G]Gov''nor, boo-hoo-hoo
[D]Now we all [C]did what we could [G]do
[D]Now Water[C]gate does not [G]bother me
[D]Does your [C]conscience bother [G]you (tell the truth!)
 
{verse: Chorus}
[D]Sweet [C]home Ala[G]bama [D], where the [C]skies are so [G]blue
[D]Sweet [C]home Ala[G]bama [D], Lord, I''m [C]coming home to [C]you
 
{verse: Verse}
[D]Now Muscle [C]Shoals has got the [G]Swampers
[D]And they''ve been [C]known to pick a [G]song or two (yes, we do)
[D]Lord, they [C]get me off [G]so much
[D]They pick me [C]up when I''m feeling [G]blue, now how ''bout you?
 
{verse: Chorus}
[D]Sweet [C]home Ala[G]bama [D], where the [C]skies are so [G]blue
[D]Sweet [C]home Ala[G]bama [D], Lord, I''m [C]coming home to [C]you',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Στα χρόνια της υπομονής',78,NULL,0,NULL,'2026-09-24 09:11:20','2026-09-28 08:24:40','{title: Στα χρόνια της υπομονής}

{verse: Verse}
[Dm]Αν είναι κόσμος όμορ[A]φος
είναι και κόσμος ψεύ[Dm]της
που μοιάζει σκοτεινό γυα[A]λί
και σαν παλιός καθρέ[Dm]φτης

{verse: Chorus}
Στα χρόνια [A]της υπομο[Dm]νής
δε μάς θυ[A]μή-, δε μάς θυμήθηκε κα[Dm]νείς
Δε μάς θυμή[A]θηκε κα[A]νείς
Στα χρόνια [A]της, στα χρόνια της υπομο[Dm]νής

{verse: Verse}
[Dm]Τα γράμματά μου γύρι[A]σες
χωρίς να τα διαβά[Dm]σεις
Μα πες μου γιατί [A]βιάστηκες
να με καταδικά[Dm]σεις

{verse: Chorus}
Στα χρόνια [A]της υπομο[Dm]νής
δε μάς θυ[A]μή-, δε μάς θυμήθηκε κα[Dm]νείς
Δε μάς θυμή[A]θηκε κα[A]νείς
Στα χρόνια [A]της, στα χρόνια της υπομο[Dm]νής

{verse: Chorus}
Στα χρόνια [A]της υπομο[Dm]νής
δε μάς θυ[A]μή-, δε μάς θυμήθηκε κα[Dm]νείς
Δε μάς θυμή[A]θηκε κα[A]νείς
Στα χρόνια [A]της, στα χρόνια της υπομο[Dm]νής',NULL),
	 ('Μη μου θυμώνεις μάτια μου',11,NULL,0,NULL,'2026-09-24 09:29:44','2026-09-28 08:24:59','{title: Μη μου θυμώνεις μάτια μου}

{verse: Verse}
[Am]Μη μου θυμώνεις [E]μάτια [Am]μου,[E]που φεύγω [Dm]για τα ξέ[Am]να
[F]Πουλί θα γίνω [Dm]και θα ''[Am]ρθω [F]πάλι κο[E]ντά σε σέ[Am]να

{verse: Chorus}
[Am]Άνοιξ'' το παρα[E]θύρι [Am]σου [F]ξανθέ βα[G]σιλικέ [C]μου
[F]και με γλυ[Am]κό χαμόγε[Dm]λό[Am]  μια κα--λη[E]νύχτα πες [Am]μου

{verse: Verse}
[Am]Μη μου θυμώνεις [E]μάτια [Am]μου, [E]τώρα που [Dm]θα σ'' αφή[Am]σω
[F]Κι έλα για λίγο [Dm]να σε [Am]δω, [F]να σ'' απο[E]χαιρετή[Am]σω

{verse: Chorus}
[Am]Άνοιξ'' το παρα[E]θύρι [Am]σου [F]ξανθέ βα[G]σιλικέ [C]μου
[F]και με γλυ[Am]κό χαμόγε[Dm]λό[Am]  μια κα--λη[E]νύχτα πες [Am]μου

{verse: Chorus}
[Am]Άνοιξ'' το παρα[E]θύρι [Am]σου [F]ξανθέ βα[G]σιλικέ [C]μου
[F]και με γλυ[Am]κό χαμόγε[Dm]λό[Am]  μια κα--λη[E]νύχτα πες [Am]μου',NULL),
	 ('Dust in the wind',79,NULL,0,NULL,'2026-09-24 10:05:22','2026-10-26 08:48:13','{title: Dust in the wind}
{verse: Intro}
[C]
[A] [Am] [A]
[C]
[Am] [A] [Am]
 
{verse: Verse}
[C]I   close [G]my  [Am]eyes
[G]only for a [Dm]moment, and the [Am]moment''s gone. [G]
[C]All [G]my  [Am]dreams
[G]pass before my [Dm]eyes, a curi[Am]osity.
 
{verse: Chorus}
[D]Dust[G] in the [Am]wind.
[D]All they are is [G]dust in the [Am]wind.

{verse: Verse}
[C]Same [G]old [Am]song.
[G]Just a drop of [Dm]water in an [Am]endless sea. [G]
[C]All [G]we  [Am]do
[G]crumbles to the [Dm]ground though we [Am]refuse to see.
 
{verse: Chorus}
[D]Dust[G] in the [Am]wind.
[D]All they are is [G]dust in the [Am]wind.
[F]Oh.......
 
{verse: Instrumental}
[Am]            [G]
[F]
[Am]            [G]
[F]
[C]
[A]             [Am]     [A]
[C]
[Am]     [A]             [Am]
 
{verse: Verse}
Now,   [C]don''t [G]hang [Am]on.
[G]Nothing lasts for[Dm]ever but the [Am]earth and sky.
It  [C]slips [G]a - [Am]way.
And [G]all your money [Dm]won''t another [Am]minute buy.
 
{verse: Chorus}
[D]Dust[G] in the [Am]wind.
[D]All they are is [G]dust in the [Am]wind.
[D]Everything is [G]dust in the [Am]wind.',NULL),
	 ('Add it up',80,NULL,0,NULL,'2026-09-24 11:17:15','2026-09-28 07:44:19','{title: Add it up}
{verse: Intro}
[NC]Day after day
[NC]I will walk, and I will play.
[NC]But the day after today
[NC]I will stop and I will start
 
[Bm] [Bm] [A] [Bm]
 
{verse: Verse}
[Bm]Why can''t I get just one kiss?  Why can''t I get just one kiss?
Be[A]lieve me, some things that I wouldn''t miss but I [Bm]look at your pants and I need a 
kiss.
[Bm]Why can''t I get just one screw?  Why can''t I get just one screw?
Be[A]lieve me, I know what to do, but [A]something won''t let me make love to you.
 
[Bm] [Bm] [A] [Bm]
 
[Bm]Why can''t I get just one fuck?  Why can''t I get just one fuck?
I [A]guess it''s got something to do with luck but I [Bm]waited my whole life for just one
 
{verse: Chorus}
[Bm]Day after day
I get [A]angry, and I will [Bm]say.
That the [Bm]day is in my sights
When I take a [A]bow, and say good [Bm]night.
 
{verse: Bridge}
[Bm]Oh my, mama, mama, mo my mum, have you kept your eye, your eye on your son?
You [A]know you''ve had problems, you''re not the only one, [Bm]when your sugar left, he left 
you on the run.
[Bm]Oh my, mama, mama, mo my mum, take a look now at what your boy has done.
He''s [A]walking around like he''s number one, he [Bm]went downtown and he got ''im a gun.
[Bm]Don''t shoot, shoot, shoot that thing at me. Don''t shoot, shoot, shoot that thing at me.
You [A]know you''ve got my sympathy but don''t [Bm]shoot, shoot, shoot that thing at me.
[Bm]Don''t shoot, shoot, shoot that thing at me. Don''t shoot, shoot, shoot that thing at me.
You [A]know you''ve got my sympathy but don''t [Bm]shoot, shoot, shoot that thing at me.
 
[Bm] [Bm] [A] [Bm]
 
{verse: Verse}
[Bm]There''s a broken down kitchen at the top of the stairs kinda mixed in with your 
affairs.
[A]Share a smoke, make a joke, [Bm]grasp and reach for a leg of hope.
[Bm]Words to memorize, words hypnotize, words make my mouth exercise.
[A]Words all fail the magic prize, [Bm]nothing I can say when I''m in your thighs
[Bm]Say oh my, mama, mama, mo my mother, I would love to love you, lover.
The [A]city''s restless, it''s ready to pounce, [Bm]going here in your bedroom ounce for ounce.
[Bm]Say oh my, mama, mama, mo my mother, I would love to love you, lover.
The [A]city''s restless, it''s ready to pounce, [Bm]going here in your bedroom ounce for ounce.
[Bm]I''ve given you a decision to make, things to lose, things to take,
just [A]as he''s ''bout ready to cut it up, she said, [Bm]"Wait a minute, honey, I''m gonna add 
it up."
Gonna [Bm]Add it up. Add it up. Add it up. Add it up.
[A]Add it up. Add it up. [Bm]Add it up. Add it up.
 
{verse: Chorus}
[Bm]Day after day
I get [A]angry, and I will [Bm]say.
That the [Bm]day is in my sights
When I take a [A]bow, and say good [Bm]night.',NULL),
	 ('Kiss off',80,NULL,0,NULL,'2026-09-24 11:22:56','2026-09-28 07:44:52','{title: Kiss off}
{verse: Intro}
[Em]
 
{verse: Verse}
[Em]I need someone, a person to talk to
Someone who''d care to love
Could it be [C]you
Could it be [Em]you
 
{verse: Verse}
[Em]Situation gets rough, then I start to panic
It''s not enough, it''s just a habit
Hey kid you''re [C]sick
Darling this [Em]is it
 
{verse: Chorus}
[C]You can all just [D]kiss off into the [C]air
Behind my [D]back I can see them [C]stare
They''ll hurt me [D]bad but I won''t [C]mind
They''ll hurt me [D]bad they do it all the [C]time  (Yeah yeah)
[D]Yeah they do it all the [C]time  (Yeah yeah)
[D]They do it all the [C]time  (do it all the time)
[D]They do it all the [C]time  (do it all the time)
[D]They do it all the [C]time, do it all the [D]tiiiiiiiime [Em]
 
{verse: Verse}
I [Em]hope you know that this will go down on your permanent record
Oh yeah, well don''t get so [C]distressed
Did I happen to mention that I''m [Em]impressed
 
{verse: Bridge}
[Em]I take one, one, one ''cause you left me
And two, two, two for my family
And three, three, three for my heartache
And four, four, four for my headaches
And five, five, five for my lonely
And six, six, six for my sorrow
And seven, seven for n''n''no tomorrow
And eight, eight, I forget what 8 was for
but nine, nine, nine for a lost god
Ten, ten, ten, ten, for everything everything everything everything
 
{verse: Chorus}
[C]You can all just [D]kiss off into the [C]air
Behind my [D]back I can see them [C]stare
They''ll hurt me [D]bad but I won''t [C]mind
They''ll hurt me [D]bad they do it all the [C]time  (Yeah yeah)
[D]Yeah they do it all the [C]time  (Yeah yeah)
[D]They do it all the [C]time  (do it all the time)
[D]They do it all the [C]time  (do it all the time)
[D]They do it all the [C]time, do it all the [D]tiiiiiiiime [Em]',NULL),
	 ('Stairway to heaven',81,NULL,0,NULL,'2026-09-24 11:40:50','2026-09-28 07:45:43','{title: Stairway to heaven}
{verse: Intro}
[Am] [C] [D] [F] [Am]
 
{verse: Verse}
There''s a [Am]lady who''s [C]sure all that glitters is [D]gold
And she''s [F]buying a stairway to [Am]heaven
When she [Am]gets there she [C]knows, if the stores are all [D]closed
With a [F]word she can get what she [D]came for
[C]Ooh, [D]ooh[F] [Am], and she''s [C]buying a [G]stairway to [D]heaven
 
[Am]There''s a [C]sign on the [D]wall but she [F]wants to be [Am]sure
[Am]''Cause you [C]know sometimes [D]words have two [F]meanings
In a [Am]tree by the [C]brook, there''s a songbird who [D]sings,
Sometimes [C]all of our thoughts are [Am]misgiven

{verse: Bridge}
[Am] [D] Ooh, it makes me wonder [Am] [Em] [D] [C] [D]
[Am] [D] Ooh, it makes me wonder [Am] [Em] [D] [C] [D]
 
{verse: Verse}
There''s a [C]feeling I [G]get when I [A]look to the [Am]west,
And my [C]spirit is [G]crying for [F]leaving [Am]
In my [C]thoughts I have [G]seen rings of [A]smoke through the [Am]trees,
And the [C]voices of [G]those who stand [F]looking [Am]
 
{verse: Bridge}
[Am] [D] Ooh, it makes me wonder [Am] [Em] [D] [C] [D]
[Am] [D] Ooh, it makes me wonder [Am] [Em] [D] [C] [D]
 
{verse: Verse}
And it''s [C]whispered that [G]soon if we all [A]call the [Am]tune
Then the [C]piper will [G]lead us to [F]reason
And a new [C]day will [G]dawn for [A]those who stand [Am]long
And the [C]forests will [G]echo with [F]laughter
 
[C]If there''s a [G]bustle in your [Am]hedgerow, don''t be alarmed now,
[C]It''s just a [G]spring clean for the [F]May Queen [Am]
[C]Yes, there are [G]two paths you can [Am]go by, but in the long run
[C]There''s still [G]time to change the [F]road you''re [Am]on
 
{verse: Bridge}
[Am] [D] Ooh, it makes me wonder [Am] [Em] [D] [C] [D]
[Am] [D] Ooh, it makes me wonder [Am] [Em] [D] [C] [D]
 
{verse: Verse}
[C]Your head is [G]humming and it [Am]won''t go, in case you don''t know,
[C]The piper''s [G]calling you to [F]join [Am]him
[C]Dear lady, [G]can you hear the [Am]wind blow, and did you know
[C]Your stairway [G]lies on the [F]whispering [Am]wind
 
{verse: Instrumental}
[C] [G] [D]
[D] [C]
[Am] [F] x8
 
{verse: Verse}
[Am]And as we [g]wind on down the [F]road
[Am]Our shadows [G]taller than our [F]soul
[Am]There walks a [G]lady we all [F]know
[Am]Who shines white [G]light and wants to [F]show
[Am]How every[G]thing still turns to [F]gold
[Am]And if you [G]listen very [F]hard
[Am]The tune will [G]come to you at [F]last
[Am]When all are [G]one and one is [F]all
[Am]To be a [G]rock and not to [F]roll
 
{verse: Instrumental}
[Am]
[F]
 
And she''s buying a stairway to heaven
',NULL),
	 ('Sultans of swing',82,NULL,0,NULL,'2026-09-24 12:31:57','2026-09-28 07:46:21','{title: Sultans of swing}
{verse: Intro}
[Em]

{verse: Verse}
You get a [Em]shiver in the dark, it''s [D]raining in the park but [B]meantime
[Em]South of the river you [D]stop and you hold every[B]thing
[G]A band is blowing Dixie double [D]four time
[C]You feel alright when you hear that music [Em]ring [C] [D]
 
{verse: Verse}
Well now, you [Em]step inside but you [D]don''t see too many [B]faces
[Em]Coming in out of the [D]rain to hear the jazz go [B]down
[G]Competition in other [D]places
[C]Uh, but the horns they blowin'' that [Em]sound [C] [D]
way on down south [C] [D]
way on down south
[Em]London Town
 
{verse: Instrumental}
[Em] [D] [C] [D]
[Em] [D] [C] [D]
 
{verse: Verse}
You check out [Em]Guitar George,     [D]he knows all the [B]chords
[Em]Mind he''s strictly rhythm [D]he doesn''t want to make it [B]cry or sing
[G]They say an old guitar [D]is all he can afford
[C]When he gets up under the lights to play his [Em]thing [C] [D]
 
{verse: Verse}
[Em]And Harry doesn''t [D]mind if he doesn''t [B]make the scene
[Em]He''s got a daytime [D]job, he''s doin'' [B]alright
[G]He can play the honky tonk like [D]anything
[C]Saving it up for Friday [Em]night [C] [D]
with the Sultans [C] [D]
with the Sultans of [Em]Swing
 
{verse: Instrumental}
[Em] [D] [C] [D]
[Em] [D] [C] [D]
 
{verse: Verse}
Then a [Em]crowd of young boys, they''re [D]foolin'' around in the [B]corner
[Em]Drunk and dressed in their best [D]brown baggies and their [B]platform soles
[G]They don''t give a damn about about any [D]trumpet playin'' band
[C]It ain''t what they call rock and [Em]roll [C] [D]
and the Sultans [C] [D]
Yeah, the Sultans, they play [Em]Creole
 
{verse: Instrumental}
[Em] [D] [C] [D]
[Em] [D] [C] [D]
 
{verse: Verse}
[Em]And then the man he [D]steps right up to the [B]microphone
[Em]And says at [D]last just as the time bell [B]ring
[G]Goodnight, now it''s [D]time to go home
[C]Then he makes it fast with one more [Em]thing [C] [D]
We are the Sultans [C] [D]
We are the Sultans of [Em]Swing
 
{verse: Instrumental}
[Em] [D] [C] [D]
[Em] [D] [C] [D]',NULL),
	 ('Στα ψηλά τα παραθύρια',11,NULL,0,NULL,'2026-09-25 10:46:19','2026-09-28 08:25:14','{title: Στα ψηλά τα παραθύρια}

{verse: Verse}
[Am]Στα ψηλά τα παρα[E]θύρια δυ[Dm]ο ματόφρυ[F]δα γιο[E]φύρια
[Am]Μαύρα μάτια και με[E]γάλα, [Dm]ζυμω[Am]μένα [F]με το [E]γάλα

{verse: Chorus}
[E]Τα ματό-, [Am]τα ματό-, [E]τα ματόκλαδά σου [Am]κλείνεις  | 2x
[E]Να περά-, [Am]να περά-, [E]να περάσω δε μ'' α[Am]φήνεις    | 2x

{verse: Verse}
[Am]Στο μπαξέ, [E]στο περιβόλι [Dm]είν'' οι δώ[F]δεκα απο[E]στόλοι
[Am]Τη Ρηνιώ ποτίζουν [E]μέλι, [Dm]μα εκείνη [Am]δε [F]με [E]θέλει

{verse: Chorus}
[E]Τα ματό-, [Am]τα ματό-, [E]τα ματόκλαδά σου [Am]κλείνεις  | 2x
[E]Να περά-, [Am]να περά-, [E]να περάσω δε μ'' α[Am]φήνεις    | 2x',NULL),
	 ('I still havent found what Im looking for',83,NULL,0,NULL,'2026-09-28 09:09:46','2026-09-28 09:09:46','{title: I still havent found what I''m looking for}
{verse: Intro} 
[D] [G] [A] [G] [D]
 
{verse: Verse}
I have [D]climbed the highest mountains
I have [D]run through the fields
Only to [G]be with you, Only to [D]be with you
 
I have [D]run I have crawled
I have [D]scaled these city walls
These [G]city walls, Only to [D]be with you
 
{verse: Chorus}
But I [A]still haven''t [G]found
What I''m [D]looking for
But I [A]still haven''t [G]found
What I''m [D]looking for
 
{verse: Verse}
I have [D]kissed honey lips
Felt the [D]healing in the fingertips
It burned [G]like fire, This burning [D]desire
I have [D]spoke with the tongue of angels
I have [D]held the hand of a devil
It was warm [G]in the night, I was cold as a [D]stone
 
{verse: Chorus}
But I [A]still haven''t [G]found
What I''m [D]looking for
But I [A]still haven''t [G]found
What I''m [D]looking for
 
{verse: Verse}
I be[D]lieve when the Kingdom comes
Then all the [D]colors will bleed into one
Bleed into [G]one, But yes I''m [D]still running. 
You broke the [D]bonds, You loosened the chains
You carried the [D]cross, Of my shame
Of my [G]shame, You know I be[D]lieved it
 
{verse: Chorus}
But I [A]still haven''t [G]found
What I''m [D]looking for
But I [A]still haven''t [G]found
What I''m [D]looking for',NULL),
	 ('With or without you',83,NULL,0,NULL,'2026-09-28 09:22:06','2026-09-28 09:22:06','{title: With or without you}
{verse: Intro} 
[C] [G] [Am] [F]
[C] [G] [Am] [F]
 
{verse: Verse}
[C]See the [G]stone set in your [Am]eyes
See the [F]thorn twist in your [C]side
I [G]wait for [Am]you [F]
[C]Sleight of [G]hand and twist of [Am]fate
On a bed of [F]nails she makes me [C]wait
And I [G]wait, with[Am]out you [F]
 
{verse: Chorus}
With or with[C]out you [G]
With or with[Am]out you [F]
 
{verse: Verse}
[C]Through the [G]storm we reach the [Am]shore
You give it [F]all but I want [C]more
And I’m [G]waiting [Am]for you [F]
 
{verse: Chorus}
With or with[C]out you [G]
With or with[Am]out you [F]
I can’t [C]live [G] 
With or with[Am]out you [F]
 
{verse: Instrumental}
[C] [G] [Am] [F]
 
{verse: Bridge}
And you [C]ive yourself a[G]way
And you [Am]give yourself a[F]way
And you [G]give
And you [G]give
And you [Am]give yourself a[F]way
 
{verse: Verse}
[C]My hands are [G]tied
My [Am]body [F]bruised, she got me [C]with
Nothing to [G]win and
[Am]Nothing left to [F]lose
 
{verse: Bridge}
And you [C]ive yourself a[G]way
And you [Am]give yourself a[F]way
And you [G]give
And you [G]give
And you [Am]give yourself a[F]way
 
{verse: Chorus}
With or with[C]out you [G]
With or with[Am]out you [F]
I can’t [C]live [G] 
With or with[Am]out you [F]
 
{verse: Interlude}
[C]Oh-oh-oh-[G]oh
[Am]Oh-oh-oh-[F]oh-oh
[C]Oh-oh-oh-[G]oh
Oh-[Am]oh-oh [F]
 
{verse: Chorus}
With or with[C]out you [G]
With or with[Am]out you [F]
I can’t [C]live [G] 
With or with[Am]out you [F]',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('One',83,NULL,0,NULL,'2026-09-28 12:23:50','2026-10-21 09:50:35','{title: One}
{verse: Intro}
[Am] [D] [F] [G]
 
{verse: Verse}
[Am]Is it getting be[D]tter?
[F]Or do you feel the [G]same?
[Am]Will it make it [D]easier on you now
[F]You got someone to [G]blame, you say
 
{verse: Chorus}
[C]One love, [Am]one life,
[F]When it''s one need, [C]in the night
[C]One love, [Am]we get to share it
[F]It leaves you baby, if [C]you don''t care for it
 
{verse: Interlude}
[Am] [D] [F] [G]
 
{verse: Verse}
[Am]Did I disappoint [D]you?
[F]Or leave a bad taste in your [G]mouth?
[Am]You act like you never had [D]love
[F]And you want me to go without, [G]well it''s
 
{verse: Chorus}
[C]Too late, [Am]tonight
[F]To drag the past out [C]into the light
[C]We''re one, but we''re [Am]not the same
We get to [F]carry each other, [C]carry each other

{verse: Interlude}
[Am] [D] [F] [G]
 
{verse: Verse}
[Am]Have you come here for fo[D]rgiveness?
[F]Have you come to raise the [G]dead?
[Am]Have you come here to play [D]Jesus
[F]To the lepers in your [G]head?
 
{verse: Chorus}
[C]Did I ask too much, [Am]more than a lot
[F]You gave me nothing, now [C]it''s all I got
[C]We''re one, but we''re [Am]not the same
Well, we [F]hurt each other, then [C]we do it again
 
{verse: Bridge}
You say, [C]love is a temple, [Am]love a higher law
[C]Love is a temple, [Am]love the higher law
You [C]ask me to enter, [G]but then you make me crawl
And [G]I can''t be holding [F]on
To what you [F]got, when all you got is [C]hurt
 
{verse: Chorus}
[C]One love, [Am]one blood
[F]One life, you got to [C]do what you should
[C]One life, [Am]with each other
[F]Sisters, [C]brothers
[C]One life, but we''re [Am]not the same
We get to [F]carry each other, [C]carry each other',NULL),
	 ('Losing my religion',84,NULL,0,NULL,'2026-09-29 07:07:58','2026-09-29 07:07:58','{title: Losing my religion}
{verse: Intro}
[Am] [Em] [Dm] [G] 

{verse: Verse}
Oh [Am]life is bigger, [Em]it''s bigger than you.
And you are [Am]not me, the lengths that I will [Em]go to.
The distance in your [Am]eyes.
[Em]Oh no, I''ve said too [Dm]much, I''ve said e[G]nough.
 
{verse: Verse}
That''s me in the [Am]corner,    That''s me in the [Em]spot light,
Losing my re[Am]ligion.    Trying to [Em]keep up with you.
And I [Am]don''t know if I can do it.
[Em]Oh no, I''ve said     too    [Dm]much, I haven''t said e[G]nough.
 
{verse: Chorus}
I thought that I heard you [F]laughing.
I thought that I [G]heard you [Am]sing.
I [F]think I thought I [G]saw you [Am]try. [G]
 
{verse: Verse}
Every [Am]whisper,
Every waking [Em]hour, I''m choosing my co[Am]nfessions.
Trying to [Em]keep eye on you.
Like a [Am]hurt lost and blinded fool, fool.
[Em]Oh no, I''ve said too [Dm]much.    I said e[G]nough.

{verse: Verse}
Consider [Am]this,    consider this [Em]hint of the century.
Consider [Am]this,    the slip, that [Em]brought me to my knees pale.
[Am]What if all these fantasies [Em]come    flaming aground.
Now I''ve [Dm]said too [G]much.
 
{verse: Chorus}
I thought that I heard you [F]laughing.
I thought that I [G]heard you [Am]sing.
I [F]think I thought I [G]saw you [Am]try. [G]
 
{verse: Interlude}
[C] [Am]
[C] [Am]
    
{verse: Chorus}
[C]That''s was just [Am]dream 
[C]That''s was just a dream
That''s me in the [Am]corner       
 
{verse: Verse}
That''s me in the [Em]spot light, losing my re[Am]ligion.
Trying to [Em]keep up with you.
And I [Am]don''t know if I can do it.
[Em]Oh no, I''ve said     too    [Dm]much.
I haven''t said e[G]nough.
                                    F
{verse: Chorus}
I thought that I heard you [F]laughing.
I thought that I [G]heard you [Am]sing.
I [F]think I thought I [G]saw you [Am]try. [G]

{verse: Outro}
But [F]that was just a [G]dream,      try, cry, [Am]why try.
[F]That was just a [G]dream,   just a [Am]dream, [G]just a dream, dream.',NULL),
	 ('Imagine',52,NULL,0,NULL,'2026-09-29 07:52:36','2026-09-29 07:52:36','{title: Imagine}
{verse: Intro}
[C] [F] x2
 
{verse: Verse}
[C]Imagine there''s no [F]heaven
[C]It''s easy if you   [F]try
[C]No hell below [F]us
[C]Above us only [F]sky
 
{verse: Bridge}
[F]Imagine [Am]all the [Dm]people [F]
[G]Living for to - day a-hah
 
{verse: Verse}
[C]Imagine there''s no    [F]countries
[C]It isn''t hard to    [F]do
[C]Nothing to kill or    [F]die for
[C]And no religion   [F]too
 
{verse: Bridge}
[F]Imagine [Am]all the [Dm]people [F]
[G]Living life in peace - you-hou-hou-ou-ou [F]
 
{verse: Chorus}
You may [G]say I''m a [C]dreamer [E]
[F]But I''m [G]not the only [C]one [E]
[F]I hope some [G]day you''ll [C]join us [E]
[F]And the [G]world will be as [C]one
 
{verse: Verse}
[C]Imagine no pos - [F]sessions
[C]I wonder if you   [F]can
[C]No need for greed or    [F]hunger
[C]A brotherhood of    [F]man
 
{verse: Bridge}
[F]Imagine [Am]all the [Dm]people [F]
[G]Sharing all the world - you-hou-hou-ou
 
{verse: Chorus}
You may [G]say I''m a [C]dreamer [E]
[F]But I''m [G]not the only [C]one [E]
[F]I hope some [G]day you''ll [C]join us [E]
[F]And the [G]world will live as [C]one',NULL),
	 ('Over my shoulder',86,NULL,0,NULL,'2026-09-29 08:41:01','2026-09-29 08:41:01','{title: Over my shoulder}
{verse: Intro}
[Em] [A]

{verse: Verse}
Looking [Em]back [A]over my [D]shoulder
[Em]I can see that [A]look in your [D]eyes
[Em]I never dreamed [A]it could be [D]over
[Em]I never wanted [A]to say good [D]bye
 
{verse: Verse}
Looking [Em]back [A]over my [D]shoulder
[Em]With an aching [A]deep in my [D]heart
[Em]I wish we [A]were starting [D]over
[Em]Oh instead we''re drif[A]ting so far a[D]part
 
{verse: Chorus}
[C]Every[G]body [F]told me you were [G]leaving
[C]Funny [G]I should [F]be the last to [G]know
[C]Baby, [G]please, [F]tell me that I''m [G]dreaming
[C]I just never want to let you [F]go
 
{verse: Verse}
Looking [Em]back [A]over my [D]shoulder
[Em]I can see that [A]look in your [D]eyes
[Em]Turning my heart [A]over and [D]over
[Em]I never wanted [A]to say good [D]bye
 
{verse: Chorus}
[C]I don''t [G]mind [F]everybody [G]laughing
[C]But it''s [G]enough to [F]make an old man [G]cry
[C]''cause I can [G]feel you''re [F]slipping through my [G]fingers
[C]I don''t even know the reason [F]why
 
 
{verse: Interlude}
[Whistle the melody]
 
{verse: Chorus}
[C]Every[G]day [F]it''s a losing [G]battle
[C]Just to [G]smile and [F]hold my head up [G]high
[C]Could it [G]be [F]we belong to[G]gether
[C]Baby, won''t you give me one more [F]try?

{verse: Verse}
Looking [Em]back [A]over my [D]shoulder
[Em]I can see that [A]look in your [D]eyes
[Em]Turning my heart [A]over and [D]over
[Em]I never wanted [A]to say good [D]bye',NULL),
	 ('In the living years',86,NULL,0,NULL,'2026-09-29 08:48:04','2026-10-05 12:12:38','{title: In the living years}
{verse: Intro}
[G] [G] [Am] [D] [G] 
 
{verse: Verse}
[G]Every generation
[C]Blames the one before
And [G]all of their frustrations
Come [C]beating on your door
 
{verse: Verse}
I [F]know that I''m a prisoner
To all my Father held so dear
I [Am]know that I''m a hostage
To all his hopes and fears
I just [D]wish I could have told him in the living [G]years
 
{verse: Verse}
[G]Crumpled bits of paper
[G]Filled with imperfect thought
[G]Stilted conversations
I''m [C]afraid that''s all we''ve got

{verse: Verse}
You [F]say you just don''t see it
He says it''s perfect sense
You [Am]just can''t get agreement
In this present tense
We all [D]talk a different language
Talking in de[G]fense
 
{verse: Chorus}
Say it [G]loud, say it [C]clear
You can [Am]listen as [D]well as you [G]hear
It''s too [G]late when we [C]die
To [Am]admit we don''t [D]see eye to [G]eye
 
{verse: Verse}
So we [G]open up a quarrel
Between the [C]present and the past
We only [G]sacrifice the future
It''s the [C]bitterness that lasts
 
{verse: Verse}
So [F]don''t yield to the fortunes
You sometimes see as fat
It [Am]may have a new perspective
On a different date
And if [D]you don''t give up, and don''t give in
You may just be [G]O.K.
 
{verse: Chorus}
Say it [G]loud, say it [C]clear
You can [Am]listen as [D]well as you [G]hear
It''s too [G]late when we [C]die
To [Am]admit we don''t [D]see eye to [G]eye

{verse: Verse}
[G]I wasn''t there that morning
When my [C]Father passed away
I [G]didn''t get to tell him
All the [C]things I had to say
 
{verse: Verse}
I [F]think I caught his spirit
Later that same year
I''m [Am]sure I heard his echo
In my baby''s new born tears
I just [D]wish I could have told him in the living [G]years
 
{verse: Chorus}
Say it [G]loud, say it [C]clear
You can [Am]listen as [D]well as you [G]hear
It''s too [G]late when we [C]die
To [Am]admit we don''t [D]see eye to [G]eye','D-D-UUD-UDU'),
	 ('The one I love',84,NULL,0,NULL,'2026-10-05 13:21:09','2026-10-06 13:47:41','{title: The one I love}
{verse: Intro}
[Em] [D] [Em]
[Em] [D] [Em]
 
{verse: Verse}
[Em]This one goes out [D]to the one I [Em]love
[Em]This one goes out [D]to the one I’ve [Em]left behind
[G]A simple [D]prop to [Am]occupy my [C]time
[Em]This one goes out [D]to the one I [Em]love
 
{verse: Chorus}
[Em]Fire [D] [Em]
[Em]Fire [D] [Em]
 
{verse: Verse}
[Em]This one goes out [D]to the one I [Em]love
[Em]This one goes out [D]to the one I’ve [Em]left behind
[G]A simple [D]prop to [Am]occupy my [C]time
[Em]This one goes out [D]to the one I [Em]love
 
{verse: Chorus}
[Em]Fire [D] [Em]
[Em]Fire [D] [Em]
 
{verse: Verse}
[Em]This one goes out [D]to the one I [Em]love
[Em]This one goes out [D]to the one I’ve [Em]left behind
[G]Another [D]prop has [Am]occupied my [C]time
[Em]This one goes out [D]to the one I [Em]love
 
{verse: Chorus}
[Em]Fire [D] [Em]
[Em]Fire [D] [Em]','D-DU-UDU'),
	 ('Another cup of coffee',86,NULL,0,NULL,'2026-09-29 08:55:13','2026-09-29 08:55:13','{title: Another cup of coffee}
{verse: Intro}
[Em] [D] [D] [C] x2
 
{verse: Verse}
And she [Em]pours herself a[D]nother [C]cup of [Em]coffee
As she [Em]contemplates the [D]stain a[C]cross the [Em]wall
And it''s [Em]in between the [D]cleaning [C]and the [Em]washing
That''s when [Am]looking back''s the [G]hardest [D]part of [Em]all
 
{verse: Verse}
And she [Em]always did her [D]best to [C]try and [Em]please him
While he [Em]always did his [D]best to [C]make her [Em]cry
And she [Em]got down on her [D]knees to [C]stop him [Em]leaving
But he [Am]always knew one [G]day he''d [D]say good[Em]bye
 
{verse: Chorus}
[C]Where are your [G]friends, where are your [D]children?
[C]Is this your [G]house, is this your [D]home?
[C]Does nothing [G]ever last for[D]ever?
[C]Does every[G]body sleep a[D]lone?
 
{verse: Verse}
And he [Em]tears the business [D]tags from [C]his old [Em]suitcase
As he [Em]packs away the [D]pieces [C]of his [Em]life
They all [Em]love him but they [D]always [C]try to [Em]change him
That''s what [Am]happens when a [G]girl be[D]comes a [Em]wife
 
{verse: Verse}
And she [Em]pours herself a[D]nother [C]cup of [Em]coffee
As she [Em]contemplates the [D]stain a[C]cross the [Em]wall
And it''s [Em]in between the [D]cleaning [C]and the [Em]washing
That''s when [Am]looking back''s the [G]hardest [D]part of [Em]all
 
{verse: Chorus}
[C]Where are your [G]friends, where are your [D]children?
[C]Is this your [G]house, is this your [D]home?
[C]Does nothing [G]ever last for[D]ever?
[C]Does every[G]body sleep a[D]lone?
 
{verse: Outro}
[Em]Don''t look back, [D]don''t give up, pour yourself [Am]another cup x4',NULL),
	 ('Υπάρχω',38,NULL,0,NULL,'2026-09-30 08:33:25','2026-09-30 08:33:25','{title: Υπάρχω}
{verse: Verse}
[Em]Υπάρχω, κι όσο υ[F]πάρχεις θα υ[G]πάρχω
Σκλά[F]βα τη ζωή σου [Em]θα ''χω
κι ας βα[C]δίζου[Dm]με σε [F]δρό[G]μους χωρι[Em]στούς
 
{verse: Verse}
[Em]Υπάρχω, μες τα [F]μάτια σου που [G]κλαίνε
μες [F]τα χείλη σου που [Em]καίνε
και θα υ[C]πάρχω [Dm]στα τρα[F]γούδια [G]που θ'' α[Em]κούς
 
{verse: Chorus}
[Em]Είμαι της ζωής σου ο [F]ένας, δε με σβήνει κα[Em]νένας
κι αν με άλλους μι[Am]λάς, κι ώρες-ώρες γε[G]λάς
κατά βάθος πο[F]νάς, [Dm]γιατί σκέφτεσαι ε[Em]μένα
[Em]Είμαι και αρχή και φι[F]νάλε, και στην σκέψη σου [Em]βάλε
πως αν κάνεις δε[Am]σμό μες σε λίγο και[G]ρό
θα χωρίσεις για[F]τί [Dm]θα υπάρχω ε[Em]γώ
 
{verse: Verse}
[Em]Υπάρχω, στη χα[F]ρά σου και στη [G]λύπη
η μορ[F]φή μου δε θα σου [Em]λείπει
κι ούτε [C]πρόκει[Dm]ται πο[F]τέ να [G]ξεχα[Em]στώ

{verse: Verse}
[Em]Υπάρχω μες την [F]τύχη σου που [Em]βρίζεις
στο μυα[F]λό σου που ζα[Em]λίζεις
με τσι[C]γάρο, [Dm]μ'' ανα[F]μνήσεις[G], με πο[Em]τό

{verse: Chorus}
[Em]Είμαι της ζωής σου ο [F]ένας, δε με σβήνει κα[Em]νένας
κι αν με άλλους μι[Am]λάς, κι ώρες-ώρες γε[G]λάς
κατά βάθος πο[F]νάς, [Dm]γιατί σκέφτεσαι ε[Em]μένα
[Em]Είμαι και αρχή και φι[F]νάλε, και στην σκέψη σου [Em]βάλε
πως αν κάνεις δε[Am]σμό μες σε λίγο και[G]ρό
θα χωρίσεις για[F]τί [Dm]θα υπάρχω ε[Em]γώ',NULL),
	 ('Child in time',87,NULL,0,NULL,'2026-10-01 06:32:39','2026-10-01 10:54:03','{title: Child in time}
{verse: Intro}
[G] [G] [Am]
[G] [G] [Am]
[F] [F] [G]
[G] [G] [Am]
 
{verse: Verse}
[G] [G] [Am]Sweet Child in [G]time [Am]
you''ll see the [F]line [G]
The line that''s drawn [G]between [Am]
The good and the [G]bad [Am]
See the blind [G]man [Am]
Shooting at the [F]world [G]
Bullets [G]flying [Am]
taking [G]toll [Am]
 
{verse: Verse}
If you''ve been [G]bad [Am],
Lord I bet you [F]have [G]
And you''ve not been [G]hit [Am]
by flying [G]lead [Am]
You''d better close your [G]eyes [Am]
and bow your [F]head [G]
 
{verse: Instrumental}
[G]Wait for the ricochet [Am]
[G] [G] [Am]
[G] [G] [Am]
[F] [F] [G]
[G] [G] [Am]

{verse: Verse}
[G] [G] [Am]Sweet Child in [G]time [Am]
you''ll see the [F]line [G]
The line that''s drawn [G]between [Am]
The good and the [G]bad [Am]
See the blind [G]man [Am]
Shooting at the [F]world [G]
Bullets [G]flying [Am]
taking [G]toll [Am]
 
{verse: Verse}
If you''ve been [G]bad [Am],
Lord I bet you [F]have [G]
And you''ve not been [G]hit [Am]
by flying [G]lead [Am]
You''d better close your [G]eyes [Am]
and bow your [F]head [G]
 
{verse: Instrumental}
[G]Wait for the ricochet [Am]
[G] [G] [Am]
[G] [G] [Am]
[F] [F] [G]
[G] [G] [Am]',NULL),
	 ('Angie',88,NULL,0,NULL,'2026-10-01 06:58:26','2026-10-01 07:39:03','{title: Angie}
{verse: Intro}
[Am] [E] [G] [F] [C]
 
{verse: Verse}
[Am]Angie, [E]Angie,
[G]When will those [F]clouds all disa[C]ppear?
[Am]Angie, [E]Angie,
[G]Where will it [F]lead us from [C]here?
 
{verse: Chorus}
With no [G]loving in our souls, and no [Dm]money in our [Am]coats
[C]You can''t [F]say we''re sati[G]sfied
 
{verse: Verse}
But [Am]Angie, [E]Angie,
[G]you can''t [F]say we never [C]tried
[Am]Angie, you''re [E]beautiful, yeah
[G]But ain''t it [F]time we said good[C]bye?
[Am]Angie, [E]I still love you,
[G]Remember [F]all those nights we [C]cried?
 
{verse: Chorus}
All the [G]dreams we held so close
seemed to [Dm]all go up in [Am]smoke
[C]Let me [F]whisper in your [G]ear
 
{verse: Verse}
[Am]Angie, [E]Angie
[G]Where will it [F]lead us from [C]here?
 
{verse: Intrumental} 
[Am] [E] [G] [F] [C]
[Am] [E] [G] [F] [C]
 
{verse: Chorus}
Oh, [G]Angie, don''t you weep,
all your [Dm]kisses still taste [Am]sweet
[C]I hate that [F]sadness in your [G]eyes
 
{verse: Verse}
But [Am]Angie, [E]Angie,
[G]ain''t it [F]time we said good[C]bye?
 
{verse: Intrumental} 
[Am] [E] [G] [F] [C]
 
{verse: Chorus}
With no [G]loving in our souls, and no [Dm]money in our [Am]coats
[C]You can''t [F]say we''re sati[G]sfied
 
{verse: Verse}
But [Dm]Angie, I still love you, [Am]baby
[Dm]Everywhere I look I see your [Am]eyes
[Dm]There ain''t a woman that comes close to [Am]you
[C]Come on [F]baby, dry your [G]eyes
 
{verse: Chorus}
But [Am]Angie, [E]Angie,
[G]ain''t it [F]good to be a[C]live?
[Am]Angie, [E]Angie,
[G]They can''t [F]say we never [C]tried',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Love hurts',89,NULL,0,NULL,'2026-10-01 08:05:26','2026-10-01 08:05:26','{title: Love hurts}
{verse: Intro}
[G] [F] [C]
 
{verse: Verse}
Love [G]hurts, love [Em]scars, love [C]wounds and [D]mars
[C]Any   [G]heart, [Em]not [C]tough or strong [D]enough
To [C]take a lot of [G]pain, [B7]take a lot of [Em]pain
[B7]Love is like a [C]cloud, it holds a lot of [D]rain
 
{verse: Chorus}
[C]Love [G]hurts, [F]ooh [C]hoo love [G]hurts
 
{verse: Verse}
I''m [G]young, I [Em]know, but [C]even [D]so
[C]I know a [G]thing or [Em]two, [C]I learned from [D]you
I [C]really learned a [G]lot, [B7]really learned a [Em]lot
[B7]Love is like a [C]flame, it burns you when it''s [D]hot
 
{verse: Chorus}
[C]Love [G]hurts, [F]ooh [C]hoo love [G]hurts
 
{verse: Bridge}
[Em]Some fools think of [B7]happiness[Em], [B7]blissfulness[Em], [B7]togetherness[Em]
[A]Some fools fool themselves, I guess
[Am]They''re not foolin'' [D]me
[C]I know it isn''t [G]true, [B7]I know it isn''t [Em]true
[B7]Love is just a [C]lie made to make you [D]blue
 
{verse: Chorus}
[C]Love [G]hurts, [F]ooh [C]hoo love [G]hurts',NULL),
	 ('Ταξιδιάρα ψυχή',94,NULL,0,NULL,'2026-10-06 12:58:19','2026-10-06 13:37:05','{title: Ταξιδιάρα ψυχή}
{verse: Intro}
[Em] [C] [Am] [C]

{verse: Verse}
[Em]Λονδίνο Άμστερνταμ ή Βερολίνο [C]έχεις ξεχάσει που ακρι[Am]βώς θέλεις να πας
[Em]όσα κι αν έχω δανεικά πια δεν σου δίνω [C]να κάνεις βόλτες με το [Am]magic bus
[Em]όσα κι αν έχω δανεικά πια δεν σου δίνω [C]να κάνεις βόλτες με το [Am]magic bus
[Em]Ταξιδιάρα ψυχή [C]κι αν θέλω δίπλα σου είναι [Am]δύσκολο να μένω
[Em]καιρός να δω τη δικιά μου ζωή [C]σ'' αυτό το ταξίδι δεν [Am]θα σε περιμένω

{verse: Instrumental}
[Em] [C] [Am] [C]
 
{verse: Verse}
[Em]Θα ψωνιστώ και κάποιο βράδυ [C]ότι έχω μέσα μου για [Am]σένα θα το σβήσω
[Em]είναι μονόδρομος ο δρόμος που ''χεις πάρει [C]και δε σε βλέπω να γυ[Am]ρίζεις πίσω
[Em]είναι μονόδρομος ο δρόμος που ''χεις πάρει [C]και δε σε βλέπω να γυ[Am]ρίζεις πίσω
[Em]Ταξιδιάρα ψυχή [C]κι αν θέλω δίπλα σου είναι [Am]δύσκολο να μένω
[Em]καιρός να δω τη δικιά μου ζωή [C]σ'' αυτό το ταξίδι δεν [Am]θα σε περιμένω

{verse: Instrumental}
[Em] [C] [Am] [C]
 
{verse: Verse}
[Em]Λονδίνο Άμστερνταμ ή Βερολίνο [C]έχεις ξεχάσει που ακρι[Am]βώς θέλεις να πας
[Em]όσα κι αν έχω δανεικά πια δεν σου δίνω [C]να κάνεις βόλτες με το [Am]magic bus
[Em]όσα κι αν έχω δανεικά πια δεν σου δίνω [C]να κάνεις βόλτες με το [Am]magic bus
[Em]Ταξιδιάρα ψυχή [C]κι αν θέλω δίπλα σου είναι [Am]δύσκολο να μένω
[Em]καιρός να δω τη δικιά μου ζωή [C]σ'' αυτό το ταξίδι δεν [Am]θα σε περιμένω',NULL),
	 ('Nightmare',90,NULL,0,NULL,'2026-10-01 08:13:45','2026-10-05 07:12:53','{title: Nightmare}
{verse: Intro}
[Am] [F] [Dm] [E]

{verse: Verse}
[Am]Nightmares, lying here in the [F]dark
Ooh [Am]Scared like my dreams made their [F]mark
I [Dm]wonder [E]

{verse: Verse}
[Am]Dreamer, always a[F]lone
[Am]Lost in a part of myself I can''t find [F]anymore
[Dm]I wonder if it''s gonna [E]end tonight

{verse: Chorus}
[Am]I can''t sleep alone any[F]more
[G]I need you here with [Am]me
Even though I closed all the [F]doors
[G]There''s somethin'' holdin'' [C]me

{verse: Chorus}
Never [G]Ending Nightmare[Dm]
Always [F]there in[G]stead of [Am]you
Never [G]Ending Nightmare[Dm]
No e[F]scape this [G]time from [Am]you
 
{verse: Instrumental}
[Am] [F] [Dm] [E]

{verse: Verse}
[Am]Lately been around someone [F]new
[Am]Needed to fill in the space That once sheltered [F]you
Still I [Dm]worry, if you''re gonna [E]be alright

{verse: Chorus}
[Am]I can''t sleep alone any[F]more
Need [G]someone here with [Am]me
All I ever wanted and [F]more
My [G]dreams are fighting [C]for

{verse: Chorus}
Never [G]Ending Nightmare[Dm]
Always [F]there [G]instead of [Am]you
Never [G]Ending Nightmare[Dm]
Punishing [F]me for the [G]things I [Am]do
Never [G]Ending Nightmare[Dm]
No e[F]scape this [G]time from [Am]you',NULL),
	 ('Its a heartache',91,NULL,0,NULL,'2026-10-01 08:42:42','2026-10-05 12:13:26','{title: Its a heartache}
{verse: Intro}
[C] [Em] [F] [C] [G]
 
{verse: Verse}
It''s a [C]heartache, nothing but a [Em]heartache,
hits you when it''s [F]too late, hits you when you''re [C]down[G].
It''s a [C]fool''s game, nothing but a [Em]fool''s game,
standing in the [F]cold rain, feeling like a [C]clown[G].
 
{verse: Verse}
It''s a [C]heartache, nothing but a [Em]heartache,
love him till your [F]arms break, then he lets you [C]down[G].
 
{verse: Bridge}
It ain''t [F]right with love to [G]share,
when you [Em]find he doesn''t [Am]care, for [G]you.
It ain''t [F]wise to need [G]someone,
as much as [Em]I depended on, [Am]you [G].
 
{verse: Verse}
Oh, it''s a [C]heartache, nothing but a [Em]heartache,
hits you when it''s [F]too late, hits you when you''re [C]down[G].
It''s a [C]fool''s game, nothing but a [Em]fool''s game,
standing in the [F]cold rain, feeling like a [C]clown[G].
 
{verse: Bridge}
It ain''t [F]right with love to [G]share,
when you [Em]find he doesn''t [Am]care, for [G]you.
It ain''t [F]wise to need some[G]one,
as much as [Em]I depended [Am]on, [G]you.
 
{verse: Chorus}
It''s a [C]heartache, nothing but a [Em]heartache,
love him till your [F]arms break, then he lets you [C]down[G].','D-DU-UDU'),
	 ('Αλίμονο',15,NULL,0,NULL,'2026-10-01 12:43:24','2026-10-01 12:48:51','{title: Αλίμονο}
{verse: Verse}
[Em]Δυο, δυο νύχτες ανταμώσανε
[Am]πά-, [Em]πάνω στα δάκρυά μου, ω, ω, ω
Η νύχτα [C]που σε [Em]γνώρισα
κι η νύχτα [C]που [Em]χωρίζουμε
[Em]Και κλαιν τα όνειρά μου, ω, ω, ω
[Em]θα πνίξουν την καρδιά μου, ω, ω, ω
 
{verse: Verse}
Χωρίς την α[Bm]γάπη σου θα ήμουνα [Em]μόνος
Η πίκρα θα [Bm]μ'' έπνιγε, το [Am]δάκρυ, ο [Em]πόνος
Εσύ με ο[F]δήγησες στη γη, στην ε[Em]λπίδα
Του κόσμου το [B]νόημα στα [Am]μάτια σου [B]είδα
 
{verse: Chorus}
[Em]Αλίμονο σ'' αυ[C]τούς που δεν α[Bm]γάπησαν
Α[Em]λίμονο, α[C]λίμονο, α[Bm]λίμονο
Α[Am]λίμονο σ'' [F]αυτούς που δε δακρύσανε, [Em]ζωή
την ομορφιά σου δε γνωρίσανε, ζω[Bm]ή
την ομορ[Am]φιά σου δε γνω[Em]ρίσανε
 
{verse: Verse}
[Em]Η νύχτα απλώθηκε παντού, είν'' το τραγούδι τ'' ουρανού
Νύχτα βα[Am]θιά, πολύ βαθιά μες στην [Em]ψυχή μου
[Em]Με σκέπασε η ερημιά, μια [Am]θλίψη και μια παγωνιά
Γιατί να [D]φύγεις ξαφνικά απ'' τη [Em]ζωή μου
 
{verse: Verse}
Θέλω α[B]πόψε να σου γράψω, μα φοβάμαι μήπως [Em]κλάψω
Με κουράσανε τα δάκρυα κι οι λυγ[B]μοί
Τα [Am]παράθυρά μου [B]κλείνω, πάλι μόνος μου θα [Em]μείνω
Θα με [B]πνίξουν πάλι [Am]απόψε οι [Em]στεναγμοί',NULL),
	 ('Ο παλιατζής',44,NULL,0,NULL,'2026-10-02 07:35:08','2026-10-02 07:35:08','{title: Ο παλιατζής}
{verse: Verse}
[E]Αυτό το σπίτι που το βλέπεις σκοτει[Am]νό
τον παλια[E]τζή απόψε [Dm]να ''ρθει περι[E]μένει
για να μα[Am]ζέψει α[A]κόμα [Dm]ό,τι μένει
από μια [Am]αγάπη που [E]χτυπήθηκε σκλη[Am]ρά
από του [E]μαύρου χωρι[Dm]σμού τη συ[E]μφορά
 
{verse: Chorus}
[E]Πάρε ό,τι θέλεις παλια[Dm]τζή
από μια α[E]γάπη που δε [Am]ζει
[F]αφού δε [Dm]ζούμε πια [E]μαζί
[F]πάρε ό,τι [Dm]θέλεις παλια[E]τζή
 
{verse: Verse}
[E]Πάρ'' το τσουβάλι κι έλα μέσα παλια[Am]τζή
έχω ε[E]νθύμια πο[Dm]λλά να το [E]γεμίσεις
Μάζεψε [Am]όλες τις [A]σκληρές μου ανα[Dm]μνήσεις
δεν έχω [Am]δύναμη να [E]βλέπω τα πα[Am]λιά
που μου [E]θυμίζουν μια [Dm]χαμένη αγκα[E]λιά
 
{verse: Chorus}
[E]Πάρε ό,τι θέλεις παλια[Dm]τζή
από μια α[E]γάπη που δε [Am]ζει
[F]αφού δε [Dm]ζούμε πια [E]μαζί
[F]πάρε ό,τι [Dm]θέλεις παλια[E]τζή',NULL),
	 ('Here without you baby',65,NULL,0,NULL,'2026-10-02 07:42:06','2026-10-02 07:42:06','{title: Here without you baby}
{verse: Intro}
[Am] [F] [G]
 
{verse: Verse}
A hundred [Am]days have made me older Since the [G]last time that saw your pretty [Am]face [F] [G],
A thousand [Am]lies have made me colder, And I [G]don''t think I can look at this the [Am]same [F] [G]
[Am]An all the miles that sepa[G]rate,
They Dis[Am]appear now when I''m [F]dreamin'' of your [G]face
 
{verse: Chorus}
[C]I''m here without you baby, [G]But you''re still on my lonely [Am]mind
I think about you baby [F]and I dream a[G]bout you all the [C]time
I''m here without you baby, [G]But you''re still with me in my [Am]dreams,
And to[F]night, there''s [G]only you and [Am]me  yeah [F] [G].
 
{verse: Verse}
The miles [Am]just keep rollin'', As the [G]people leave their way to say [Am]hello [F] [G]
I''ve heard this [Am]life is overrated, [G]But I hope that it gets better as we [Am]go
[F]hooh [G]yeah yeah.
 
{verse: Chorus}
[C]I''m here without you baby, [G]But you''re still on my lonely [Am]mind
I think about you baby [F]and I dream a[G]bout you all the [C]time
I''m here without you baby, [G]But you''re still with me in my [Am]dreams,
And to[F]night, there''s [G]only you and [Am]me  yeah [F] [G].
 
{verse: Verse}
[Am]Everything I know, [C]and anywhere I [G]go
It gets hard but it won''t [F]take away my love,
[Am]And when the last one falls, [C]when it''s all said and [G]done.
It gets hard but it won''t [F]take, away, my love, woah [C]oh Woah    [G]wo-oh [Am] [F] [G]
 
{verse: Chorus}
[C]I''m here without you baby, [G]But you''re still on my lonely [Am]mind
I think about you baby [F]and I dream a[G]bout you all the [C]time
I''m here without you baby, [G]But you''re still with me in my [Am]dreams,
And to[F]night, there''s [G]only you and [Am]me  yeah [F] [G].',NULL),
	 ('Μα δεν θα δακρύσω πια για σένα',42,NULL,0,NULL,'2026-10-02 10:25:15','2026-10-02 10:35:15','{title: Μα δεν θα δακρύσω πια για σένα}
{verse: Verse}
[C]Μέτρησα προ[G]χθές τις μι[Dm]κρές μας στι[Am]γμές
[C]Ήσουνα κι ε[G]σύ μια στα[Em]γόνα στη βρο[Am]χή
[C]Κι αν δε [G]μπορώ να σ'' α[Dm]γγίξω πάλι [Am]μόνος προσπαθώ
[C]να κρυ[G]φτώ, να σε [Em]χάσω, να χα[Am]θώ
 
{verse: Chorus}
[Dm]Μα δε θα δα[G]κρύσω πια για [Am]σένα
και [G]μη ρωτάς για [Am]μένα
[Dm]Μα δε θα δα[G]κρύσω πια για [Am]σένα
και [G]μη ρω[Em]τάς για [Am]μένα
 
{verse: Verse}
[C]Μέθυσα προ[G]χθές στις μι[Dm]κρές μας στι[Am]γμές
[C]Ήσουνα κι ε[G]σύ μια στα[Em]γόνα από κρα[Am]σί
[C]Κι αν δε [G]μπορώ να σ'' α[Dm]γγίξω πάλι [Am]μόνος προσπαθώ
[C]να κρυ[G]φτώ, να σε [Em]χάσω, να χα[Am]θώ
 
{verse: Chorus}
[Dm]Μα δε θα δα[G]κρύσω πια για [Am]σένα
και [G]μη ρωτάς για [Am]μένα
[Dm]Μα δε θα δα[G]κρύσω πια για [Am]σένα
και [G]μη ρω[Em]τάς για [Am]μένα',NULL),
	 ('Οι παλιές αγάπες πάνε στον παράδεισο',42,NULL,0,NULL,'2026-10-02 10:32:16','2026-10-16 12:18:58','{title: Οι παλιές αγάπες πάνε στον παράδεισο}
{verse: Verse}
[Em]Aγονη [C]πλήξη μιας [D]ζωής δίχως [Am]έρωτα
[Em]Της ερημιάς [C]μου τέρας, της πόλης μου [D]θηρίο μη με φο[Am]βάσαι
[Em]Αλλοπαρμένη [C]έκφραση οι τοίχοι σου [D]θυμίζουν, τον πρώτο σου [Am]έρωτα
[Em]Οι πιο πολλοί [C]αδιάφορα κενοί σε λυ[D]γίζουν όπου και [Am]να ''σαι
 
{verse: Verse}
[Em]Σε σκοτεινά δρο[C]μάκια οι σκιές γλι[D]στράνε επι[Am]κίνδυνα
[Em]Στα ηλεκτρισμένα ξενυ[C]χτάδικα οι γυναίκες μισο[D]κρύβονται πίσω απ'' τη [Am]λήθη
[Em]Στα κολασμένα πα[C]ζάρια της λεωφόρου οι αστυ[D]νόμοι, οι πλούσιοι επαρχιώτες μηχα[Em]νόβιοι
[Am]Μάσκες ακάλυπτες μι[D]κρές στο γύρο του θα[C]νάτου
[Am]Που τρεμοπαίζουν τον [Bm]άγγελο ή το δαίμονα [D]στις άκρες των δαχτύλων [C]τους
[D]Ξημέρωμα Σα[Em]ββάτου
 
{verse: Chorus}
[Am]Για τις παλιές [D]αγάπες μη μι[Em]λάς, [Am]στα πιο μεγάλα [D]θέλω κάνουν [C]πίσω
[Am]Δεν άντεξαν μα[D]ζί και χάθηκαν [Em]μακριά, [Am]κρυφτήκαν στις σπη[D]λιές χαμένων Παρα[Em]δείσων.
 
{verse: Verse}
[Em]Ότι α[C]ξίζει πο[D]νάει κι είναι [Am]δύσκολο
[Em]Για να μην υπο[C]φέρεις φύγε μα[D]κριά μου, κρύψου από [Am]μένα
[Em]Δεν ξέρω [C]αν φεύγεις [D]τώρα, για το [Am]λίγο μου
[Em]Ή αν αυτό που [C]νιώθω ήταν πο[D]λύ, πολύ για [C]σένα, [Em]πολύ για σένα
 
{verse: Chorus}
[Am]Για τις παλιές [D]αγάπες μη μι[Em]λάς, [Am]στα πιο μεγάλα [D]θέλω κάνουν [C]πίσω
[Am]Δεν άντεξαν μα[D]ζί και χάθηκαν [Em]μακριά, [Am]κρυφτήκαν στις σπη[D]λιές χαμένων Παρα[Em]δείσων.',NULL),
	 ('Ο δρόμος είχε την δική του ιστορία',53,NULL,0,NULL,'2026-10-05 12:20:00','2026-10-16 07:42:46','{title: Ο δρόμος είχε την δική του ιστορία}
{verse: Verse}
[C]Ο δρόμος είχε τη δική του ιστο[Dm]ρία
κάποιος την έγραψε στον [G]τοίχο με μπο[C]γιά
[C]Ήταν μια λέξη μοναχά, ελευθε[Dm]ρία
κι έπειτα είπαν πως την [G]έγραψαν παι[C]διά

{verse: Chorus}
[Am] [Em] [F] [C]
Λα λα λα λα...
[F] [C] [G] [C]
Λα λα λα λα...
 
{verse: Verse}
[C]Ύστερα κύλησε ο καιρός κι η ιστο[Dm]ρία
πέρασε εύκολα απ'' τη [G]μνήμη στην κα[C]ρδιά
[C]Ο τοίχος έγραφε μοναδική ευκαι[Dm]ρία
εντός πωλούνται πάσης [G]φύσεως υλι[C]κά
 
{verse: Chorus}
[Am] [Em] [F] [C]
Λα λα λα λα...
[F] [C] [G] [C]
Λα λα λα λα...
 
{verse: Verse}
[C]Τις Κυριακές απ'' το πρωί στα καφε[Dm]νεία
έπειτα γήπεδο, στοι[G]χήματα, καυ[C]γά
[C]Ο δρόμος είχε τη δική του ιστο[Dm]ρία
είπανε όμως πως την [G]έγραψαν παι[C]διά
 
{verse: Chorus}
[Am] [Em] [F] [C]
Λα λα λα λα...
[F] [C] [G] [C]
Λα λα λα λα...',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Ενα χειμωνιάτικο πρωί',92,NULL,0,NULL,'2026-10-05 12:31:00','2026-10-05 12:31:00','{title: Ένα χειμωνιάτικο πρωί}
{verse: Verse}
[Em]Ένα χειμωνιάτικο πρωί
έφυγα απ'' το σπίτι σαν τρε[Am]λή
ο αέρας μου τρυπούσε       | 2x
[G]το κορμί και μου ζητούσε   | 2x
[F]μιά απόφαση ηρωι[Em]κή.        | 2x
 
{verse: Verse}
[Em]Πήρα εφημερίδα και στυλό
βρήκα διαμέρισμα φτη[Am]νό
τρία νοίκια να το κλείσω
[G]έπιπλα για να το ντύσω
[F]και δεν θέλω να σε ξανα[Em]δώ
 
{verse: Verse}
[Em]Ήρθε η νύχτα η σκληρή κι'' εγώ
νοιώθω σαν απόκληρη ε[Am]δώ
θέλω πίσω να γυρίσω
[G]και συγνώμη να ζητήσω
[F]αλλά ντρέπομαι να σου το [Em]πω
 
{verse: Verse}
[Em]Πώς χωρίς εσένα είμαι μισή
δεν πετιέται έτσι μιά ζω[Am]ή
θέλω πίσω να γυρίσω
[G]και συγνώμη να ζητήσω
[F]μα με κυνηγάει μιά φυ[Em]γή
 
{verse: Verse}
[Em]Ένα χειμωνιάτικο πρωί
έφυγα απ'' το σπίτι σαν τρε[Am]λή
ο αέρας μου τρυπούσε
[G]το κορμί και μου ζητούσε
[F]μιά απόφαση ηρωι[Em]κή',NULL),
	 ('Τα μεταξωτά',93,NULL,0,NULL,'2026-10-05 12:41:41','2026-10-05 12:41:41','{title: Τα μεταξωτά}
{verse: Verse}
[Am]Μέρες βαριές, χοντρές ψιχάλες πάνω σε χάπια και μπουκάλες
[F]Δε θα γυρέψω νοσηλεία [Dm]στα σινεμά και στα βιβλία [Am]
[Am]Πάω ν'' αδειάσω το τασάκι κι αυτό το σκούρο σου σακάκι
[F]Θα το πετάξω απ'' το μπαλκόνι, [Dm]να βρει κανένα που κρυώνει [Am]κι εγώ
 
{verse: Chorus}
[F]Να βάλω τα μεταξωτά και να φυσάει
[Dm]στα εργοστάσια μπρο[Am]στά και στα σκου[Em]πίδια [Dm]πλάι
[Em]Να μπερδευτώ με τους εργάτες, [Dm]να πω τον πόνο μου στις γάτες
[Am]και στη φουφού [G]του καστανά [F]στάχτη να [G]γίνεις σατα[Am]νά

{verse: Verse}
[Am]Έχει ψυχρούλα και μ'' αρέσει κι αν δεν μου πάει θα σπάσω μέση
[F]Η αγάπη πάει με μπαστούνι [Dm]κι εγώ με γκάζια στο τακούνι [Am]
[Am]Το άσθμα μου κι ο βρυχηθμός μου στα ραδιόφωνα του κόσμου
[F]Με τρύπια βάρκα και ναυτία [Dm]βγαίνω λοιπόν στην πειρατεία [Am]κι εγώ

{verse: Chorus}
[F]Να βάλω τα μεταξωτά και να φυσάει
[Dm]στα εργοστάσια μπρο[Am]στά και στα σκου[Em]πίδια [Dm]πλάι
[Em]Να μπερδευτώ με τους εργάτες, [Dm]να πω τον πόνο μου στις γάτες
[Am]και στη φουφού [G]του καστανά [F]στάχτη να [G]γίνεις σατα[Am]νά',NULL),
	 ('Γαρύφαλλε',95,NULL,0,NULL,'2026-10-08 06:03:35','2026-10-08 06:03:35','{title: Γαρύφαλλε}
{verse: Intro}
[Am] [G] [Em] [Am]

{verse: Verse}
Μα[Am]ζεύεται πλήθος χα[G]ρούμενες φάτσες ε[Em]κεί που ο Γαρύφαλλος [Am]λέει
τους [Am]λέει τα δικά του και σαν τε[G]λειώσει ο [Em]κόσμος γελάει ή [Am]κλαίει
Σχο[Am]λείο βιβλία αρ[G]χαία ιστορία γι [Em]αυτόν είναι άγνωστες [Am]λέξεις
δεν [Am]ξέρει να γράφει και [G]όμως θαυμάσια [Em]δίνει στον κόσμο δια[Am]λέξεις
Γα[D]ρύφαλλε, Γα[G]ρύφαλλε [Am]κανείς μας δεν [D]ξέρει ποιος [G]είσαι [Em]
 
{verse: Instrumental}
[Am] [G] [Em] [Am]
 
{verse: Verse}
Τα [Am]χρόνια περάσαν τον [G]είδανε όλοι και [Em]ήταν πολύ ευτυχι[Am]σμένος
οι [Am]νέοι γεράσαν και [G]φύγαν οι γέροι και [Em]φεύγει και αυτός ο καη[Am]μένος
μα[Am]ζεύεται πλήθος να [G]τον χαιρετήσει κα[Em]νείς τώρα πια δε γε[Am]λάει
στα ου[Am]ράνια ο Γαρύφαλος [G]βρίσκεται τώρα και [Em]με τους αγγέλους μι[Am]λάει
Γα[D]ρύφαλλε, Γα[G]ρύφαλλε [Am]κανείς μας δεν [D]ξέρει ποιος [G]είσαι [Em]
Γα[D]ρύφαλλε, Γα[G]ρύφαλλε [Am]κανείς μας δεν [D]ξέρει ποιος [G]είσαι [Em]',NULL),
	 ('Ηλιε μου',96,NULL,0,NULL,'2026-10-08 06:20:28','2026-10-08 06:25:32','{title: Ήλιε μου}
{verse: Intro}
[Em] [Am] | 6x
[Am] | 4x
 
{verse: Verse}
[Am]Φρέσκο το χώμα, βροχή έχει πέσει, τα [G]φύλλα ξερά
Υγρά τα [F]μάτια μου είναι, νομίζω πως θέλω να [Em]κλάψω
[Am]Με λίγες νότες τραγούδι έχω γράψει να [G]σου τραγουδώ
Όταν θα [F]βλέπεις πουλιά μακριά σου να φεύγουν στον [Em]ήλιο
Κοροϊ[D]δεύουν τα κλου[Am]βιά
 
{verse: Bridge}
[Em] [Am] | 6x
[Am] | 4x
 
{verse: Verse}
[Am]Είναι καιρός που φέρνει τον ένα στον [G]άλλο κοντά
Είναι και[F]ρός που χωρίζουν οι σκέψεις και μένουμε [Em]μόνοι
[Am]Πόσο ανάγκη έχω τώρα από ένα δι[G]κό σου φιλί
Πόσο μου [F]λείπει η ζεστή σου ανάσα που χείλη θε[Em]ριεύει
Ζωντα[D]νεύει την καρ[Am]διά
 
{verse: Chorus}
[Am]Ή--λιε μου, [D]ήλιε μου
[Am]Έ--λα, [D]ήλιε μου...

{verse: Outro}
[Em] [Am] | 6x',NULL),
	 ('Μην της το πεις',96,NULL,0,NULL,'2026-10-08 06:25:32','2026-10-08 06:25:32','{title: Μην της το πεις}
{verse: Intro}
[Em] [C] | 2x

{verse: Verse}
[Em]Όταν την δεις με τον άλλο ξανά
[C]κι αν μι[Em]λήσεις
[Em]πες της πως μ'' είδες πως είμαι καλά
[C]και να [Em]ζήσεις
 
{verse: Chorus}
[Em]Mην τής το [G]πεις
πως την [C]έχασα μα την [Em]αγαπώ
[Em]Mην τής το [G]πεις
πως δεν [C]ξέχασα και για [Em]κείνη ζω
Mην της μι[C]λήσεις, να με [D]λυπάται δεν [Em]θέλω
Ίσως μια [C]μέρα νιώσει το [B]λάθος και ''[Em]ρθει
 
{verse: Verse}
[Em]Όταν την δεις πες της ότι μπορείς
[C]να με [Em]σώσεις
[Em]Μην τής μιλήσεις για μένα, μην πεις
[C]μην προ[Em]δώσεις
 
{verse: Chorus}
[Em]Mην τής το [G]πεις
πως την [C]έχασα μα την [Em]αγαπώ
[Em]Mην τής το [G]πεις
πως δεν [C]ξέχασα και για [Em]κείνη ζω
Mην της μι[C]λήσεις, να με [D]λυπάται δεν [Em]θέλω
Ίσως μια [C]μέρα νιώσει το [B]λάθος και ''[Em]ρθει',NULL),
	 ('Δεν μετανιώνω',96,NULL,0,NULL,'2026-10-08 06:29:41','2026-10-08 06:29:41','{title: Δεν μετανιώνω}
{verse: Intro}
[Em] [G] [Am] [Em] | 2x

{verse: Verse}
[Em]Τι θα πει απα[G]γορεύεται [Am]δεν έμαθα
[C]ένα νόμο μόνο [D]ξέρει η καρ[Em]διά μου
[Em]πάντα έκανα [G]ότι ήθελα και ας [Am]έπαθα
[C]Ότι λάθη έχω [D]κάνει είναι δι[Em]κά μου
 
{verse: Chorus}
[Em]Για ότι έχω [G]κάνει δεν μετα[Am]νιώνω, δεν μετα[Em]νιώνω
[Em]Είναι η ζωή μια [G]πλάνη γεμάτη [Am]δάκρυ και ψέμα [Em]μόνο
[Em]και πίστεψα σε [D]σένα και εσύ ήσουν [Am]ψέμα, εσύ [Em]ήσουν ψέμα
[Em]Για ότι έχω [G]κάνει δεν μετα[Am]νιώνω, δεν μετα[Em]νιώνω
 
{verse: Verse}
[Em]Τι θα πει απα[G]γορεύεται [Am]δεν έμαθα
[C]ένα νόμο μόνο [D]ξέρει η καρ[Em]διά μου
[Em]πάντα έκανα [G]ότι ήθελα και ας [Am]έπαθα
[C]Ότι λάθη έχω [D]κάνει είναι δι[Em]κά μου

{verse: Chorus}
[Em]Για ότι έχω [G]κάνει δεν μετα[Am]νιώνω, δεν μετα[Em]νιώνω
[Em]Είναι η ζωή μια [G]πλάνη γεμάτη [Am]δάκρυ και ψέμα [Em]μόνο
[Em]και πίστεψα σε [D]σένα και εσύ ήσουν [Am]ψέμα, εσύ [Em]ήσουν ψέμα
[Em]Για ότι έχω [G]κάνει δεν μετα[Am]νιώνω, δεν μετα[Em]νιώνω',NULL),
	 ('Julia',97,NULL,0,NULL,'2026-10-09 07:05:28','2026-10-09 13:07:59','{title: Julia}
{verse: Intro}
[C] [D] [C] [D] [C] [Bm]
 
{verse: Verse}
[Am]Julia  [D]you set the standards for me
[Em]Walk to your door
[G]Beggin'' for it [D]just to be more and
[Am]Julia  [D]I couldn''t do much better than you
[Em]Said so yourself
[G]Wouldn''t want [D]anyone else
[C]And I can''t [D]live without your [Em]love
[C]And I can''t [D]live without your  [Em]love
[C]Well I can''t [D]live without you [Am]
Julia ... [D]Oh you''re drivin me crazy
But I''m a ... [Em]I''m a part of your plans
[G]Oh just a [D]man while your [A]dreams be
[G]You''re just a [D]part of me
[C]Oh, please [Em]see how [Am]much how [D]much you mean to me
[C]Please [Em]see how much [Am]how much you [D]mean to me

{verse: Verse}
[Am]And Julia [D]straight away you''ve had me
And I   [Em]know I''ve had you
[G]You''re a part of me [D]too
[C]And I can''t [D]live without your [Em]love
[C]Well I can''t [D]live without your [Em]love
[C]And I can''t [D]live without you   [A]Julia.',NULL),
	 ('Another brick in the wall',30,NULL,0,NULL,'2026-10-09 07:15:47','2026-10-09 07:15:47','{title: Another brick in the wall}
{verse: Intro}
[Am]
 
{verse: Verse}
[Am]Daddy''s flown across the ocean...Leaving just a memory
[Am]Snapshot in the family album...Daddy what else did you leave for [D]me?
[D]Daddy, what''d''ja leave behind for [Am]me?
 
{verse: Chorus}
[C]All in all it was [G]just a brick in the wall!
[C]All in all it was all [G]just bricks in the wall!
 
{verse: Verse}
[Am]We don’t need no education! We don’t need no thought control!
[Am]No dark sarcasm in the class room! Teacher leave those kids [D]alone!
[D]Hey! Teacher! Leave them kids [Am]alone!
 
{verse: Chorus}
[C]All in all it’s just [G]another brick in the [Am]wall!
[C]All in all you’re just [G]another brick in the [Am]wall!
 
{verse: Verse}
[Am]We don’t need no education! We don’t need no thought control!
[Am]No dark sarcasm in the class room! Teacher leave those kids [D]alone!
[D]Hey! Teacher! Leave them kids [Am]alone!
 
{verse: Chorus}
[C]All in all it’s just [G]another brick in the [Am]wall!
[C]All in all you’re just [G]another brick in the [Am]wall!
 
{verse: Verse}
[Am]I don''t need no arms around me...And I don''t need no drugs to calm me!
[Am]I have seen the writing on the wall...Don''t think I need anything at [D]all!
[D]No! Don''t think I''ll need anything at [Am]all!
 
{verse: Chorus}
[C]All in all it’s just [G]another brick in the [Am]wall!
[C]All in all you’re just [G]another brick in the [Am]wall!',NULL),
	 ('Reason',98,NULL,0,NULL,'2026-10-09 08:18:57','2026-10-09 08:18:57','{title: Reason}
{verse: Intro}
[G]
 
{verse: Verse}
[G]I''m not a perfect [Em]person
There are many things I wish I didn''t [G]do
But I continue [Em]learning
I never meant to do those things to [C]you
And so I have to say before I [D]go
That I just want you to [G]know
 
{verse: Chorus}
[G]I''ve found a reason for [Em]me
To change who I used to [C]be
A reason to start over [D]new
And the reason is [G]you
 
{verse: Verse}
[G]I''m sorry that I [Em]hurt you
It''s something I must live with every[G]day
And all the pain I put you [Em]through
I wish that I could take it all [C]away
And be the one who catches all your [D]tears
Thats why I need you to [G]hear
 
{verse: Chorus}
[G]I''ve found a reason for [Em]me
To change who I used to [C]be
A reason to start over [D]new
And the reason is [F]you
And the reason is [G]you
And the reason is [F]you
And the reason is [G]you
 
{verse: Verse}
[G]I''m not a perfect [Em]person
I never meant to do those things to [C]you
And so I have to say before I [D]go
That I just want you to [G]know
 
{verse: Chorus}
[G]I''ve found a reason for [Em]me
To change who I used to [C]be
A reason to start over [D]new
And the reason is [G]you
I''ve found a reason to [Em]show
A side of me you didn''t [C]know
A reason for all that I [D]do
And the reason is [G]you',NULL),
	 ('Ode to my family',27,NULL,0,NULL,'2026-10-09 12:01:08','2026-10-09 12:01:08','{title: Ode to my family}
{verse: Intro}
[C] [Am] [Em] [F] [C]
 
{verse: Verse}
Under[Am]stand the things I [Em]say, don''t [F]turn away from me [C]
Cause I spent [Am]half my life out [Em]there, you [F]wouldn''t disagree[C].
D''you see me[Am], d''you see, do you [Em]like me, do you [F]like me standing there[C].
D''you notice[Am], d''you know, do you [Em]see me, do you [F]see me, does anyone care.[C]
 
{verse: Chorus}
Unhappi[Am]ness, where''s when [Em]I was young, and [F]we didn''t give a damn. [C]
''Cause we were [Am]raised, to see [Em]life as fun and [F]take it if we can.[C]
My mother[Am], my mother she [Em]hold me, did she [F]hold me, when I was out there. [C]
My father[Am], my father, he [Em]liked me, oh he [F]liked me, does anyone care. [C]
 
{verse: Instrumental}
[C] [Am] [Em] [F] [C]

{verse: Verse}
Under[Am]stand what I''ve be[Em]come, it [F]wasn''t my design. [C]
And people [Am]everywhere think, [Em]something [F]better than I am. [C]
But I miss you [Am], I miss ''cause I [Em]liked it, I [F]liked it, when I was out there. [C]
D''you know this [Am], d''you know, you did [Em]not find me, you did [F]not find, does anyone care. [C]

{verse: Chorus}
Does anyone care? [Am]
Does anyone care? [Em]
Does anyone care? [F]
Does anyone care? [C]',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Άνθρωπε αγάπα',96,NULL,0,NULL,'2026-10-09 13:17:07','2026-10-09 13:17:07','{title: Άνθρωπε αγάπα}
{verse: Intro}
[Am] [G] [D] [Am]

{verse: Verse}
[Am]Αν θες τραγούδια όμορφα ν'' ακούσεις, [G]ήλιε μου
[D]την καρδιά μου ν'' [Am]ανοίξεις
[Am]Αν θες λουλούδι γύρω σου ν'' ανθίσει, [G]το θυμό
[D]άσ'' τον όλο να [Am]σβήσει
 
{verse: Chorus}
[C]Άνθρωπε α[G]γάπα, [D]τη φωτιά στα[Am]μάτα
[C]και τη δύνα[G]μή σου [D]δώσ'' την στο φι[Am]λί σου
 
{verse: Verse}
[Am]Μια πεταλούδα αν θες να φτερουγίσει, [G]μια ψυχή
[D]άνοιξε το κλου[Am]βί της
[Am]Μια αργή ανάσα αν θες να ζωντανέψει, [G]φίλε μου
[D]δώσ'' της απ'' την πνο[Am]ή σου
 
{verse: Chorus}
[C]Άνθρωπε α[G]γάπα, [D]τη φωτιά στα[Am]μάτα
[C]και τη δύνα[G]μή σου [D]δώσ'' την στο φι[Am]λί σου
 
{verse: Verse}
[Am]Τους φίλους σου αν θες να συναντήσεις, [G]άνθρωπε
[D]μόνος σαν περπα[Am]τήσεις
[Am]Κι αν συμβουλή σε κάποιον θα ζητήσεις, [G]φίλε μου
[D]μην σ'' απάντηση ελ[Am]πίσεις
 
{verse: Chorus}
[C]Άνθρωπε α[G]γάπα, [D]τη φωτιά στα[Am]μάτα
[C]και τη δύνα[G]μή σου [D]δώσ'' την στο φι[Am]λί σου',NULL),
	 ('Broken',99,NULL,0,NULL,'2026-10-09 14:04:59','2026-10-09 14:04:59','{title: Broken}
{verse: Intro}
[Em] [C] [Em] [C] [Em] [C] [D]
 
{verse: Verse}
[Em]I wanted [C]you to know [Em]that I love the [C]way you laugh
[Em]I wanna [C]hold you high and [D]steal your pain awaaay
[Em]I keep your [C]photograph; [Em]I know it [C]serves me well
[Em]I wanna [C]hold you high and [D]steal your pain
 
{verse: Chorus}
BeCause I''m [C]bro-[Em]ken when I''m [C]looone-[Em]some
And I don''t [C]feel [Em]right..  when you''re [C]gone a[Em]way
[C] [Em] [C]You''ve gone away [Em]
[C]You don''t [Em]feel me here any[D]more
 
{verse: Verse}
[Em]The worst is [C]over now [Em]and we can [C]breathe again
[Em]I wanna [C]hold you high, you [D]steal my pain awaaaay
[Em]There''s so much [C]left to learn, [Em]and no one [C]left to fight
[Em]I wanna [C]hold you high and [D]steal your pain
 
{verse: Chorus}
''Cause I''m [C]brooo-[Em]ken when I''m [C]ooooo-[Em]pen
And I don''t [C]feel [Em]like I am [C]strong e[Em]nough
BeCause I''m [C]broooo-[Em]ken when I''m [C]loooone-[Em]some
And I don''t [C]feel [Em]Right when you''re [C]gone [Em]away
 
{verse: Chorus}
''Cause I''m [C]brooo-[Em]ken when I''m [C]ooooo-[Em]pen
And I don''t [C]feel [Em]like I am [C]strong e[Em]nough
BeCause I''m [C]broooo-[Em]ken when I''m [C]loooone-[Em]some
And I don''t [C]feel [Em]Right when you''re [C]gone [Em]away

{verse: Outro}
[Em] [C] [Em] [C] [Em] [C] [D]',NULL),
	 ('Numb',100,NULL,0,NULL,'2026-10-09 14:18:08','2026-10-09 14:18:08','{title: Numb}
{verse: Verse}
[Em]I’m tired of being what you [C]want me to be
[G]Feeling so faithless
Lost [D]under the surface
[Em]I don’t know what you’re ex[C]pecting of me
Put [G]under the pressure
of [D]walking in your [C]shoes
(Caught in the undertow, just [D]caught in the undertow)
 
{verse: Chorus}
Every [Em]step that I take is
a[G]nother mistake to [C]you
(Caught in the undertow, just [D]caught in the undertow)
 
{verse: Chorus}
[Em]I’ve become so [C]numb
I can’t feel you [G]there
Become so [D]tired
So much more a[Em]ware
I’m becoming [C]this
All I want to [G]do
Is be more like [D]me
And be less like [Em]you
 
{verse: Verse}
[Em]Can’t you see that you’re [C]smothering me
[G]Holding too tightly [D]afraid to lose co[Em]ntrol
Cause everything that you [C]thought I would be
Has [G]fallen apart [D]right in front of [C]you
(Caught in the undertow, just [D]caught in the undertow)

{verse: Chorus}
Every [Em]step that I take is
a[G]nother mistake to [C]you
(Caught in the undertow, just [D]caught in the undertow)
And every [Em]second I waste is more than [G]I can take
 
{verse: Chorus}
[Em]I’ve become so [C]numb
I can’t feel you [G]there
Become so [D]tired
So much more a[Em]ware
I’m becoming [C]this
All I want to [G]do
Is be more like [D]me
And be less like [Em]you
 
{verse: Bridge}
And I [D]know I may [Em]end  up  [G]failing, [C]too
But I [D]know you were [B7]just like me with someone disappointed in you
 
{verse: Chorus}
[Em]I’ve become so [C]numb
I can’t feel you [G]there
Become so [D]tired
So much more a[Em]ware
I’m becoming [C]this
All I want to [G]do
Is be more like [D]me
And be less like [Em]you',NULL),
	 ('Πράγματα',78,NULL,0,NULL,'2026-10-12 06:56:21','2026-10-30 13:22:00','{title: Πράγματα}
{verse: Intro}
[G] [Em] [Am] [D]
[G] [Em] [Am] [D]

{verse: Verse}
[G]Πράγματα, [Em]πράγματα, [Am]γύρω μου υπάρχουνε πα[D]ντού δικά σου
[G]Πράγματα, [Em]πράγματα, [Am]εσένα να μου φέρνουνε στο [D]νου χιλιάδες
[G]Πράγματα, [Em]πράγματα, [Am]ο μαύρος αναπτήρας στο μπλου [D]τζιν σου
Μικρο[G]πράγματα, [Em]διάφορα, [Am]ριγμένα μέσ'' στο σπίτι, εδώ και [D]εκεί
 
{verse: Chorus}
Και δεν κρατάω πια τα [Em]κλάματα
Με[Am]σάνυχτα με βρίσκουν μονα[D]χή να σκίζω [Em]γράμματα
Να [Am]βρίζω και να σπάω σαν τρε[D]λή στους τοίχους [Em]πράγματα
Να [Am]λέω θα γυρίσει, δεν μπο[D]ρεί, ως τα χα[G]ράματα

{verse: Instrumental}
[G] [Em] [Am] [D]
[G] [Em] [Am] [D]
 
{verse: Verse}
[G]Πράγματα, [Em]πράγματα, [Am]στέκω σαν χαμένη να κοι[D]τώ χιλιάδες
[G]Πράγματα, [Em]πράγματα, [Am]ό,τι μου ''χει μείνει από [D]σένα μόνο
[G]Πράγματα, [Em]γράμματα, [Am]μια φωτογραφία που κοι[D]τιόμαστε
Κα[G]τάματα, [Em]πράγματα, [Am]σε φέρνουνε στο νου και δεν κρατάω πια τα [D]κλάματα
 
{verse: Chorus}
Και δεν κρατάω πια τα [Em]κλάματα
Με[Am]σάνυχτα με βρίσκουν μονα[D]χή να σκίζω [Em]γράμματα
Να [Am]βρίζω και να σπάω σαν τρε[D]λή στους τοίχους [Em]πράγματα
Να [Am]λέω θα γυρίσει, δεν μπο[D]ρεί, ως τα χα[G]ράματα',NULL),
	 ('Ψέμματα',47,NULL,0,NULL,'2026-10-12 07:10:40','2026-10-12 07:10:40','{title: Ψέμματα}
{verse:Intro}
[C] [G] [Dm] [Em] [Am] [G] [Am]

{verse:Verse}
[Am]Τέρμα τα θαύματα, [G]τα σινεμά κλει[C]στά
[Am]Δεν υπάρχεις πια[Dm], δεν υ[Em]πάρχεις
[Am]Όλα τα φώτα σβήνω [G]και κρύβομαι ξα[C]νά
[Am]Δεν υπάρχεις πια[Dm], δεν υ[Em]πάρχεις [G]
 
{verse:Chorus}
[C]Ψέματα, [G]ψέματα
[Dm]Πες μου πως είναι [Em]ψέμα
[Am]Ένα αστείο χα[G]ζό, ένα [Am]όνειρο [G]
[C]Ψέματα, [G]ψέματα
[F]Πες μου πως είναι [Em]ψέμα
[Am]Ένα αστείο χα[G]ζό, εγώ χωρίς ε[Am]σένα
[G]Εγώ χωρίς ε[F]σένα [Em]
 
{verse:Verse}
[Am]Μες τη βοή ξεχνιέμαι [G]κι ο κόσμος προσπερ[C]νά
[Am]Δε με ψάχνεις πια[Dm], δε με [Em]ψάχνεις
[Am]Πάλι το τραύμα ξύνω [G]κι ο πόνος με με[C]θά
[Am]Δε με ψάχνεις πια [Dm], δε με [Em]ψάχνεις [G]
 
{verse:Chorus}
[C]Ψέματα, [G]ψέματα
[Dm]Πες μου πως είναι [Em]ψέμα
[Am]Ένα αστείο χα[G]ζό, ένα [Am]όνειρο [G]
[C]Ψέματα, [G]ψέματα
[F]Πες μου πως είναι [Em]ψέμα
[Am]Ένα αστείο χα[G]ζό, εγώ χωρίς ε[Am]σένα
[G]Εγώ χωρίς ε[F]σένα [Em]
 
{verse:Outro}
[Am]Δεν θέλω να θυμάμαι, [G]δεν θέλω να ξε[C]χνάω
[Am]Δε σε έχω πια [Dm], δε σε [Em]έχω
[Am]Την έξοδο κινδύνου [G]δε βρίσκω πουθε[C]νά
[Am]Δε σε έχω πια [Dm] [Em]',NULL),
	 ('Τα χρόνια τα μαθητικά',78,NULL,0,NULL,'2026-10-12 07:40:26','2026-10-12 07:40:26','{title: Τα μαθητικά τα χρόνια}
{verse: Verse}
Τους μαθη[G]τές τους τρώει το [Em]στρες
κι η αγω[C]νία αν θα μπούνε στις α[D]νώτατες σχολές
Τους μαθη[G]τές τους τρώει το [Em]στρες
κι όλοι [C]θέλουν να ξεφύγουν
από [Am]Φυσικοχη[D]μείες, Άλγε[Em]βρες, Γραμματι[D]κές
 
{verse: Chorus}
Μα ε[G]γώ θα έδινα τα πάντα [D]να γινόμουνα,
[Em]πάλι παιδί λίγο [D]να βρισκόμουνα
στις [Em]ίδιες τάξεις, στα ίδια θρανία,
με [C]τους συμμαθητές μου να κάνω αστεία
και [Am]τους καθηγητές που κοιτάζουν καχύποπτα,
[D]τα μαθητικά τα χρόνια δεν τ'' αλλάζω με [G]τίποτα
 
{verse: Verse}
Τους μαθη[G]τές τους τρώει το [Em]στρες
τα καρδιο[C]χτύπια, οι συζητήσεις μες στις [D]σχολικές αυλές
Τους μαθη[G]τές τους τρώει το [Em]στρες,
μα σαν τε[C]λειώσει το σχολείο
τελει[Am]ώνουν της ζω[D]ής μας κι οι [Em]στιγμές, οι πιο κα[D]λές
 
{verse: Chorus}
Μα ε[G]γώ θα έδινα τα πάντα [D]να γινόμουνα,
[Em]πάλι παιδί λίγο [D]να βρισκόμουνα
στις [Em]ίδιες τάξεις, στα ίδια θρανία,
με [C]τους συμμαθητές μου να κάνω αστεία
και [Am]τους καθηγητές που κοιτάζουν καχύποπτα,
[D]τα μαθητικά τα χρόνια δεν τ'' αλλάζω με [G]τίποτα
 
{verse: Interlude}
με [Em]τίποτα
Μη [C]βιάζεσαι, τα χρόνια γρήγορα πε[Em]ρνούν
κι οι [A]πρώτες οι ρυτίδες σα [D]δρόμοι πίσω μάς γυρ[D]νούν
Στα [Gm]χρόνια τα μαθη[D]τικά, [Gm]στα χρόνια τα [F]μαθητικά
 
{verse: Chorus}
Μα ε[G]γώ θα έδινα τα πάντα [D]να γινόμουνα,
[Em]πάλι παιδί λίγο [D]να βρισκόμουνα
στις [Em]ίδιες τάξεις, στα ίδια θρανία,
με [C]τους συμμαθητές μου να κάνω αστεία
και [Am]τους καθηγητές που κοιτάζουν καχύποπτα,
[D]τα μαθητικά τα χρόνια δεν τ'' αλλάζω με [G]τίποτα',NULL),
	 ('Blue Hotel',25,NULL,0,NULL,'2026-10-13 07:32:10','2026-10-13 07:32:10','{title: Blue Hotel}
{verse: Intro}
[Am]Blue Hotel, [D] On a [Dm]lonely highway
[Am]Blue Hotel, [D] Life don''t [Dm]work out my way
 
{verse: Verse}
[Am]Blue Hotel, [D] On a [Dm]lonely highway
[Am]Blue Hotel, [D] Life don''t [Dm]work out my way
[F]I wait alone each lonely [E]night.
 
{verse: Chorus}
Blue ho[Am]tel, [D] [Dm]
Blue ho[Am]tel, [D] [Dm]
 
{verse: Verse}
[Am]Blue hotel, [D] every [Dm]room is lonely.
[Am]Blue hotel [D] I was [Dm]waiting only.
[F]The night and the life of her lonely [E]dream.
 
{verse: Chorus}
Blue ho[Am]tel, [D] [Dm]
Blue ho[Am]tel, [D] [Dm]
 
{verse: Verse}
[Am]Blue Hotel, [D] On a [Dm]lonely highway
[Am]Blue Hotel, [D] Life don''t [Dm]work out my way
[F]I wait alone each lonely [E]night.
 
{verse: Chorus}
Blue ho[Am]tel, [D] [Dm]
Blue ho[Am]tel, [D] [Dm]',NULL),
	 ('Learning to fly',101,NULL,0,NULL,'2026-10-13 13:50:54','2026-10-13 13:59:23','{title: Learning to fly}
{verse: Intro}
[F] [C] [Am] [G]
 
{verse: Verse}
[F]Well I started [C]out, [Am] [G] [F]down a dirty [C]road [Am] [G]
[F]Started [C]out [Am] [G] [F]all a[C]lone [Am] [G]
[F]And the sun went [C]down, [Am] [G] [F]as I crossed the [C]hill [Am] [G]
[F]As the town lit [C]up, [Am] [G] [F]the world got [C]still [Am] [G]
 
{verse: Chorus}
[F]I’m learning to [C]fly,  [Am] [G] [F]but I ain’t got [C]wings [Am] [G]
[F]Coming [C]down  [Am] [G] [F]is the hardest [C]thing [Am] [G]
 
{verse: Verse}
[F]Well the good ol’ [C]days,  [Am] [G] [F]may not re[C]turn  [Am] [G]
[F]And the rocks may [C]melt  [Am] [G] [F]and the sea may [C]burn  [Am] [G]
 
{verse: Chorus}
[F]I’m learning to [C]fly,  [Am] [G] [F]but I ain’t got [C]wings [Am] [G]
[F]Coming [C]down  [Am] [G] [F]is the hardest [C]thing [Am] [G]
 
{verse: Verse}
[F]Well some say [C]life  [Am] [G] [F]will beat you [C]down, [Am] [G]
[F]Break your [C]heart,  [Am] [G] [F]steal your [C]crown [Am] [G]
[F]So I started [C]out,  [Am] [G] [F]for god knows [C]where [Am] [G]
[F]I guess I’ll [C]know  [Am] [G] [F]when I get [C]there [Am] [G]
 
{verse: Chorus}
[F]I’m learning to [C]fly,  [Am] [G] [F]around the [C]clouds, [Am] [G]
[F]But what goes [C]up  [Am] [G] [F]must come [C]down [Am] [G]',NULL),
	 ('Έστειλα ένα περιστέρι',102,NULL,0,NULL,'2026-10-14 07:55:26','2026-10-14 07:55:26','{title: Έστειλα ένα περιστέρι}
{verse: Verse}
[Am]Έστειλα ένα περιστέρι στην α[E]πάνω γειτο[Am]νιά
[Am]ένα μήνυμα να φέρει από [E]μιαν ομορφο[Am]νιά
[Am]Πέρασε το καλοκαί[Dm]ρι και με βρήκε χειμω[Am]νιά
[Am]Κι έμεινε το περιστέ[Dm]ρι στην απά[E]νω γειτο[Am]νιά
 
{verse: Chorus}
[Am]Τι να μου [Dm]πεις και [G]τι να [C]πω
Δεν φταις ε[Dm]σύ που σ'' αγα[Am]πώ
Δεν φταις ε[Dm]σύ που [G]σ'' αγα[C]πώ
Τι να μου [Dm]πεις και [E]τι να [C]πω
 
{verse: Verse}
[Am]Είν'' η ελπίδα μου η μόνη ο καη[E]μός μου ο κρυ[Am]φός
[Am]Ήτανε ένα χελιδόνι μέσα [E]στο γαλάζιο [Am]φως
[Am]τώρα έρχονται τα χρό[Dm]νια με τη γκρίζα συννε[Am]φιά
[Am]Φεύγουν και τα χελιδό[Dm]νια κι είμαι δί[E]χως συντρο[Am]φιά
 
{verse: Chorus}
[Am]Τι να μου [Dm]πεις και [G]τι να [C]πω
Δεν φταις ε[Dm]σύ που σ'' αγα[Am]πώ
Δεν φταις ε[Dm]σύ που [G]σ'' αγα[C]πώ
Τι να μου [Dm]πεις και [E]τι να [C]πω',NULL),
	 ('Νυχτερίδες και αράχνες',38,NULL,0,NULL,'2026-10-14 08:02:22','2026-10-14 08:02:22','{title: Νυχτερίδες και αράχνες}
{verse: Verse}
[E]Νυχτερίδες και [Dm]αράχνες γλυκιά μου
[E]έχουν χτίσει φω[Dm]λιά
[Dm]μέσα στο έρημο [C]κι άδειο μας σπίτι
[Dm]όσο λείπεις μα[E]κριά
[E]Νυχτερίδες και αράχνες γλυκιά μου
[Dm]μου κρατούν συντρο[Am]φιά

{verse: Chorus} 
[Am]Γύρισε γλυ[E]κιά μου, στην αγκα[Am]λιά μου, στα βάσα[Dm]νά μου
μην μ'' απαρνη[E]θείς [Am]
Ε[G]σένα στερ[F]νή μου α[E]γάπη
[G]με πόνο ζη[F]τώ για να [E]ρθεί-ς [Am]
μια καρ[E]διά που πονά
να [Dm]γιατρέψεις ξανά μην [Am]αργείς, μην αργείς
 
{verse: Verse}
[E]Την σκιά μου ρω[Dm]τώ κάθε βράδυ
[E]αν ποτέ θα σε [Dm]δω
[Dm]Για να δώσεις χα[C]ρά στη ζωή μου
[Dm]στην καρδιά μου παλ[E]μό
[E]Μα πονάμε και κλαίμε μονάχοι
[Dm]η σκιά μου και ε[Am]γώ
 
{verse: Chorus} 
[Am]Γύρισε γλυ[E]κιά μου, στην αγκα[Am]λιά μου, στα βάσα[Dm]νά μου
μην μ'' απαρνη[E]θείς [Am]
Ε[G]σένα στερ[F]νή μου α[E]γάπη
[G]με πόνο ζη[F]τώ για να [E]ρθεί-ς [Am]
μια καρ[E]διά που πονά
να [Dm]γιατρέψεις ξανά μην [Am]αργείς, μην αργείς',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Αλλοτινές μου εποχές',38,NULL,0,NULL,'2026-10-14 08:07:52','2026-10-14 08:07:52','{title: Αλλοτινές μου εποχές}
{verse: Verse}
[Am]Αλλοτινές μου επο[E]χές
αλλοτινοί μου χρό[Am]νοι
Ερωτικές μου συντρο[E]φιές
ερωτι[Dm]κοί μου πό[Am]νοι
 
{verse: Chorus}
[A]Αχ και να ''ρχόσαστε ξανά
αυτά τα κρύα δειλι[Dm]νά
που είν'' η καρδιά μου μό[Am]νη
τώρα που [F]σουρου[G]πώ[E]νει
Αλλοτι[Am]νές μου επο[Dm]χές
Αλλο[E]τινοί μου χρό[Am]νοι
 
{verse: Verse}
[Am]Αγαπημένες μου φω[E]νές
αγαπημένα χεί[Am]λη
Ονειρεμένες μου στι[E]γμές
σ'' ονειρε[Dm]μένο δεί[Am]λι
 
{verse: Chorus}
[A]Αχ και να φέρνατε ξανά
στην ορφανή μου την καρ[Dm]διά
μηνύματα τ'' Απρί[Am]λη
της μονα[F]ξιάς μου [G]φί[E]λοι
Αγαπη[Am]μένες μου φω[Dm]νές
Αγαπη[E]μένα χεί[Am]λη',NULL),
	 ('My immortal',103,NULL,0,NULL,'2026-10-14 08:21:57','2026-10-14 08:21:57','{title: My immortal}
{verse: Intro}
[C] [Em]
[C] [Em]
 
{verse: Verse}
[C]I''m so tired of being [Em]here
[C]Suppressed by all my [Em]childish fears
[C]And if you have to leave
[Em]I wish that you would just leave
[C]''cause your presence still lingers here
[Em]and it won''t leave me a[Am]lone
 
{verse: Pre-chorus}
[Em]These wounds won''t seem to [Am]heal
[Em]This pain is just too [Am]real
[Em]There''s just too much that [G]time cannot e[Am]rase
 
{verse: Chorus}
When you [F]cried I''d [G]wipe away [Em]all of your [Am]tears
When you''d [F]scream I''d [G]fight away [Em]all of your [Am]fears
And I [F]held your [G]hand through [Em]all of these [Am]years
but you [F]still [G]have all of [C]me
 
{verse: Interlude}
[C] [Em]
[C] [Em]
 
{verse: Verse}
[C]You used to captivate me [Em]by your resonating light
[C]but now I''m bound by the [Em]life you left behind
[C]Your face it haunts [Em]my once pleasant dreams
[C]Your voice it chased away [Em]all the sanity in [Am]me
 
 
{verse: Pre-chorus}
[Em]These wounds won''t seem to [Am]heal
[Em]This pain is just too [Am]real
[Em]There''s just too much that [G]time cannot e[Am]rase
 
{verse: Chorus}
When you [F]cried I''d [G]wipe away [Em]all of your [Am]tears
When you''d [F]scream I''d [G]fight away [Em]all of your [Am]fears
And I [F]held your [G]hand through [Em]all of these [Am]years
but you [F]still [G]have all of [C]me
 
{verse: Bridge}
[F]I''ve tried so [Am]hard to tell my[G]self that you''re [F]gone
but [Dm]though you''re still [Em]with me
[F]I''ve been [G]alone all a[Am]long
 
{verse: Interlude}
[Am] [F] [G] [Em]
[Am] [F] [G] [Em]
 
{verse: Chorus}
When you [F]cried I''d [G]wipe away [Em]all of your [Am]tears
When you''d [F]scream I''d [G]fight away [Em]all of your [Am]fears
And I [F]held your [G]hand through [Em]all of these [Am]years
but you [F]still [G]have all of [C]me
 
{verse: Outro}
[C]Me... [Em]Oooh...
[C]Me... [Em]Oooh...
[C]Me... [Em]Oooh...',NULL),
	 ('Ιστορία παλιά',104,NULL,0,NULL,'2026-10-14 09:39:09','2026-10-14 14:29:00','{title: Ιστορία παλιά}
{verse: Intro}
[C] [F] [C] [G] [F]

{verse: Verse}
[C]Ιστορίες παλιές θα ''[F]ρθεις να πεις να διαλέξω
[C]Τις ξέρω καλά, τις [F]ξέρω τις έμαθα απ ''έξω
[C]Ιστορία παλιά που σου λέει [F]ξανά σ'' αγαπώ
Τώρα [C]πάω πάω μα[F]κριά
 
{verse: Pre-chorus}
[G]Και ότι και αν πεις είναι αργά δεν με[F]τράει
[G]Σαν σπάσει η αγάπη ξανά δεν κο[F]λλάει
 
{verse: Chorus}
[C]Τώρα πάω, πάω μα[F]κριά
Σ'' αγα[C]πάω μα είναι αρ[F]γά
 
{verse: Verse}
[C]Ιστορία παλιά θα σου [F]πω άλλη μια φορά
τα [C]λόγια της ακριβός θησαυρός
οι [F]λέξεις της είναι χρυσός
μην την [C]πεις μην την πεις μ'' ακούς
η σιω[F]πή σου είναι ο μόνος χρυσός
δεν σ'' α[C]κούω δεν έχεις φωνή
τα ξε[F]πούλησες όλα δεν μένει δραχμή
Και στην [C]μάχη που θέλεις να πας
έχεις [F]χάσει από πριν φύγε μην πολεμάς
 
{verse: Pre-chorus}
[G]Τι μου πες τι σου πα είναι αργά δεν με[F]τράει
Σαν [G]σπάσει η αγάπη ξανά δεν κο[F]λλάει
 
{verse: Chorus}
Μα που [C]πας
Πάω μα[F]κριά
Μ'' αγα[C]πάς στο λέω είναι αρ[F]γά
 
{verse: Solo}
[C] [F] [C] [F] [C] [F]
 
{verse: Verse}
[C]Ιστορία παλιά τελευ[F]ταία φορά θα σου πω
[C]Μην ψάχνεις τέλος και αρχή
Η φω[F]τιά σου έχει σβήσει είμαι σ'' άλλη εποχή
[C]Πονάει η φωνή μη λες αν [F]φύγεις εσύ δεν υπάρχω και εγώ
[C]Δεν έχει η ιστορία αρχή ούτε τέλος
[F]Κάθε της λέξη θανάσιμο βέλος
 
{verse: Pre-chorus}
[G]Και ότι κι αν πούμε είναι αργά δεν με[F]τράει
[G]Σαν σπάσει η αγάπη ξανά δεν κο[F]λλάει
 
{verse: Chorus}
Τώρα [C]πάω, πάω μα[F]κριά
Σ'' αγα[C]πάω μα είναι αρ[F]γά
Τώρα [C]πάω, πάω μα[F]κριά',NULL),
	 ('Έφυγες',105,NULL,0,NULL,'2026-10-14 10:31:39','2026-10-14 10:31:39','{title: Έφυγες}
{verse: Verse}
[F]Δίχως λόγο κλαίω και δεν [C]ξέρω τι αισθάνομαι
και δεν [Dm]ξέρω που θα ήθελα να [Am]είμαι
[F]ξέρω πως τα πράγματα αλ[C]λιώς τ'' αντιλαμβάνομαι
κι αγα[Dm]πάω αυτό που τίποτα [Em]δεν είναι
 
{verse: Chorus}
[Am]Έφυγες και όλα μοιάζουν [Dm]όνειρο κακό
δεν μπορώ να καταλάβω, [Em]μοναχά κοι[Am]τώ
[F]όσο και να με πειράζει [Dm]μόνο αυτό θα πω
να προ[Em]σέχεις, καλή τύχη, σ'' [Am]αγαπώ
 
{verse: Verse}
[F]Βλέπω την καρδιά μου που κομ[C]μάτια τώρα γίνεται
και τα [Dm]χέρια προς το μέρος σου α[Am]πλώνω
[F]νιώθω κάθε μέρα τη ζω[C]ή ν'' απομακρύνεται
και ξα[Dm]νά που σ'' αγαπάω με[Em]τανιώνω
 
{verse: Chorus}
[Am]Έφυγες και όλα μοιάζουν [Dm]όνειρο κακό
δεν μπορώ να καταλάβω, [Em]μοναχά κοι[Am]τώ
[F]όσο και να με πειράζει [Dm]μόνο αυτό θα πω
να προ[Em]σέχεις, καλή τύχη, σ'' [Am]αγαπώ',NULL),
	 ('Χειμώνας είναι',106,NULL,0,NULL,'2026-10-14 11:33:18','2026-10-16 07:32:24','{title: Χειμώνας είναι}
{verse: Verse}
[Am]Νύχτες φευ[G]γάτες μ'' αλκο[Em]τέστ κι εξακρι[Dm]βώσεις
[Am]σε μια πο[G]ρεία μες στην [Em]κοσμοχαλα[Am]σιά
[Am]ήρθαν σε [G]βρήκαν και σου [Em]είπαν να δη[Dm]λώσεις
[F]κι εσύ τους είπες μονα[G]ξιά
[Em]δηλώνω μονα[Am]ξιά
 
{verse: Verse}
[Am]Νύχτες φευ[G]γάτες με υπο[Em]σχέσεις και δη[Dm]λώσεις
[Am]σε μια πα[G]τρίδα όλο [Em]τρύπες και φτε[Am]ρά
[Am]ήρθαν σε [G]πιάσαν και σου [Em]είπαν να δη[Dm]λώσεις
[F]κι εσύ τους είπες ερη[Am]μιά
[Em]δηλώνω ερη[Am]μιά
 
{verse: Chorus}
[Dm]Χαμένος [G]τώρα σε πα[Em]ράδεισους κρυ[Am]φούς
[G]των Εξαρχείων την πλα[Em]τεία να βι[Am]ώνεις
[Dm]καλέ μου [G]φίλε σου μι[Em]λώ και δε μ'' α[F]κούς
[Dm]χειμώνας είναι εκεί που [G]πας [Em]
και θα κρυ[Am]ώνεις
 
{verse: Interlude}
[Am]Να να [C]να να [G]να να να [Em]να να να [Am]να να να να
να να [C]να να [G]να να να [Am]να να να
[Am]Να να [C]να να [G]να να να [Em]να να να [Am]να να να να
να να [C]να να [G]να να να [Am]να να να
 
{verse: Verse}
[Am]Μέρες και [G]νύχτες σαν που[Em]λιά στην καται[Dm]γίδα
[Am]αυτήν που [G]τρέμουν και φο[Em]βούνται τα παι[Am]διά
[Am]ήρθαν κι ε[G]κείνοι που σου [Em]πούλαγαν ελ[Dm]πίδα
[Dm]κι ενώ τους πήρες αγκα[G]λιά [Em]
σου πέρασαν [Am]θηλιά
 
{verse: Chorus}
[Dm]Χαμένος [G]τώρα σε πα[Em]ράδεισους κρυ[Am]φούς
[G]των Εξαρχείων την πλα[Em]τεία να βι[Am]ώνεις
[Dm]καλέ μου [G]φίλε σου μι[Em]λώ και δε μ'' α[F]κούς
[Dm]χειμώνας είναι εκεί που [G]πας [Em]
και θα κρυ[Am]ώνεις
 
{verse: Interlude}
[Am]Να να [C]να να [G]να να να [Em]να να να [Am]να να να να
να να [C]να να [G]να να να [Am]να να να
[Am]Να να [C]να να [G]να να να [Em]να να να [Am]να να να να
να να [C]να να [G]να να να [Am]να να να

{verse: Chorus}
[Dm]Χαμένος [G]τώρα σε πα[Em]ράδεισους κρυ[Am]φούς
[G]των Εξαρχείων την πλα[Em]τεία να βι[Am]ώνεις
[Dm]καλέ μου [G]φίλε σου μι[Em]λώ και δε μ'' α[F]κούς
[Dm]χειμώνας είναι εκεί που [G]πας [Em]
και θα κρυ[Am]ώνεις
 
{verse: Outro}
[Am]Να να [C]να να [G]να να να [Em]να να να [Am]να να να να
να να [C]να να [G]να να να [Am]να να να',NULL),
	 ('Πριν το χάραμα',38,NULL,0,NULL,'2026-10-14 12:59:55','2026-10-14 12:59:55','{title: Πριν το χάραμα}
{verse: Verse}
[Am]Πριν το χάραμα μονάχος [F]εξεκίνη[Am]σα
[F]Αχ, και στο πρώτο [E]μας το [Am]στέκι [E]την αυγούλα γύρι[Am]σα
 
{verse: Verse}
[Am]Πριν ακόμα σβήσουν τ’ άστρα [F]εξεπόρτι[Am]σα
[F]Αχ, να ξανάβρω [E]τα δυο σου [Am]χείλη, [E]που ποτέ δεν χόρτα[Am]σα
 
{verse: Verse}
[Am]Αν και άλλη μ’ είχε μπλέξει [F]με καμώμα[Am]τα
[F]Αχ, σ’ αγαπώ [E]κι ήρθα κο[Am]ντά σου [E]πριν τα ξημερώμα[Am]τα',NULL),
	 ('Βραδιάζει',38,NULL,0,NULL,'2026-10-14 13:15:30','2026-10-14 13:51:46','{title: Βραδιάζει}
{verse: Intro}
[Am] [Em] [F] [G] [E]
[Am] [G] [F] [G] [Am]

{verse: Verse}
Βρα[Am]διάζει πάλι σήμερα βρα[Em]διάζει
κι έρχε[F]ται η ώρα η δι[Em]κιά μου
Αυ[Dm]τή που σα πουκάμισο ται[Am]ριάζει
με τη με[G]λαγχολία στη καρ[F]διά μου, βρα[Am]διάζει

{verse: Bridge}
[Am]

{verse: Chorus}
[Am]Παιδί της νύχτας μια ζωή δε το α[G]ντέχω το πρωί
με τους κυ[F]ρίους στα κα[G]σμήρια τους σφι[C]γμένους
Εγώ τη [Am]νύχτα μόνο ζω μαζί με [G]κείνους π'' αγαπώ
με τους πα[F]ράνομους και [G]τους αδικη[Am]μένους

{verse: Bridge}
[F] [G] [Am]
[Am] [Em] [F] [G] [Am]

{verse: Verse}
Βρα[Am]διάζει πάλι σήμερα βρα[Em]διάζει
και τότε [F]το τραγούδι σιγο[Em]πιάνω
Σα [Dm]μανά το σκοτάδι μ’ αγκα[Am]λιάζει
μια τέτοια [G]ώρα θέλω να πε[F]θάνω βρα[Am]διάζει
 
{verse: Chorus}
[Am]Παιδί της νύχτας μια ζωή δε το α[G]ντέχω το πρωί
με τους κυ[F]ρίους στα κα[G]σμήρια τους σφι[C]γμένους
Εγώ τη [Am]νύχτα μόνο ζω μαζί με [G]κείνους π'' αγαπώ
με τους πα[F]ράνομους και [G]τους αδικη[Am]μένους

{verse: Bridge}
[F] [G] [Am]

{verse: Outro}
Βρα[Am]διάζει πάλι σήμερα βρα[Em]διάζει
κι έρχε[F]ται η ώρα η δι[Em]κιά μου
Αυ[Dm]τή που σα πουκάμισο ται[Am]ριάζει
με τη με[G]λαγχολία στη καρ[F]διά μου, βρα[Am]διάζει',NULL),
	 ('Το βουνό',107,NULL,0,NULL,'2026-10-14 13:36:34','2026-10-14 13:36:34','{title: Το βουνό}
{verse: Intro}
[G] [Dm] [Em]
[C] [E] [Am]
[Em] [Dm] [Em]

{verse: Verse}
[Em]Θ'' ανέβω [G]και θα τραγουδήσω
στο πιο ψηλότε[Dm]ρο βου[Em]νό
[C]ν'' ακούγεται [E] στην ερη[Am]μιά
ο πόνος [Em]μου με [Dm]την πε[Em]νιά

{verse: Interlude}
[G] [Dm] [Em]
[C] [E] [Am]
[Em] [Dm] [Em]
 
{verse: Verse}
[Em]Mε το βου[G]νό θα γίνω φίλος
και με τα [Dm]πεύκα συντρο[Em]φιά
[C]κι όταν θα κλαί[E]ω και [Am]πονώ
θ'' αναστε[Em]νάζει [Dm]το βου[Em]νό  

{verse: Interlude}
[G] [Dm] [Em]
[C] [E] [Am]
[Em] [Dm] [Em]
 
{verse: Verse}
[Em]Aπάνω [G]στο βουνό θα μείνω
κι από τον [Dm]κόσμο μακρι[Em]ά
[C]θα κλαίω μό[E]νος, θα [Am]πονώ  
και θα μ'' [Em]ακούει [Dm]το βου[Em]νό',NULL),
	 ('Με τι καρδιά',51,NULL,0,NULL,'2026-10-15 06:33:47','2026-10-15 06:33:47','{title: Με τι καρδιά}
{verse: Verse}
[Em]Με τι καρ[D]διά να [Am]σ'' αποχαιρε[Em]τήσω
[Em]Με τι καρ[D]διά τρα[Am]γούδι να σου [Em]πω
Στον [G]ουρα[Am]νό με τ'' [D]όνειρο θα [G]ζήσω
Στον [G]ουρα[Am]νό σαν [D]άστρο θα χα[G]θώ

{verse: Chorus}
[C]Βάλε φω[D]νή, κοντά σου να γυ[G]ρίσω
[C]Βάλε φω[D]νή, τη γη να θυμη[G]θώ
 
{verse: Verse}
[Em]Με τι καρ[D]διά τα [Am]μάτια σου ν'' α[Em]φήσω
[Em]Με τι καρ[D]διά τον [Am]κόσμο ν'' αρνη[Em]θώ
Σε [G]σκοτει[Am]νό γε[D]φύρι θα κα[G]θίσω
Σε [G]σκοτει[Am]νό πο[D]τάμι θα στα[G]θώ
 
{verse: Chorus}
[C]Δώσ'' μου φω[D]τιά, τη νύχτα μου να [G]σβήσω
[C]Δώσ'' μου φω[D]τιά, στον ήλιο να βρε[G]θώ',NULL),
	 ('Ιστορία μου',7,NULL,0,NULL,'2026-10-15 06:41:32','2026-10-15 06:41:32','{title: Ιστορία μου}
{verse: Verse}
[Am]Eίναι γλυκό το πιο[Dm]τό της αμαρ[Am]τίας
Ποιος ειν'' αυτός, που δεν λα[G]χτάρησε να [Am]πιει
Aυτή την [Dm]γλύκα της κλεμμένης ευτυ[Am]χίας
λίγο πο[F]λύ όλοι την [E]έχουμε γευ[Am]τεί [F] [E] [Am]
 
{verse: Chorus}
Iστο[Am]ρία μου, αμαρ[G]τία [Am]μου
[Dm]λάθος μου με[Am]γάλο
Eίσ'' η αρ[Am]ρώστια μου, μέσ'' τα [G]στήθια [Am]μου
[Dm]και [E] πώς να σε [Am]βγάλω
 
{verse: Verse}
[Am]Παρακαλώ πότε [Dm]να ''ρχεται το [Am]βράδυ
Πότε να ''ρθεί εκείνη η [G]ώρα η γνω[Am]στή
που θα φα[Dm]νείς όπως ο κλέφτης στο σκο[Am]τάδι
κι απ'' την λα[F]χτάρα η καρ[E]διά μου θα σφι[Am]χτεί [F] [E] [Am]
 
{verse: Chorus}
Iστο[Am]ρία μου, αμαρ[G]τία [Am]μου
[Dm]λάθος μου με[Am]γάλο
Eίσ'' η αρ[Am]ρώστια μου, μέσ'' τα [G]στήθια [Am]μου
[Dm]και [E] πώς να σε [Am]βγάλω',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Dreams',27,NULL,0,NULL,'2026-10-15 10:08:05','2026-10-15 10:08:05','{title: Dreams}
{verse: Intro}
[D] [G] [A] [D]
[D] [G] [A] [D]
 
{verse: Verse}
[D] Oh, my [G]life is changing every [A]day,
In every possible [D]way
[D] And oh, my [G]dreams it''s never quite as it [A]seems,
Never quite as it [D]seems
 
{verse: Pre-chorus}
[D]I know I felt like this be[G]fore
But now I''m feeling it even [A]more
Because it came from [D]you
 
{verse: Pre-chorus}
[D]Then I open up and [G]see
The person falling here is [A]me
A different way to [D]be
 
{verse: Verse}
[D] I want [G]more, impossible to i[A]gnore,
Impossible to i[D]gnore
[D] They''ll come [G]true, impossible
Not to [A]do, impossible not to [D]do

{verse: Pre-chorus}
[D]And now I tell you open[G]ly
You have my heart so don''t hurt [A]me
You''re what I couldn''t [D]find
 
{verse: Pre-chorus}
[D]A totally amazing [G]mind
So understanding and so [A]kind
You''re everything to [D]me
 
{verse: Verse}
[D] Oh, my [G]life is changing every [A]day,
In every possible [D]way
[D] And oh, my [G]dreams
It''s never quite as it [A]seems
''Cause you''re a dream to [D]me, dream to me',NULL),
	 ('Thousand years',108,NULL,0,NULL,'2026-10-15 12:14:05','2026-10-15 12:14:05','{title: Thousand years}
{verse: Intro}
[G] [D] [Em] [D] [C] [D]
 
{verse: Verse}
[C]Heartbeats fast
Colors and [G]promises
How to be [Em]brave
How can I [D]love when
[G] I''m a[C]fraid to fall
But watching you [G]stand alone
All of my [Em]doubt suddenly
[D]goes a[G]way some[Am]how
One step [Em]cloooooo [D]ser
 
{verse: Chorus}
[G]I have died everyday
waiting for you
[Em]Darling don''t be afraid
I have loved you
For a [C]thousand years
I love you for a [D]thousand more
 
{verse: Verse}
[C]Time stands still
Beauty in [G]all she is
I will be [Em]brave
I will not [D]let
[G]anything [C]take away
What''s standing in [G]front of me
Every [Em]breath
Every [D]hour has [G]come to [Am]this
One step [Em]cloooooo [D]ser
 
{verse: Chorus}
[G]I have died everyday
waiting for you
[Em]Darling don''t be afraid
I have loved you
For a [C]thousand years
I love you for a [D]thousand more
 
{verse: Chorus}
And [G]all along I believed
I would find you
[Em]Time has brought your heart to me
I have loved you
for a [C]thousand years
I''ll love you for a [D]thousand more',NULL),
	 ('Behind blue eyes',109,NULL,0,NULL,'2026-10-15 12:47:55','2026-10-15 14:49:32','{title: Behind blue eyes}
{verse: Intro}
[Em] [G] [D] [C] [A]
 
{verse: Verse}
[Em]No one knows what it''s [G]like, to be the [D]bad man,
To be the [C]sad man, be[A]hind blue eyes
[Em]No one knows what it''s [G]like to be [D]hated,
To be [C]fated, to telling [A]only lies
 
{verse: Chorus}
But my [C]dreams [D], they aren''t as [G]empty,
As my [C]conscience [D]seems to [Em]be
I have [Bm]hours, only [C]lonely
My love is [D]vengeance that''s never [A]free
 
{verse: Verse}
[Em]No one knows what it''s [G]like to feel these [D]feelings
Like I [C]do, and [A]I blame you
[Em]No one bites back as [G]hard on their [D]anger
None of [C]my pain and woe, can [A]show through
 
{verse: Chorus}
But my [C]dreams [D], they aren''t as [G]empty,
As my [C]conscience [D]seems to [Em]be
I have [Bm]hours, only [C]lonely
My love is [D]vengeance that''s never [A]free
 
{verse: Verse}
[Em]No one knows what it''s [G]like
To be mis[D]treated, to be de[C]feated
[A]Behind blue eyes
[Em]No one knows how to [G]say
That they''re [D]sorry and don''t [C]worry
I''m not [A]telling lies
 
{verse: Chorus}
But my [C]dreams [D], they aren''t as [G]empty,
As my [C]conscience [D]seems to [Em]be
I have [Bm]hours, only [C]lonely
My love is [D]vengeance that''s never [A]free
 
{verse: Outro}
[Em]No one knows what it''s [G]like, to be the [D]bad man,
To be the [C]sad man, be[A]hind blue eyes',NULL),
	 ('Αργοσβήνεις μόνη',62,NULL,0,NULL,'2026-10-15 13:31:41','2026-10-15 13:31:41','{title: Αργοσβήνεις μόνη}
{verse: Intro}
[Em] [C] [B7] [Am] [B7] [Am] [Em]
 
{verse: Verse}
[Em]Αχ στης ζωής τη στράτα αργοσβήνεις [Am]μόνη
δίχως να ''χεις κα[Em]μιά συντρο[C]φιά μαυρο[B7]μάτα
[Em]πώς κλαίω και θρηνώ για [Am]τα γλυκά σου [Em]νιάτα
 
{verse: Prelude}
[B7] [Am] [Em]
 
{verse: Pre-chorus}
[Em]Αν σε α[B7]πάτησε και σε τραυ[Em]μάτισε
ο έρω[Am]τας που φωτίζει τα [Em]μάτια σου
[B7]τα πανάκριβα πα[Em]λάτια σου
 
{verse: Chorus}
[E]Η αγάπη [Dm]μου θα σε για[Am]τρέψει
και [B7]τ'' όνειρό σου το πα[Am]λιό
θα ζωντα[Em]νέψει',NULL),
	 ('Στο άδεια μου πακέτο',110,NULL,0,NULL,'2026-10-16 12:47:16','2026-10-21 09:49:26','{title: Στο άδειο μου πακέτο}
{verse: Verse}
Στο [Em]άδειο μου πακέτο απόψε [F]μπήκες
δεν [Em]ξέρω τι ζητάς και αν το [F]βρήκες
Αχ [Dm]να ''σουνα τσιγάρο τελε[Em]υταίο
γουλιά-γου[Dm]λιά μαζί σου να τα [Em]λέω
 
{verse: Chorus}
[Em]Μα τι να πω
που'' μαι στεγνός από ψιλά και από παρέα
και σ'' αγαπώ
γιατί ''σαι άπιαστη σαν όλα τα ωραία
Τι να σου [Am]πω
άδειο βαγόνι το μυαλό μου [Em]αραγμένο
Το σ'' αγα[F]πώ πάνω στου μπράτσου μου
χαράζω την [Em]πληγή
και δεν μπο[Am]ρώ
να μη σε δω ούτε να μην σε [Em]περιμένω
που δεν μπο[F]ρείς ν'' ακολουθήσεις
τη δική μου τη φυ[Em]γή
 
{verse: Verse}
Δεν [Em]ξέρω λόγια όμορφα να [F]δίνω
και αν [Em]τα ''θελες σε μένα μην τα [F]ψάξεις
Ε[Dm]δώ που είμαι άσε με να [Em]μείνω
χω[Dm]ρίς να προσπαθήσεις να μ'' αλ[Em]λάξεις

{verse: Chorus} 
[Em]Μα τι να πω
στο περιθώριο που ζω φυλακισμένος
Το σ'' αγαπώ
μοιάζει με λέξη που τη λέει μεθυσμένος
Τι να σου [Am]πω
άδειο βαγόνι το μυαλό μου [Em]αραγμένο
Το σ'' αγα[F]πώ πάνω στου μπράτσου μου
χαράζω την [Em]πληγή
και δεν μπο[Am]ρώ
να μη σε δω ούτε να μην σε [Em]περιμένω
που δεν μπο[F]ρείς ν'' ακολουθήσεις
τη δική μου τη φυ[Em]γή',NULL),
	 ('Drive',84,NULL,0,NULL,'2026-10-18 13:14:56','2026-10-18 13:14:56','{title: Drive}
{verse: Intro}
[Dm]
 
{verse: Verse}
[Dm]Smash, crack, bushwacked
[G]Tie another one to the racks, [Dm]baby
[Dm]Hey kids, rock and roll
[G]Nobody tells you where to go, [Dm]baby
 
{verse: Chorus}
[F]What if I ride, what if you walk
[Am]What if you rock around the clock
[G]Tick-tock, tick-tock
[Em]What if you did, what if you walk
What if you tried to get off, [Dm]baby
 
{verse: Verse}
[Dm]Hey kids, where are you
[G]Nobody tells you what to do, [Dm]baby
[Dm]Hey kids, shake a leg
[G]Maybe you''re crazy in the head, [Dm]baby
 
{verse: Chorus}
[F]Maybe you did, maybe you walked
[Am]Maybe you rocked around the clock
[G]Tick-tock, tick-tock
[Em]Maybe I ride, maybe you walk
Maybe I try to get off, [Dm]baby
 
{verse: Bridge}
[C]Hey kids, shake a leg
Maybe you''re crazy in the head, [Dm]baby
[C]Ollie, ollie, ollie ollie ollie
Ollie ollie, in come free, [Dm]baby
[C]Hey kids, where are you
[G]Nobody tells you what to do, [Dm]baby

{verse: Interlude}
[Dm]
 
{verse: Verse}
[Dm]Smack, crack, shack a lack
[G]Tie another one to your back, [Dm]baby
[Dm]Hey kids, rock and roll
[C]Nobody tells you where to go, [Dm]baby
 
{verse: Chorus}
[F]Maybe you did, maybe you walked
[Am]Maybe you rocked around the clock
[G]Tick-tock, tick-tock
[Em]Maybe I ride, maybe you walk
Maybe I try to get off, [Dm]baby
 
[Em]Hey kids, where are you
Nobody tells you what to do, [Dm]baby
[Em]Hey kids, rock and roll
Nobody tells you where to go, [Dm]baby
 
{verse: Outro}
[Dm]Baby ... baby ...',NULL),
	 ('Δεν φταίω εγώ που μεγαλώνω',77,NULL,0,NULL,'2026-10-19 06:50:15','2026-10-20 12:02:22','{title: Δεν φταίω εγώ που μεγαλώνω}
{verse: Verse}
[Em]Και να που τα ταξίδια μείναν [C]μόνο, [Em]όνειρα
[Em]και να που οι φωνές και τα τρα[C]γούδια, [Em]σώπασαν
[Am]και να που η ζωή τώρα κυ[Bm]λάει, πιο γρήγορα
και [C]να που τα παιδιά και τα παι[Am]χνίδια, [Em]χάθηκαν [C] [D]
 
{verse: Chorus}
[Em]Δε φταίω ε[C]γώ που μεγα[Am]λώ[Bm]νω, [C]χτυπάει πι[D]σώπλατα ο [Em]χρόνος [C] [D]
[Em]δε φταίω ε[C]γώ που μεγα[Am]λώ[Bm]νω, [C]φταίει η ζω[D]ή, που είναι μι[G]κρή
 
{verse: Verse}
[Em]Ραγίσαν τα φεγγάρια που ''χε [C]φέρει, η [Em]Άνοιξη
[Em]μαρμάρωσε το φως στο τελευ[C]ταίο, [Em]νύχτωμα
φτια[Am]σίδι ερωτικό που θα φο[Bm]ράει, το αύριο
στις [C]πιάτσες τις βροχής όταν που[Am]λιέται [Em]Σάββατο [C] [D]
 
{verse: Chorus}
[Em]Δε φταίω ε[C]γώ που μεγα[Am]λώ[Bm]νω, [C]χτυπάει πι[D]σώπλατα ο [Em]χρόνος [C] [D]
[Em]δε φταίω ε[C]γώ που μεγα[Am]λώ[Bm]νω, [C]φταίει η ζω[D]ή, που είναι μι[G]κρή',NULL),
	 ('Η μπαλάντα του Ούρι',42,NULL,0,NULL,'2026-10-22 13:29:36','2026-10-22 13:29:36','{title: Η μπαλάντα του Ούρι}
{verse: Verse}
[Am]Ουρανέ, [E]όχι δεν θα [Am]πω το ναι
[Am]Ουρανέ, [E]φίλε μακρι[Am]νέ
Πώς να δε[F]χτώ [G]άλλης αγκα[C]λιάς τη στορ[Am]γή
Πώς να δεχτώ, [E]μάνα μου είν'' η [Am]γη
Πώς ν'' αρνη[F]θώ [G]της ζωής το [C]φως το ξαν[Am]θό
Αχ, ουρανέ, [E]πόνε μακρι[Am]νέ
 
{verse: Chorus}
[Am]Κάθε δειλινό κοιτώ τον ουρανό, τον γαλανό
κι ακούω μια φω[Em]νή, καμπάνα γιορτι[B7]νή, να με παρα[E]κινεί
[Am]Κάθε Κυριακή, μου λέει να πάω εκεί, εκεί, εκεί
που χτίζουνε φω[Em]λιά αλλόκοτα που[B7]λιά, στου ήλιου τα [E]σκαλιά

{verse: Verse}
[Am]Ουρανέ, [E]όχι δεν θα [Am]πω το ναι
[Am]Ουρανέ, [E]φίλε μακρι[Am]νέ
Πώς να δε[F]χτώ [G]άλλης αγκα[C]λιάς τη στορ[Am]γή
Πώς να δεχτώ, [E]μάνα μου είν'' η [Am]γη
Πώς ν'' αρνη[F]θώ [G]της ζωής το [C]φως το ξαν[Am]θό
Αχ, ουρανέ, [E]πόνε μακρι[Am]νέ
 
{verse: Chorus}
[Am]Κάθε δειλινό κοιτώ τον ουρανό, τον γαλανό
και μια φωνή τρε[Em]λή, σαν χάδι κι απει[B7]λή κοντά της με [E]καλεί
[Am]Κάθε Κυριακή μου λέει να πάω εκεί, εκεί, εκεί
μου τάζει ωκεα[Em]νούς, κομήτες φωτει[B7]νούς και ό,τι βάζει [E]ο νους

{verse: Outro}
[Am]Ουρανέ, [E]όχι δεν θα [Am]πω το ναι
[Am]Ουρανέ, [E]φίλε μακρι[Am]νέ',NULL),
	 ('Τα ζηλιάρικά σου μάτια',12,NULL,0,NULL,'2026-10-22 14:08:10','2026-10-22 14:08:10','{title: Τα ζηλιάρικά σου μάτια}
{verse: Intro}
[Am] [E] [Am]
 
{verse: Verse}
[Am]Τα ζηλιάρικά σου μάτια μ'' έχουν ξετρελάνει
Δε λογάριασα παλάτια, σκλάβο μ'' έχουν κάνει
[A]Μαρα[Dm]ζώνω, σαν [G]το κεράκι [C]λιώνω
[Dm]Με παι[E]δεύεις, γιατί δεν μ'' αγα[Am]πάς
[A]Μαρα[Dm]ζώνω, σαν [G]το κεράκι [C]λιώνω
[Dm]Με παι[E]δεύεις, γιατί δεν μ'' αγα[Am]πάς
 
{verse: Verse}
[Am]Σε αγάπησα στ'' αλήθεια και για σένα κλαίω
Έχω φλόγα μες στα στήθια κι άκου που στο λέω
[A]Η μα[Dm]τιά σου, η [G]άστατη καρ[C]διά σου
[Dm]μου ''χει [E]πάρει το δόλιο μου μυα[Am]λό
[A]Η μα[Dm]τιά σου, η [G]άστατη καρ[C]διά σου
[Dm]μου ''χει [E]πάρει το δόλιο μου μυα[Am]λό
 
{verse: Verse}
[Am]Είναι κρίμα να μ'' αφήνεις μόνος μου να λιώνω
Μαύρη συντροφιά μου δίνεις μοναχά τον πόνο
[A]Σε λα[Dm]τρεύω, [G]σε χαϊ[C]δεύω
[Dm]μην κα[E]κιώνεις γιατί θα τρελα[Am]θώ
[A]Σε λα[Dm]τρεύω, [G]σε χαϊ[C]δεύω
[Dm]μην κα[E]κιώνεις γιατί θα τρελα[Am]θώ [E] [Am]',NULL),
	 ('Κάθε φορά',63,NULL,0,NULL,'2026-10-23 09:18:06','2026-10-23 10:03:56','{title: Κάθε φορά}
{verse: Verse}
[Em]Κάθε φορά που τελειώνει ο [Am]κόσμος
[Em]να με κρατάς [D] απ'' το χέρι σφι[C]χτά
[Em]να περπατάς πλάι μου στα συ[Am]ντρίμμια
[Em]να με κοιτάς [D]  με τα μάτια κλει[Am]στά
 
{verse: Pre-chorus}
[Em]Κάθε φορά που τε[Am]λειώνει ο [D]κόσμος
όταν θα κλαίω θέλω να μου γε[Em]λάς
κι όσα τραγούδια [Am]έχω αγαπήσει
[D]μέσα στ'' αυτί να μου τραγου[Em]δάς
 
{verse: Chorus}
Κι όταν ξανά θα τελειώσει ο [D]κόσμος
φίλα με σαν να ''ναι η πρώτη φο[Em]ρά
και μέσα στη ζεστή αγκα[D]λιά σου
ίσως αρχίσει ο κόσμος ξα[C]νά
 
{verse: Solo}
[Em] [Am] [D] [Em]
[Em] [D] [D] [Em]
[Em] [D] [D] [C] [D]
 
{verse: Verse}
[Em]Κάθε φορά που τελειώνει ο [Am]κόσμος
[Em]να με κρατάς[D] έξω από το νε[C]ρό
[Em]στο παγερό τ'' αγριεμένο [Am]κύμα
[Em]της ξενιτιάς,[D]  φως μου να μη βρα[Em]χώ
 
{verse: Pre-chorus}
[Em]Κάθε φορά που τε[Am]λειώνει ο [D]κόσμος
όταν θα κλαίω θέλω να μου γε[Em]λάς
κι όσα τραγούδια [Am]έχω αγαπήσει
[D]μέσα στ'' αυτί να μου τραγου[Em]δάς
 
{verse: Chorus}
Κι όταν ξανά θα τελειώσει ο [D]κόσμος
φίλα με σαν να ''ναι η πρώτη φο[Em]ρά
και μέσα στη ζεστή αγκα[D]λιά σου
ίσως αρχίσει ο κόσμος ξα[C]νά
 
{verse: Solo}
Σόλο
[Em] [Am] [Am] [Em] [D] [C] [D]
 
{verse: Pre-chorus}
[Em]Κάθε φορά που τε[Am]λειώνει ο [D]κόσμος
όταν θα κλαίω θέλω να μου γε[Em]λάς
κι όσα τραγούδια [Am]έχω αγαπήσει
[D]μέσα στ'' αυτί να μου τρα[Em]γουδάς
 
{verse: Chorus}
Κι όταν ξανά θα τελειώσει ο [D]κόσμος
φίλα με σαν να ''ναι η πρώτη φο[Em]ρά
και μέσα στη ζεστή αγκα[D]λιά σου
ίσως αρχίσει ο κόσμος ξα[C]νά',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Του έρωτα',47,NULL,0,NULL,'2026-10-23 09:24:55','2026-10-23 10:01:46','{title: Του έρωτα}
{verse: Verse}
[Am]Αϊ σκοτεινό [G]φως του [Am]έρωτα
Τρεμάμενο [G]αίμα του [Am]έρωτα
Μες τη γη[Dm]τειά σου ελη[G]σμόνησα τους φο[C]νιά[G]δες και[Am]ρούς
[Dm]Γέννησα ρόδινα μωρά, σε [C]μέλλον με α[Am]στέρια
[F]Αϊ σκοτει[G]νό φως του [Dm]έρωτα
 
{verse: Verse}
[Am]Αϊ της α[G]γάπης μαχαι[Am]ριά
[F]Στης νιότης [G]το κρουστό κορ[Am]μί
[F]Πληγή που ανά[G]βλυζε ευωδι[C]ές [G] φιλι[Am]ών και [G]μουσική [F]
[Dm]Ντύνοντας το γυμνό έρημο [F]κόσμο [G]
[F]Αϊ της α[G]γάπης μαχαι[Am]ριά
 
{verse: Verse}
[Am]Αϊ της α[G]γάπης μαχαι[Am]ριά
[F]Στης νιότης[G] το κρουστό κορ[Am]μί
[F]Πληγή που ανά[G]βλυζε ευωδι[C]ές [G]φιλιών [Am] [G]
[F]Αϊ της α[G]γάπης μαχαιριά[Am]
[F]Αϊ της α[G]γάπης μαχαιριά[Am]
[F]Αϊ της α[G]γάπης μαχαιριά[Am]',NULL),
	 ('Σαν απόκληρος γυρίζω',38,NULL,0,NULL,'2026-10-26 07:33:52','2026-10-26 07:34:17','{title: Σαν απόκληρος γυρίζω}
{verse: Verse}
[F]Σαν [C]α[Dm]πόκληρος γυ[Am]ρίζω [F]στην [C]κα[Dm]κούργα ξενι[Am]τιά
[Dm]περιπλανώμενος, δυστυχι[Am]σμένος
μακριά απ'' της [E]μάνας μου την αγκα[Am]λιά
 
{verse: Verse}
[F]Κλαί[C]νε [Dm]τα πουλιά γι [Am]αέρα [F]και [C]τα [Dm]δέντρα για νε[Am]ρό
[Dm]Κλαίω μανούλα μου κι εγώ για [Am]σένα
που έχω [E]χρόνια για να σε [Am]δω
 
{verse: Verse}
[F]Χά[C]ρε, [Dm]πάρε την ψυ[Am]χή μου, [F]η[C]συ[Dm]χία για να [Am]βρω
[Dm]Αφού το θέλησε η μαύρη [Am]μοίρα
μες στη ζω[E]ή μου να μη χα[Am]ρώ',NULL),
	 ('Όταν έχω εσένα',15,NULL,0,NULL,'2026-10-26 07:38:24','2026-10-26 07:38:24','{title: Όταν έχω εσένα}
{verse: Verse}
Όταν έχω ε[C]σένα
μπορώ να ονει[G]ρεύομαι ξανά
ανοίγω μες στη [F]θάλασσα πανιά
και πιάνω μες στα [G]χέρια μου
τον κόσμο να τον [G]φτιάξω
Όταν έχω [F]εσένα
μπορώ να μη βυ[G]θίζομαι αργά
τα βράδια που πλη[F]γώνεται η καρδιά
και πιάνω το μα[G]χαίρι
το σκοτάδι να [C]χαράξω
 
{verse: Chorus}
Κάνε ένα [Am]βήμα
να κάνω το [F]επόμενο
αίμα μου και [G]σχήμα
λόγος και ψυχή στο συμφρα[Em]ζόμενο
Όταν έχω ε[Am]σένα
νιώθω σαν παιδί, έχω έναν [F]άνθρωπο
μη φοβού κα[G]νένα
Εγώ κι εσύ στον κόσμο
τον α[Em]πάνθρωπο
εσύ και ε[G]γώ
 
{verse: Verse}
Όταν έχω ε[C]σένα
μπορώ να βάψω με α[G]σήμι τη σκουριά
μπορώ να κοιμη[F]θώ με σιγουριά
να πιάσω με τα [G]χέρια μου
τους δράκους να σκο[G]τώσω
Όταν έχω ε[F]σένα
αντέχω, πάω [G]δίπλα στον γκρεμό
το ξέρω, έχω ένα [F]χέρι να πιαστώ
κοντά μου έναν [G]άνθρωπο
τα χρόνια μου να ε[C]νώσω

{verse: Chorus}
Κάνε ένα [Am]βήμα
να κάνω το [F]επόμενο
αίμα μου και [G]σχήμα
λόγος και ψυχή στο συμφρα[Em]ζόμενο
Όταν έχω ε[Am]σένα
νιώθω σαν παιδί, έχω έναν [F]άνθρωπο
μη φοβού κα[G]νένα
Εγώ κι εσύ στον κόσμο
τον α[Em]πάνθρωπο
εσύ και ε[G]γώ',NULL),
	 ('Άλλος για Χίο τράβηξε',15,NULL,0,NULL,'2026-10-26 07:41:18','2026-10-26 07:47:44','{title: Άλλος για Χίο τράβηξε}
{verse: Verse}
[Em]Στα καλντερίμια συζητούν ως το πρωί οι γει[D]τόνοι      | 2x
[D]μα σκοτεινιάζει ο καιρός [B7]και στις καρδιές νυ[Em]χτώνει   | 2x
 
{verse: Chorus}
[G]Άλλος για Χίο [D]τράβηξε, πήγε, [B7]κι άλλος για Μυτι[Em]λήνη   | 2x
κι [F]άλλος στης Σύρας [Em]τα στενά [B7]αίμα και δάκρυα [Em]πίνει   | 2x
 
{verse: Verse}
[Em]Σε πανηγύρι και γιορτή απ'' την Άγια Μαρ[D]κέλλα   | 2x
[D]σ'' αγόρασα χρυσή κλωστή [B7]και κόκκινη κορ[Em]δέλα    | 2x
 
{verse: Chorus}
[G]Άλλος για Χίο [D]τράβηξε, πήγε, [B7]κι άλλος για Μυτι[Em]λήνη   | 2x
κι [F]άλλος στης Σύρας [Em]τα στενά [B7]αίμα και δάκρυα [Em]πίνει   | 2x

{verse: Chorus}
[G]Άλλος για Χίο [D]τράβηξε, πήγε, [B7]κι άλλος για Μυτι[Em]λήνη   | 2x
κι [F]άλλος στης Σύρας [Em]τα στενά [B7]αίμα και δάκρυα [Em]πίνει   | 2x',NULL),
	 ('Σαγαπώ σαν αμαρτία',15,NULL,0,NULL,'2026-10-26 07:47:44','2026-10-26 07:47:44','{title: Σαγαπώ σαν αμαρτία}
{verse: Verse}
[Am]Κάθεσαι στο [Dm]μπαλκο[Am]νάκι
[Am]Σα λουλούδι [Dm]αθάνα[Am]το
Μα ε[C]γώ σαν τ αηδο[Dm]νάκι
Παί[G]ζω με το θάνα[C]το [E]
Δε με [Am]νοιάζει [Dm]κι αν πε[Am]θάνω
Δε με νοιάζει [Dm]κι αν χα[Am]θώ
Ένα [C]μόνο με μα[Dm]ραίνει
Που μ [E]αφήνεις μονα[Am]χό [E] [Am]
 
{verse: Chorus}
[Am]Σ αγαπώ [G]σαν αμαρ[Am]τία
[Am]Σε μισώ [G]σαν φυλα[Am]κή
Κό[E]ψε με αν θες στα [Dm]τρία
Στάλα [G]αίμα δεν θα [C]βγει [E]
 
{verse: Chorus}
Σ αγα[Am]πώ σαν [G]αμαρ[Am]τία
[Am]Σε μισώ [G]σαν φυλα[Am]κή
Κό[E]ψε με αν θες στα [Dm]τρία
Στάλα [G]αίμα δεν θα [C]βγει [E]
 
{verse: Verse}
Τα βε[Am]λούδινα [Dm]σου [Am]χείλη
[Am]Δεν μα[Dm]τώσανε πο[Am]τές
Είσαι η [C]καύτρα στο κα[Dm]ντήλι
Που το [G]λάδι μου το [C]καις [E]
Στα μαλ[Am]λιά σου [Dm]κρέμα[Am]σέ με
Χτυπο[Am]κάρδι [Dm]και βρι[Am]σιά
Να μη [C]βλέπω άλλα [Dm]χείλη
Να σου [E]πίνουν τη δρο[Am]σιά [E] [Am]

{verse: Chorus}
[Am]Σ αγαπώ [G]σαν αμαρ[Am]τία
[Am]Σε μισώ [G]σαν φυλα[Am]κή
Κό[E]ψε με αν θες στα [Dm]τρία
Στάλα [G]αίμα δεν θα [C]βγει [E]
 
{verse: Chorus}
Σ αγα[Am]πώ σαν [G]αμαρ[Am]τία
[Am]Σε μισώ [G]σαν φυλα[Am]κή
Κό[E]ψε με αν θες στα [Dm]τρία
Στάλα [G]αίμα δεν θα [C]βγει [E]',NULL),
	 ('Ένα όμορφο αμάξι με δυο άλογα',40,NULL,0,NULL,'2026-10-26 07:51:49','2026-10-26 07:51:49','{title: Ένα όμορφο αμάξι με δυο άλογα}
{verse: Verse}
[Am]Ένα όμορφο αμάξι με [Dm]δυο [E]άλογα
Να μου φέρετε τα μάτια μου σαν [Am]κλείσω
Τον ντουνιά με τα στραβά και τα πα[Dm]ράλο[E]γα
Καβαλάρης μια φορά να σεργια[Am]νίσω
 
{verse: Chorus}
[Am]Το ένα [G]τ'' άλογο να είναι [Am]άσπρο
[G]όπως τα όνειρα που έκανα [C]παιδί [Am]
[Am]Το άλλο [G]τ'' άλογο να είναι [Am]μαύρο
Σαν τη πι[E]κρή μου τη κατάμαυρη ζω[Am]ή
 
{verse: Verse}
[Am]Να χτυπώ το καμουτσίκι μου το [Dm]άπο[E]νο
Σαν της μοίρας μου τ'' αβάσταχτα χα[Am]στούκια
Και ν'' ακούγεται τη νύχτα σαν πα[Dm]ράπο[E]νο
Σαν πενιά λυπητερή από μπου[Am]ζούκια
 
{verse: Chorus}
[Am]Το ένα [G]τ'' άλογο να είναι [Am]άσπρο
[G]όπως τα όνειρα που έκανα [C]παιδί [Am]
[Am]Το άλλο [G]τ'' άλογο να είναι [Am]μαύρο
Σαν τη πι[E]κρή μου τη κατάμαυρη ζω[Am]ή',NULL),
	 ('Όμορφή μου Κατερίνα',111,NULL,0,NULL,'2026-10-26 07:56:51','2026-10-26 07:56:51','{title: Όμορφή μου Κατερίνα}
{verse: Verse}
[C]Κάνει βόλτα το φεγγάρι, [Dm]βγαίνουν έξοδο οι φαντάροι
[F]κι είναι μια βραδιά ω[Dm]ραία, [G]στην Αθήνα, στον [C]Περαία
[C]Χάθηκαν οι καστανάδες [Dm]κι οι αργόσχολοι βοριάδες
[F]κι απ'' τη ρίζα του χει[Dm]μώνα [G]φύτρωσε μια ανε[C]μώνα
 
{verse: Chorus}
[C]Όμορφή μου Κατε[Dm]ρίνα, [G]του μπαξέ μου καρ[C]δερίνα
[A]Άνοιξε τα βλέφα[Dm]ρά σου [G]και τα ροδοπέτα[C]λά σου
[C]Να χιμήξω στ'' ακρο[Dm]γιάλια [G]του κορμιού σου τα κα[C]θάρια
[A]Που ''χουν βότσαλα κο[Dm]χύλια [G]του ουρανού τα πετρα[C]χήλια
 
{verse: Verse}
[C]Κάνει βόλτα η λατέρνα [Dm]στολισμένη ως τη φτέρνα
[F]κι ένα αμούστακο χα[Dm]μίνι, [G]μιας μικρής τον ήλιο [C]πίνει
[C]Κι ένας άνεμος αντάρτης [Dm]σαν ηλιοκαμένος ναύτης
[F]βγήκε βόλτα στα σο[Dm]κάκια, [G]να γλυκάνει τα φαρ[C]μάκια
 
{verse: Chorus}
[C]Όμορφή μου Κατε[Dm]ρίνα, [G]του μπαξέ μου καρ[C]δερίνα
[A]Άνοιξε τα βλέφα[Dm]ρά σου [G]και τα ροδοπέτα[C]λά σου
[C]Να χιμήξω στ'' ακρο[Dm]γιάλια [G]του κορμιού σου τα κα[C]θάρια
[A]Που ''χουν βότσαλα κο[Dm]χύλια [G]του ουρανού τα πετρα[C]χήλια',NULL),
	 ('Ανήμερα του έρωτα',9,NULL,0,NULL,'2026-10-26 08:04:03','2026-10-26 11:21:32','{title: Ανήμερα του έρωτα}
{verse: Verse}
[Am]Ανήμερα του έρωτα [Dm]τα πάντα σου [G]φανέρωσα [C]για μένα [E]
σου [Am]είπα ότι άλλαξα σε [Dm]σένα κατα[G]στάλαξα σε σέ[C]να [E]
και [Dm]γέμισαν τα μάτια σου με [E]φως
χω[Am]ρίς να με ρωτήσεις τι και [F]πως
μ'' α[Dm]γκάλιασες με φίλησες και [E]είπες περασμένα ξεχα[Am]σμένα [F] [E]
 
{verse: Verse}
Α[Am]νήμερα την άνοιξη [Dm]την πόρτα τη μι[G]σάνοιχτη α[C]νοίγω [E]
αλ[Am]λάζω τις εικόνες μου [Dm]κι απ'' έξω τους [G]χειμώνες μου α[C]φήνω [E]
ξε[Dm]χνώ ότι με πόνεσες βα[E]θιά
και [Am]πέφτω στη δική σου αγκα[F]λιά
Στα [Dm]χέρια σου αφήνομαι και [E]σβήνω τα πα[Am]λιά

{verse: Chorus}
[Dm]Έρω[G]τα τι μου ''χεις [C]κάνει έρω[Am]τα
[Dm]μια στιγ[E]μή δεν ησυ[Am]χάζεις
[Dm]Έρω[G]τα τι μου ''χεις [C]κάνει έρω[Am]τα
[Dm]μέλι [G]και φαρμάκι [E]στάζεις
πόσο μου [Am]μοιάζεις
 
[Am]Ανήμερα του έρωτα μα[Dm]ζί σου όσα [G]πέρασα θυ[C]μάμαι [E]
μα [Am]τώρα που τελειώσαμε [Dm]τι πήραμε τι δώσαμε [C]μετράμε [E]
ο [Dm]έρωτας τις πιο πολλές φο[E]ρές ο[Am]νόματα αλλάζει και μορ[F]φές
τη [Dm]μια γεμίζεις όνειρα την [E]άλλη ενο[Am]χές [F] [E]
 
{verse: Chorus}
[Dm]Έρω[G]τα τι μου ''χεις [C]κάνει έρω[Am]τα
[Dm]μια στιγ[E]μή δεν ησυ[Am]χάζεις
[Dm]Έρω[G]τα τι μου ''χεις [C]κάνει έρω[Am]τα
[Dm]μέλι [G]και φαρμάκι [E]στάζεις
πόσο μου [Am]μοιάζεις',NULL),
	 ('Άστην να λέει',42,NULL,0,NULL,'2026-10-26 08:07:53','2026-10-26 08:07:53','{title: Άστην να λέει}
{verse: Verse}
[Am]Σου είπε έτσι πρέπει, [G]γεια χαρά
Εσύ δα[Am]κρύζεις [G]
[Am]Σου είπε πως επέρασε πολ[G]λά
Θέλει να [Am]φύγει [G]
 
{verse: Pre-chorus}
[F]Δεν έμαθε ποτέ της ν'' αγα[Em]πά
και είναι [Am]μόνη [G]
[F]Δεν έμαθε ποτέ της να πο[G]νά
και σε πλη[E]γώνει

{verse: Chorus}
Άσ'' την να [Am]λέει, άσ'' την να [Em]λέει           | 2x
[Dm]εκείνη μόνο ξέρει, και [Em]μέσα της θα κλαίει  | 2x
[Am]Άσ'' την να λέει [Em]
Άσ'' την να [Dm]λέει [Em]
Άσ'' την να [Am]λέει
 
{verse: Verse}
[Am]Κι αν έφυγε και πήγε μα[G]κριά
Αυτή θα [Am]χάσει [G]
[Am]Σου ράγισε για λίγο την καρ[G]διά
Θα σου πε[Am]ράσει [G]
 
{verse: Pre-chorus}
[F]Δεν έμαθε ποτέ της ν'' αγα[Em]πά
και είναι [Am]μόνη [G]
[F]Δεν έμαθε ποτέ της να πο[G]νά
και σε πλη[E]γώνει

{verse: Chorus}
Άσ'' την να [Am]λέει, άσ'' την να [Em]λέει           | 2x
[Dm]εκείνη μόνο ξέρει, και [Em]μέσα της θα κλαίει  | 2x
[Am]Άσ'' την να λέει [Em]
Άσ'' την να [Dm]λέει [Em]
Άσ'' την να [Am]λέει',NULL),
	 ('Γιατί',42,NULL,0,NULL,'2026-10-26 08:13:07','2026-10-27 06:50:41','{title: Γιατί}
{verse: Intro}
[Am] [G] [F] [Em]
 
{verse: Verse}
[Am]Άδειες στιγμές η [G]ψυχή μας κενή
[F]Τα λόγια υπάρχουν γιατί [Em]υπήρχαν εκεί
[Am]Πλοίο τα μάτια, τα μαλ[G]λιά σου πανί
[F]Πόσο σε ήθελα και [Em]πόσο εσύ
 
{verse: Chorus}
Για[Am]τί, [G]  [Dm]τί [Em]
Για[Am]τί το τρα[G]γούδι αυτό
[Dm]Πάντα να λέει [Em]δεν μπορώ
Για[Am]τί κι εσύ με [G]σπρώχνεις στο γκρεμό
[Dm]Δε σε συγχωρώ, [Em]δε σε συγχωρώ, για[Am]τί
 
{verse: Solo}
[Am] [G] [F] [Em]

{verse: Verse}
[Am]Κοίτα να δεις πως αλ[G]λάξαμε
[F]Δες τη ζωή που ξε[Em]γράψαμε
[Am]Με μια ματιά με μια [G]κίνηση απλή
[F]Ο εγωισμός σου, πάντα αυ[Em]τός οδηγεί

{verse: Chorus}
Για[Am]τί, [G]  [Dm]τί [Em]
Για[Am]τί το τρα[G]γούδι αυτό
[Dm]Πάντα να λέει [Em]δεν μπορώ
Για[Am]τί κι εσύ με [G]σπρώχνεις στο γκρεμό
[Dm]Δε σε συγχωρώ, [Em]δε σε συγχωρώ, για[Am]τί',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Χειμωνανθός',112,NULL,0,NULL,'2026-10-26 11:44:26','2026-10-26 11:44:26','{title: Χειμωνανθός}
{verse: Verse}
[Am]Φθινόπωρο στον [F]έρωτα
[Am]απόψε ανα[F]τέλλει
[G]αρισμαρί και [Am]μέλι
[G]μύρισαν τα βου[Em]νά
[Am]κι εγώ κοιτάζω [F]σιωπηλός
[Am]το χώμα το βρεγ[F]μένο
[G]σαν κάρβουνο αναμ[Am]μένο
[G]η ομορφιά πο[Am]νά
 
{verse: Verse}
[Am]Φιλί γυρεύω του [F]ουρανού
[Am]κι αυτός μου δίνει [F]στάχτη
[G]μα απ'' της καρδιάς τ'' α[Am]δράχτι
[G]σαν θέλω να κο[Em]πείς
[Am]σαλεύουν τα πορ[F]τόφυλλα
[Am]κι η κλειδωνιά γυ[F]ρίζει
[G]αέρας μου σφυ[Am]ρίζει
[G]αν έρθεις μην αρ[Am]γείς

{verse: Chorus}
[Am]Γδύσου κι από τα [G]μάτια μου
[Am]πάρε νερό και [G]πλύσου
[F]ο χωρισμός θυ[G]μήσου
[Dm]είναι χειμωναν[Em]θός
[Am]την λύπη την κα[G]τοίκησα
[Am]σε νύχτα και σε [G]μέρα
[F]σ'' αφήνω στον α[G]έρα
[Dm]για να σε βρω στο [Am]φως

{verse: Verse}
[Am]Η αγάπη φόβους κι [F]όνειρα
[Am]δειπνά προτού ρα[F]γίσει
[G]στου πόνου το ξω[Am]κλήσι
[G]αγιάζει η ερη[Em]μιά
[Am]κι εγώ μια θλίψη [F]που ζητώ
[Am]για να με σημα[F]δέψει
[G]το φως πριν βασι[Am]λέψει
[G]θα σ'' αρνηθώ ξα[Am]νά

{verse: Chorus}
[Am]Γδύσου κι από τα [G]μάτια μου
[Am]πάρε νερό και [G]πλύσου
[F]ο χωρισμός θυ[G]μήσου
[Dm]είναι χειμωναν[Em]θός
[Am]την λύπη την κα[G]τοίκησα
[Am]σε νύχτα και σε [G]μέρα
[F]σ'' αφήνω στον α[G]έρα
[Dm]για να σε βρω στο [Am]φως',NULL),
	 ('Στο μπαράκι',113,NULL,0,NULL,'2026-10-26 12:31:20','2026-10-26 12:36:29','{title: Στο μπαράκι}
{verse: Verse}
Σε μπα[Em]ράκι μικρό σε συνάντησα, μόνη και σκεφτι[Am]κή
Στη μα[D]τιά σου την πρώτη ναυάγησα, σ'' εξωτικό νη[G]σί [B7]
Μ'' ένα [Em]θάρρος τρελό σε πλησίασα κάνοντας την αρ[Am]χή
Μ'' ένα [C]σλόγκαν γνωστό κι αρκε[Em]τά πειστικό, [B7]φανερά ερωτικό
 
{verse: Chorus}
Σ'' έχω [Em]δει κάπου, κάπου σε [Am]ξέρω
τα [D]μάτια σου αυτά μου ''ναι τόσο γνω[G]στά
Σ'' έχω [C]δει κάπου, κάπου σε [Am]ξέρω
Η [B7]μνήμη μου δεν μ'' απατά       
 
{verse: Verse}
Η σιω[Em]πή σου ψυχρή κι ανεξήγητη, μου ''κοψε τα φτε[Am]ρά
Η μα[D]τιά σου στο χώρο πλανήθηκε για άλλη μια φο[G]ρά [B7]
Κι ήρθε [Em]ξάφνου αυτός της καρδιάς σου ο Θεός κι όλα χαθήκα[Am]νε
Και [C]τώρα ζητώ συντρο[Em]φιά στο ποτό, [B7]μόνος και μονολογώ
 
{verse: Chorus}
Σ'' έχω [Em]δει κάπου, κάπου σε [Am]ξέρω
τα [D]μάτια σου αυτά μου ''ναι τόσο γνω[G]στά
Σ'' έχω [C]δει κάπου, κάπου σε [Am]ξέρω
Η [B7]μνήμη μου δεν μ'' απατά',NULL),
	 ('Καμαρούλα μια σταλιά',14,NULL,0,NULL,'2026-10-26 13:30:35','2026-10-26 13:34:06','{title: Καμαρούλα μια σταλιά}
{verse: Verse}
[Am]Άπλωσε το [E]μεσονύχτι [Am]το γλυκό του δίχτυ
[F]πάνω στη μι[G]κρή μας γειτο[C]νιά [E]
[Am]Ξέχασέ τα [E]όλα τώρα, [Am]είναι της αγάπης ώρα
[F]βάλε το κλειδί στην κλειδω[E]νιά
 
{verse: Chorus}
[F]Καμαρούλα [G]μια σταλιά, [F]δύο [G]επί [C]τρία
[F]κόγχη [G]και λα[C]τρεία, [F]τοίχος και φι[C]λιά
[F]Καμαρούλα [G]μια σταλιά, [E]τοίχος και φι[Am]λιά
 
{verse: Verse}
[Am]Φύσα το κε[E]ρί να σβήσει [Am]και να μάς αφήσει
[F]μόνους μες [G]στη νύχτα την κα[C]λή [E]
[Am]Σφίξου στην καρ[E]διά μου επάνω [Am]για να σε ζεστάνω
[F]σα χελιδονάκι, σαν που[E]λί
 
{verse: Chorus}
[F]Καμαρούλα [G]μια σταλιά, [F]δύο [G]επί [C]τρία
[F]κόγχη [G]και λα[C]τρεία, [F]τοίχος και φι[C]λιά
[F]Καμαρούλα [G]μια σταλιά, [E]τοίχος και φι[Am]λιά',NULL),
	 ('Passenger',115,NULL,0,NULL,'2026-10-27 07:21:40','2026-10-27 07:21:40','{title: Passenger}
{verse: Intro}
[Am] [F] [C] [G]
[Am] [F] [C] [E]
[Am] [F] [C] [G]
[Am] [F] [C] [E]
[Am] [F] [C] [G]
[Am] [F] [C] [E]
 
{verse: Verse}
[Am]I am a [F]passe[C]nger [G]
[Am]And I [F]ride and I [C]ride [E]
[Am]I ride [F]through the [C]city back[G]sides
[Am]I see the [F]stars come [C]out of the [E]sky
[Am]Yeah, they''re [F]bright in a [C]hollow [G]sky
[Am]You know it [F]looks so [C]good to[E]night
 
{verse: Instrumental}
[Am] [F] [C] [G]
[Am] [F] [C] [E]
 
{verse: Verse}
[Am]I am the [F]passen[C]ger [G]
[Am]I stay [F]under [C]glass [E]
[Am]I look [F]through my [C]window so [G]bright
[Am]I see the [F]stars come [C]out to[E]night
[Am]I see the [F]bright and [C]hollow [G]sky
[Am]Over the [F]city''s [C]ripping [E]sky
[Am]And every[F]thing looks [C]good to[G]night
 
{verse: Instrumental}
[Am] [F] [C] [E]
 
{verse: Chorus}
[Am]Singing la [F]la laa la la [C]la laa la la [G]
[Am]A la la laa [F]la la la laa [C]la la [E]
[Am]la la laa [F]la la la laa la[C] la [G]
 
{verse: Instrumental}
[Am] [F] [C] [G]
[Am] [F] [C] [E]
 
{verse: Verse}
[Am]Get in[F]to the [C]car [G]
[Am]We''ll be the [F]passen[C]ger [E]
[Am]We''ll ride [F]through the [C]city to[G]night
[Am]We''ll see the [F]city''s [C]ripped back[E]sides
[Am]We''ll see the [F]bright and [C]hollow [G]sky
[Am]We''ll see the [F]stars that [C]shine so [E]bright
[Am]The stars [F]made for [C]us to[G]night
 
{verse: Instrumental}
[Am] [F] [C] [E]
[Am] [F] [C] [G]
[Am] [F] [C] [E]
 
{verse: Verse}
[Am]Oh, the [F]passen[C]ger [G]
[Am]Oh, [F]how you [C]ride [E]
[Am]Oh, the [F]passen[C]ger [G]
[Am]He [F]rides and he [C]rides [E]
[Am]He looks [F]through his [C]window [G]
[Am]And what [F]does he [C]see [E]
[Am]He sees the [F]bright and [C]hollow [G]sky
[Am]He sees the [F]stars come [C]out to[E]night
[Am]He sees the [F]city''s [C]ripped back[G]sides
[Am]He sees the [F]winding [C]ocean [E]drive
[Am]And every[F]thing was made for [C]you and [G]me
[Am]All of it was [F]made for [C]you and [E]me
[Am]''Cause it just be[F]longs to [C]you and [G]me
[Am]So let''s take a [F]ride and [C]see what''s [E]mine
 
{verse: Instrumental}
[Am] [F] [C] [G]
[Am] [F] [C] [E]
 
{verse: Chorus}
[Am]And singing [F]la la laa la [C]la la laa la [G]la
[Am]A la laa la[F]laaaaa la la [C]laa la la [E]laa
[Am]la laa lala[F]aaaa la la laa[C] la la [G]laa
La laa [Am]la [F] [C] [E]
 
{verse: Instrumental}
[Am] [F] [C] [G]
 
{verse: Verse}
[Am]Are you the [F]passen[C]ger? [G]
[Am]He sees [F]things from under [C] glass [E]
[Am]He looks [F]through his [C]window side [G]
[Am]He sees the [F]things he [C]knows are his [E]
[Am]He sees the [F]bright and [C]hollow [G]sky
[Am]He sees the [F]city [C]sleeping at [E]night
[Am]He sees the [F]stars are [C]out to[G]night
[Am]And all of [F]it is [C]yours and [E]mine
[Am]And all of [F]it is [C]yours and [G]mine
[Am]So let''s all [F]ride and ride [C]and ride and [E]ride
 
{verse: Instrumental}
[Am] [F] [C] [G]
[Am] [F] [C] [E]

{verse: Chorus}
[Am]And singing [F]la la laa la [C]la la laa la [G]la
[Am]A la laa la[F]laaaaa la la [C]laa la la [E]laa
[Am]la laa lala[F]aaaa la la laa[C] la la [G]laa
La laa [Am]la [F] [C] [E]',NULL),
	 ('Μικρή πατρίδα',104,NULL,0,NULL,'2026-10-27 08:00:43','2026-10-27 08:00:43','{title: Μικρή πατρίδα}
{verse: Intro}
[Em] [Bm] [Cm] [Bm]
[Em] [Bm] [Cm] [Em]
 
{verse: Verse}
Δεν [Em]έκανα ταξίδια μακρι[Bm]νά
τα [Am]χρόνια μου είχαν ρίζες ήταν [Em]δέντρα
που [Em]τα `ντυσε με φύλλα η καρ[Bm]διά
και [Am]τ’ άφησε ν’ ανθίζουν μες την [Em]πέτρα
 
{verse: Verse}
Δεν [Em]έκανα ταξίδια μακρι[Bm]νά
οι [Am]άνθρωποι που αγάπησα ήταν [Em]δάση
οι [Em]φίλοι μου φεγγάρια ήταν νη[Bm]σιά
που [Am]δίψασε η καρδιά μου να τα [C]ψάξει
που [C]δίψα[D]σε η καρ[Am]διά μου [Bm]να τα [Em]ψάξει
 
{verse: Chorus}
Το [C]πιο μακρύ τα[Bm]ξίδι μου εσύ
η [F]νύχτα εσύ το όνειρο της [Em]μέρας
μι[C]κρή πατρίδα [Bm]σώμα μου κι αρχή
η [Am]γη μου εσύ α[Gm]νάσα μου κι α[Em]έρας
η [Am]γη μου εσύ α[Bm]νάσα μου κι α[Em]έρας
 
{verse: Instrumental}
[Em] [Bm] [Cm] [Bm]
[Em] [Bm] [Cm] [Em]
 
{verse: Verse}
Δεν [Em]έκανα ταξίδια μακρι[Bm]νά
τα[Am]ξίδεψε η καρδιά κι αυτό μου [Em]φτάνει
σε [Em]όνειρα σ’ αισθήματα υ[Bm]γρά
το [Am]μυστικό τον κόσμο ν’ ανα[C]σάνει
το [C]μυστι[D]κό τον [Am]κόσμο [Bm]ν’ ανα[Em]σάνει
 
{verse: Chorus}
Το [C]πιο μακρύ τα[Bm]ξίδι μου εσύ
η [F]νύχτα εσύ το όνειρο της [Em]μέρας
μι[C]κρή πατρίδα [Bm]σώμα μου κι αρχή
η [Am]γη μου εσύ α[Gm]νάσα μου κι α[Em]έρας
η [Am]γη μου εσύ α[Bm]νάσα μου κι α[Em]έρας',NULL),
	 ('Είπα να φύγω',9,NULL,0,NULL,'2026-10-27 10:51:08','2026-10-27 14:10:31','{title: Είπα να φύγω}
{verse: Verse}
[Am]Είπα να [Dm]φύγω, μα με [E]κράταγε η λύ[Am]πη
[Am]Είπα να [Dm]μείνω, αλλά [E]είχα κουρα[Am]στεί
[Dm]Ώσπου α[G]ντάμωσα ένα άγιο καρδιο[Em]χτύπι
[Dm]κι είπα να [E]σπάσω του [F]καημού μου [G]την κλω[E]στή
 
{verse: Chorus}
[Am]Είπα να [Dm]φύγω, μα με [E]κράταγε η λύ[Am]πη
[Am]Είπα να [Dm]μείνω, αλλά [E]είχα κουρα[Am]στεί

{verse: Verse}
[Am]Ένας κερ[Dm]δίζει στην α[E]γάπη κι άλλος χά[Am]νει
[Am]Μα όποιος [Dm]κέρδισε, [E]δεν είναι ο νικη[Am]τής
[Dm]Πάντα το [G]δάκρυ του χαμένου τόνε [Em]φτάνει
[Dm]για να του [E]σβήσει το [F]τραγούδι [G]της γιορ[E]τής

{verse: Chorus}
[Am]Ένας κερ[Dm]δίζει στην α[E]γάπη κι άλλος χά[Am]νει
[Am]Μα όποιος [Dm]κέρδισε, [E]δεν είναι ο νικη[Am]τής',NULL),
	 ('Μαγική αυλή',116,NULL,0,NULL,'2026-10-29 07:44:07','2026-10-30 13:07:05','{title: Μαγική αυλή}
{verse: Verse}
[Em]Πέρασα μια νύχτα δίχως τελειω[Am]μό
[Em]Τρέχω μα με βρίσκει η νύχτα στο σταθ[Am]μό
[Em]Δίπλα μου ζητιάνοι γέροι και τυ[Am]φλοί
[Em]Μοιάζει τούτη η γη με μαγική αυ[Am]λή
 
{verse: Chorus}
[G]Και συ τώρα [C]μου μιλάς τα [D]όνειρα δεν είναι [Em]πια για μας
[G]Άλλα όνει[C]ρα να δεις [D]έλα εδώ στη μαγική αυλή να ονειρευτείς
 
{verse: Verse}
[Em]Έφυγε ένας χρόνος χάθηκε στο [Am]χθες
[Em]Όλα μοιάζουν ίδια φίλε τι τα [Am]θες
[Em]Σίδερο τσιμέντο χώμα και γυα[Am]λί
[Em]Μοιάζει τούτη η γη με μαγική αυ[Am]λή
 
{verse: Chorus}
[G]Και συ τώρα [C]μου μιλάς τα [D]όνειρα δεν είναι [Em]πια για μας
[G]Άλλα όνει[C]ρα να δεις [D]έλα εδώ στη μαγική αυλή να ονειρευτείς',NULL),
	 ('Εσύ μουπες πως μαγαπάς',116,NULL,0,NULL,'2026-10-29 07:49:00','2026-10-29 07:49:00','{title: Εσύ μουπες πως μαγαπάς}
{verse: Verse}
[Am]Εσύ μου ''πες πως μ'' αγα[Em]πάς
πως [G]είμαι για '' σένα ο πα[Am]ράδεισος
[Am]στις άδειες σου νύχτες το [Em]φως
ο [G]φίλος σου και ο αδελ[Am]φός
 
{verse: Verse}
[Am]Εσύ μου ''πες πως μ'' αγα[Em]πάς
μα [G]πριν ξημερώσει μ'' αρ[Am]νήθηκες
[Am]και εγώ που σε πίστεψα [Em]πως
να [G]ζήσω ξανά μονα[Am]χός
 
{verse: Chorus}
[Dm]Τώρα σιω[G]πή, τώρα [Dm]φεύγεις και αφήνεις ρυ[Am]τίδες
[C]χτύπα και [G]συ, η καρ[Dm]διά μου ν'' αντέξει μπο[E]ρεί
 
{verse: Verse}
[Am]Εσύ μου ''πες πως μ'' αγα[Em]πάς
πως [G]είμαι για '' σένα ο πα[Am]ράδεισος
[Am]στα μαύρα σου μάτια το [Em]φως
στο [G]στήθος σου ασήμι χρυ[Am]σός
 
{verse: Verse}
[Am]Εσύ μου ''πες πως μ'' αγα[Em]πάς
μα [G]πριν ξημερώσει μ'' αρ[Am]νήθηκες
[Am]μικρό μου αστέρι που [Em]πάς
Ε[G]σύ μου ''πες πως μ'' αγα[Am]πάς
 
{verse: Chorus}
[Dm]Τώρα σιω[G]πή, τώρα [Dm]φεύγεις και αφήνεις ρυ[Am]τίδες
[C]χτύπα και [G]συ, η καρ[Dm]διά μου ν'' αντέξει μπο[E]ρεί',NULL),
	 ('It must have been love',117,NULL,0,NULL,'2026-10-29 08:00:25','2026-10-29 11:25:17','{title: It must have been love}
{verse: Verse}
Lay a [G]whisper on my pillow, leave the [C]winter on the [D]ground
I wake up [G]lonely, there''s air of [C]silence in the [Am]bedroom and all [D]around
Touch me [Em]now, I close my [G]eyes and dream [C]away... [D]
 
{verse: Chorus}
It must have been [G]love, but it''s over [C]now!
It must have been [Am]good, but I [Em]lost it some[D]how...
It must have been [G]love but it''s over [C]now!
From the moment we [Am]touched, till the [Em]time had run [D]out...
 
{verse: Verse}
Make be[G]lieving we''re together, that I''m [C]sheltered by your [D]heart
But in and [G]outside I''ve turned to [C]water, like a [Am]teardrop in [D]your palm
And it''s a [Em]hard winter''s [G]day, I dream [C]away... [D]
 
{verse: Chorus}
It must have been [G]love, but it''s over [C]now!
It was all that I [Am]wanted, now I''m [Em]living with[D]out
It must have been [G]love, but it''s over [Dm]now
It''s where the [G]water flows, it''s where the [F]wind blows',NULL),
	 ('Σε βλέπω στο ποτήρι μου',118,NULL,0,NULL,'2026-10-29 08:06:00','2026-10-29 08:06:00','{title: Σε βλέπω στο ποτήρι μου}
{verse: Verse}
[E]Σε βλέπω στο ποτήρι [Dm]μου [E]και πίνοντας σε πί[Am]νω
[E]Κι όταν τελειώσει το πο[Dm]τό [E]      [Dm]δεν ξέρω τι θα [E]γίνω
 
{verse: Verse}
[Am]Σαν ακούρδιστο ρολόι που δεν παίρνει [G]πια στροφή
[F]Το μυαλό μου έχει μείνει στη δική σου [G]τη [F]μορ[E]φή
 
{verse: Verse}
[E]Σε βλέπω στο ποτήρι [Dm]μου [E]και πίνοντας σε πί[Am]νω
[E]Κι όταν τελειώσει το πο[Dm]τό [E]      [Dm]δεν ξέρω τι θα [E]γίνω
 
{verse: Verse}
[Am]Πίνω από τις εννιά το βραδύ και έφτασε [G]τρεισήμισι
[F]Και το νου μου βασανίζει η δική σου [G]θύ[F]μη[E]ση

{verse: Verse}
[E]Σε βλέπω στο ποτήρι [Dm]μου [E]και πίνοντας σε πί[Am]νω
[E]Κι όταν τελειώσει το πο[Dm]τό [E]      [Dm]δεν ξέρω τι θα [E]γίνω',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Το αεροπλάνο',122,NULL,0,NULL,'2026-11-02 08:04:20','2026-11-02 08:04:20','{title: Το αεροπλάνο}
{verse: Verse}
[C]Πολύ με πίκρανες ζω[Em]ή
[F]Μακριά θα φύγω ένα [Em]πρωί
[Dm]Θα ανέβω σ'' ένα αερο[C]πλάνο
[Dm]Να δω τον [G]κόσμο από κει [C]πάνω [F] [G]
[C]Όταν κοιτάς από ψη[Em]λά, [F]μοιάζει η γη με ζω[Em]γραφιά
[Dm]και συ την πήρες σοβα[C]ρά, [Dm]και συ την [G]πήρες σοβα[C]ρά
 
{verse: Chorus}
[Am]Μοιάζουν τα σπίτια με σπιρ[Em]τόκουτα
[Am]Μοιάζουν μυρμήγκια οι αν[Em]θρώποι
[F]Το μεγαλύτερο [Em]ανάκτορο
[Dm]μοιάζει μ'' ένα μικρούλι [E]τόπι
 
{verse: Chorus}
[Am]Κι όλοι αυτοί που σε πι[Em]κράνανε
[Am]από ψηλά αν τους κοι[Em]τάξεις
[F]θα σου φανούν τόσο α[Em]σήμαντοι
[Dm]που στη στιγμή θα τούς [E]ξεχάσεις [G]
 
{verse: Verse}
[C]Αγαπημένη μου, μην [Em]κλαις, [F]πάμε μαζί ψηλά, [Em]αν θες
[Dm]Να δεις τη γη απ'' τη [C]σελήνη, [Dm]ένα φεγγάρι [G]είναι και [C]κείνη
[C]Όταν κοιτάς από ψη[Em]λά, [F]μοιάζει η γη με ζω[Em]γραφιά
[Dm]και συ την πήρες σοβα[C]ρά, [Dm]και συ την [G]πήρες σοβα[C]ρά
 
{verse: Chorus}
[Am]Μοιάζουν οι πύργοι με κου[Em]κλόσπιτα
[Am]και τα κανόνια με παι[Em]χνίδια
[F]Από ψηλά δεν ξεχω[Em]ρίζουνε
[Dm]οι ομορφιές και τα [E]στολίδια [G]
[Am]Κι ό,τι σε πλήγωσε ή [Em]σε θάμπωσε, [Am]από ψηλά αν το κοι[Em]τάξεις
[F]θα σου φανεί τό[Em]σο ασήμαντο, [Dm]που στη στιγμή θα το ξε[E]χάσεις
 
{verse: Verse}
[C]Αγαπημένη μου, μην [Em]κλαις, [F]πάμε μαζί ψηλά, [Em]αν θες
[Dm]Να δεις τη γη απ'' τη [C]σελήνη, [Dm]ένα φεγγάρι [G]είναι και [C]κείνη
[C]Όταν κοιτάς από ψη[Em]λά, [F]μοιάζει η γη με ζω[Em]γραφιά
[Dm]και συ την πήρες σοβα[C]ρά, [Dm]και συ την [G]πήρες σοβα[C]ρά',NULL),
	 ('Να κοιμηθούμε αγκαλιά',119,NULL,0,NULL,'2026-10-29 08:45:08','2026-10-29 08:45:08','{title: Να κοιμηθούμε αγκαλιά}
{verse: Verse}
[Am]Πάλι μέτρησα τ'' αστέρια και όμως κάποια λείπουνε
[G]Μόνο τα δικά σου χέρια δεν μ'' εγκαταλείπουνε
[F]Πως μ'' αρέσουν τα μαλλιά σου στην βροχή να βρέχονται
[Em]Τα φεγγάρια στο κορμί σου να πηγαινο[Am]έρχονται

{verse: Chorus}
[Am]Να κοιμηθούμε αγκα[Em]λιά να μπερδευ[F]τούν τα όνει[Em]ρά μας
και στων φι[F]λιών την μουσι[Em]κή ρυθμό να [F]δίνει η καρ[G]διά μας
Να κοιμη[Am]θούμε αγκα[Em]λιά να μπερδευ[F]τούν τα όνει[Em]ρά μας
για μια ο[F]λόκληρη ζω[Em]ή να είναι [F]η βραδιά δι[Am]κιά μας
 
{verse: Verse}
[Am]Τα φιλιά σου στον λαιμό μου μοιάζουνε με θαύματα
[G]Σαν τριαντάφυλλα που ανοίγουν πριν απ'' τα χαράματα
[F]Στων ματιών σου το γαλάζιο έριξα τα δίχτυα μου
[Em]Στις δικές σου παραλίες θέλω απ'' τα ξε[Am]νύχτια μου
 
{verse: Chorus}
[Am]Να κοιμηθούμε αγκα[Em]λιά να μπερδευ[F]τούν τα όνει[Em]ρά μας
και στων φι[F]λιών την μουσι[Em]κή ρυθμό να [F]δίνει η καρ[G]διά μας
Να κοιμη[Am]θούμε αγκα[Em]λιά να μπερδευ[F]τούν τα όνει[Em]ρά μας
για μια ο[F]λόκληρη ζω[Em]ή να είναι [F]η βραδιά δι[Am]κιά μας',NULL),
	 ('Χαιρετίσματα λοιπόν',119,NULL,0,NULL,'2026-10-29 08:53:56','2026-10-29 08:53:56','{title: Χαιρετίσματα λοιπόν}
{verse: Verse}
[C]Eγώ δεν θέλω στη ζωή να κυβερ[Em]νήσω
Θέλω να [F]μείνω οπα[G]δός φανατικός
[C]αυτών που πάντοτε την τρώνε από [Em]πίσω
και στο μη[F]δέν ξαναγυρ[G]νάνε διαρ[C]κώς
 
{verse: Chorus}
[Am]Xαιρετίσματα λοιπόν στην εξου[Em]σία
Εγώ κρα[F]τάω την ουσία [G]κι ονειρεύο[C]μαι
[Am]Παίρνω την κιθάρα μου και τραγου[Em]δάω
Σας αγα[F]πάω, [G]μα δεν παντρεύο[C]μαι
 
{verse: Verse}
[C]Eγώ δεν θέλω να με κάνετε σα[Em]τράπη
ούτε συ[F]νένοχο σε [G]κόλπα ομαδικά
Απ'' το ρα[C]διόφωνο σάς στέλνω με α[Em]γάπη
τα τραγου[F]δάκια μου και [G]δυο γλυκά φι[C]λιά
 
{verse: Chorus}
[Am]Xαιρετίσματα λοιπόν στην εξου[Em]σία
Εγώ κρα[F]τάω την ουσία [G]κι ονειρεύο[C]μαι
[Am]Παίρνω την κιθάρα μου και τραγου[Em]δάω
Σας αγα[F]πάω, [G]μα δεν παντρεύο[C]μαι

{verse: Verse}
[C]Eγώ δεν θέλω τον αρμόδιο να [Em]παίξω
ν'' αποφα[F]σίζω κεκλει[G]σμένων των θυρών
Είμαι απ'' αυ[C]τούς που πάντα μένουνε απ'' [Em]έξω
γιατί δεν [F]έχω ούτε γρα[G]βάτα ούτε παπι[C]γιόν
 
{verse: Chorus}
[Am]Xαιρετίσματα λοιπόν στην εξου[Em]σία
Εγώ κρα[F]τάω την ουσία [G]κι ονειρεύο[C]μαι
[Am]Παίρνω την κιθάρα μου και τραγου[Em]δάω
Σας αγα[F]πάω, [G]μα δεν παντρεύο[C]μαι',NULL),
	 ('Ένα καράβι',119,NULL,0,NULL,'2026-10-29 09:00:09','2026-10-29 09:00:09','{title: Ένα καράβι}
{verse: Verse}
[Am]Ένα καράβι παλιό, σαπιοκάραβο με κάτι ναύτες τρε[G]λούς πειρα[Am]τές
Σηκώνει άγκυρα άγριο χάραμα, υπάρχουν [F]θέσεις, αν [Em]θέλεις, κε[Am]νές
[Am]Όταν βραδιάζει, που λες, στο κατάστρωμα χίλια φωτάκια θ'' α[G]νάβουν μι[Am]κρά
[Am]Στη συντροφιά μας θα έρχεται ο άνεμος να μας σφυ[F]ρίζει τρα[Em]γούδια πα[Am]λιά
 
{verse: Chorus}
[Am]Άντε να λύσουμε, να ξεκι[G]νήσουμε και τους βα[F]ρέθηκα, δεν τους μπο[E]ρώ
[Am]Να ξενυχτίσουμε και να με[G]θύσουμε, να τους ξε[F]χάσουμε [Em]όλους ε[Am]δώ
 
{verse: Verse}
[Am]Ένα καράβι παλιό, σαπιοκάραβο λύνει τους κάβους κι α[G]νοίγει πα[Am]νιά
[Am]Αφήνει πίσω στραβά και παράλογα, σηκώνει [F]άγκυρα [Em]για μακρι[Am]ά
[Am]Θα ξημερώνουμε πάνω στη θάλασσα θα βγαίνει ο ήλιος να [G]κάνει βου[Am]τιές
[Am]ο παπαγάλος θα λέει "τους ξεφύγαμε" κι εμείς θα [F]ψάχνουμε γι [Em]άλλες στε[Am]ριές
 
{verse: Chorus}
[Am]Άντε να λύσουμε, να ξεκι[G]νήσουμε και τους βα[F]ρέθηκα, δεν τους μπο[E]ρώ
[Am]Να ξενυχτίσουμε και να με[G]θύσουμε, να τους ξε[F]χάσουμε [Em]όλους ε[Am]δώ',NULL),
	 ('Άσε με να κάνω λάθος',119,NULL,0,NULL,'2026-10-29 09:12:08','2026-10-29 09:12:08','{title: Άσε με να κάνω λάθος}
{verse: Verse}
[Em]Άσε με να [B7]κάνω λάθος [C]μην μου λες πως [B7]είν'' ντροπή
[Em]άσε με να [B7]βρω μονάχος [C]ποιο το τέλος, [B7]ποια η αρχή
[F]Άσε με μονάχο μου να [Em]νιώσω [F]την ουσία μέσα σε όλα που ''χεις [Em]πει
[G]αν αντίρρηση μου φέρεις [D]θα θυμώσω και το ξέρεις
[C]αν με χάσεις αιτία θα ''σαι ε[Em]σύ [D] [Em]
 
{verse: Verse}
[Em]Άσε με να [B7]κάνω λάθος [C]άσε με να [B7]κουραστώ
[Em]άσε με να ''[B7]ρθω μονάχος [C]και συγγνώμη [B7]να σου πω
[F]Έχω μπόλικο καιρό να κοροϊ[Em]δεύω [F]κάθε λέξη κάθε έννοια και σκο[Em]πό
[G]Έχω όρεξη πολλή να αλη[D]τεύω [C]κι ας μην ξέρω για τι ψάχνω ή τι θα [Em]βρω [D] [Em]
 
{verse: Verse}
[Em]Mην μου λες για ε[B7]ξερευνήσεις, [C]και για χώρες [B7]μακρινές
[Em]μην μου λες για [B7]κατακτήσεις, [C]και για μαζι[B7]κές δομές
[F]πες μου μόνο πώς περνούν την νύκτα με δυο [Em]φίλους [F]σ'' ένα υπόγειο σκυ[Em]φτό
[G]η σειρήνα πάνω ουρλιάζει [D]και η σύριγγα αδειάζει
[C]και το αίμα χύνεται ζε[Em]στό [D] [Em]
 
{verse: Verse}
[Em]Άσε με να [B7]κάνω λάθος, [C]άσε με να [B7]δω καλά
[Em]άσε με να [B7]βρω μονάχος, [C]τι μου παίρνει [B7]τα μυαλά
[F]Άσε με να σου σφυρίξω στο σκο[Em]τάδι [F]ένα γνώριμο, παλιό σκο[Em]πό
[G]άσε με να σου γεμίσω κάποιο [D]βράδυ
[C]τα κενά με μουσική, ροκ εντ ρολ που συμπα[Em]θώ [D] [Em]
 
{verse: Verse}
[Em]Άσε με να [B7]κάνω λάθος, [C]μην παριστάνεις [B7]τον Θεό
[Em]δεν μ'' αρέσουν [B7]οι σωτήρες, [C]δεν γουστάρω [B7]να σωθώ
[F]δεν πειράζει αν μετά θα μετα[Em]νιώσω
[F]δεν τρέχει τίποτα αν διπλά θα κουρα[Em]στώ
[G]δεν με νοιάζει απογοήτευση αν [D]νιώσω
[C]αφού ξέρω πως έπαιξα και ''[Em]γω',NULL),
	 ('November rain',32,NULL,0,NULL,'2026-10-29 10:52:13','2026-10-29 10:52:13','{title: November rain}
{verse: Intro}
[F] [Am] [Dm] [C]
[F] [Dm] [C]
[F] [Am] [Dm] [C]
[F] [Dm] [C]
[F] [Dm] [C]
 
{verse: Verse}
[F]When I look into your [Dm]eyes
I can see a love re[C]strained
[F]But darling when I [Dm]hold you
Don''t you know I feel the [C]same
[Dm]''Cause nothin'' lasts for[G]ever
And we both know hearts can [C]change
[Dm]And it''s hard to hold a [G]candle
In the cold November [C]rain
 
{verse: Verse}
[F]We''ve been through this such a [Dm]long, long time
Just tryin'' to kill the [C]pain, oh yeah
But [F]lovers always come and lovers always go
And [Dm]no one''s really sure who''s lettin'' go [C]today, walkin'' away
If [F]we could take the time to lay it on the line
I could [Dm]rest my head
Just knowin'' that you were [C]mine, all mine
[Dm]So if you want to [G]love me
Then darlin'' don''t re[C]frain
[Dm]Or I''ll just end up [G]walkin''
In the cold November [C]rain
 
{verse: Chorus}
Do you [F]need some time on your [G]own?
Do you [F]need some time all a[G]lone?
Everybody [F]needs some time on their [G]own
Don''t you know you [F]need some time all a[G]lone
 
{verse: Bridge}
[Em]I know it''s [F]hard to keep an [C]open heart
[Em]When even [F]friends seem out to [Dm]harm you
[Em]But if [F]you could heal a [C]broken heart
[Em]Wouldn''t [F]time be out to [G]charm you
 
{verse: Solo}
[F] [Dm] [C] [C]
[F] [Dm] [C] [C]
[Dm] [G] [C] [C]
[Dm] [G] [C] [C]
 
{verse: Chorus}
Sometimes I [F]need some time on my [G]own
Sometimes I [F]need some time all a[G]lone
Everybody [F]needs some time on their [G]own
Don''t you know you [F]need some time all a[G]lone
 
{verse: Solo}
[F] [Dm] [C] [C]
 
{verse: Verse}
[F]And when your fears sub[Dm]side
And shadows still re[C]main, oh yeah
[F]I know that you can [Dm]love me
When there''s no one left to [C]blame
[Dm]So never mind the [G]darkness
We still can find a [C]way
[Dm]''Cause nothin'' lasts for[G]ever
Even cold November [C]rain',NULL),
	 ('Where did you sleep last night',3,NULL,0,NULL,'2026-10-29 11:22:53','2026-10-30 14:50:04','{title: Where did you sleep last night}
{verse: Intro}
[D] [E] [F] [D] [G] [F] [A] [D]
 
{verse: Verse}
[D]My girl, my girl, don''t [G]ie to [F]me
Tell me [A]where did you sleep last [D]night
[D]In the pines, in the pines
Where the [G]sun don''t ever [F]shine
I would [A]shiver the whole night [D]through
 
{verse: Verse}
[D]My girl, my girl, where [G]will you [F]go
I''m [A]going where the cold wind [D]blows
[D]In the pines, in the pines
Where the [G]sun don''t ever [F]shine
I would [A]shiver the whole night [D]through
[D]Her husband, was a hard [G]working [F]man
Just [A]about a mile from [D]here
[D]His head was found in a [G]driving [F]wheel
But his [A]body never was [D]found
 
{verse: Verse}
[D]My girl, my girl, don''t [G]ie to [F]me
Tell me [A]where did you sleep last [D]night
[D]In the pines, in the pines
Where the [G]sun don''t ever [F]shine
I would [A]shiver the whole night [D]through
 
{verse: Interlude}
[D] [G] [F] [A]      [D]
 
{verse: Verse}
[D]My girl, my girl, don''t [G]ie to [F]me
Tell me [A]where did you sleep last [D]night
[D]In the pines, in the pines
Where the [G]sun don''t ever [F]shine
I would [A]shiver the whole night [D]through',NULL),
	 ('Η πρώτη μας νύχτα',120,NULL,0,NULL,'2026-10-29 11:53:05','2026-10-29 12:02:42','{title: Η πρώτη μας νύχτα}
{verse: Verse}
Η [G]πρώτη μας νύχτα, [C]αργά θα κυ[G]λήσει
εσύ τ'' όνει[D]ρό μου και [C]γύρω η σιω[G]πή
Ποιος [G]θα'' χει το θάρρος [C]να πρωτομι[G]λήσει
την πρώτη τη [D]λέξη ποιος τάχα θα [G]πει
 
{verse: Chorus}
Μα αν [Em]γίνουν τα μάτια αγάπης κα[C]θρέφτης
και [D]το μυστικό μας στα χείλη μας [G]βγει
Θα [G]πούνε τ'' αστέρια [C]πως πήγε ένας [G]κλέφτης
και πήρε ένα α[D]στέρι και το'' χει [G]στη γη',NULL),
	 ('Ασφαλώς και δεν πρέπει',45,NULL,0,NULL,'2026-10-29 12:13:43','2026-10-29 12:13:43','{title: Ασφαλώς και δεν πρέπει}
{verse: Verse}
Ασφα[F]λώς και δεν [C]πρέπει
[E]Να μας δούνε πα[Am]ρέα
[G]Επεράσαμε ω[C]ραία
[Dm]Λίγες ώρες μα[G]ζί
 
{verse: Chorus}
[Em]Είν'' η πρώτη μας [Am]νύχτα
[Am]Πρώτη και τελευ[G]ταία
[Em]Ασφαλώς και δεν πρέπει
[E]Να μας δούνε πα[Am]ρέα
 
{verse: Verse}
Ασφα[F]λώς και το [C]ξέρω
[E]Πως δεν είμαστε [Am]ίδια
[G]Μοναχά στα παι[C]χνίδια
[Dm]Είμαστ'' όλοι παι[G]διά
 
{verse: Chorus}
[Em]Κι αν εσύ το ξε[Am]χάσεις
[Am]Η ζωή στο θυ[G]μίζει
[Em]Και πεθαίνει η αγάπη
[E]Και σωπαίνει η καρ[Am]διά
 
{verse: Verse}
Είμαι ε[F]κείνος που [C]είμαι
[E]Κι έχεις όνομα [Am]κάποιο
[G]Σε χρυσό κόσμο [C]σάπιο
[Dm]Δε χωράω να [G]μπω
 
{verse: Chorus}
[Em]Κάνε εκείνο που [Am]πρέπει
[Am]Όλα τα επι[G]τρέπει
[Em]Το δικό σου το πρέπει
[E]Ένα πρέπει [Am]θαμπό',NULL),
	 ('Κλαίει απόψε η γειτονιά',15,NULL,0,NULL,'2026-10-29 12:27:30','2026-10-29 12:27:30','{title: Κλαίει απόψε η γειτονιά}
{verse: Verse}
[Em]Όλη η ζωή μου [Am]δίχως νόη[Em]μα
[Dm]ξαδέρφη του, ξαδέρφη του θανά[Em]του
[Em]Ας ήταν και να [F]πέθαινα ξη[G]μέρωμα Σαβ[Em]βάτο

{verse: Solo}
[Em] [Am]
 
{verse: Chorus}
[Am]Κλαίει απόψε η [G]γειτονιά [Dm]μαζί με την καρ[Em]διά [G]μου
[Am]Πού είσαι αγάπη [G]μου γλυκιά, [Dm]να δεις τα δάκρυ[Em]ά μου

{verse: Solo}
[Em] [Am]
 
{verse: Verse}
[Em]Όλη η ζωή μου [Am]δίχως νόη[Em]μα
[Dm]μία ψευτιά, μία ψευτιά μεγά[Em]λη
[Em]και το δικό σου [F]βάσανο να [G]δω πού θα με [Em]βγάλει
 
{verse: Solo}
[Em] [Am]

{verse: Chorus}
[Am]Κλαίει απόψε η [G]γειτονιά [Dm]μαζί με την καρ[Em]διά [G]μου
[Am]Πού είσαι αγάπη [G]μου γλυκιά, [Dm]να δεις τα δάκρυ[Em]ά μου',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Μουπες θα φύγω',2,NULL,0,NULL,'2026-11-03 07:08:34','2026-11-03 07:52:54','{title: Μουπες θα φύγω}
{verse: Verse}
[Am]Μου ''πες θα φύγω χθες το [F]βράδυ ξαφνικά
[Am]Απλώς κουράστηκα δε [F]φταίω για όλα αυτά
[Am]Θεέ μου δε θέλει το [F]βλέπω καθαρά
Κι όλα [E]γίναν Θεέ μου τόσο [F]μα τόσο ξαφνι[Am]κά
 
{verse: Verse}
[Am]Σηκώθηκα μο[F]νάχος το πρωί
[Am]Χωρίς καφέ χωρίς τσι[F]γάρο και ψυχή
[Am]Θεέ μου το ξέρω τώρα [F]είμαι μοναχός
Κι όμως [E]θα γυρίσει πάλι [F]δεν μπορεί να κάνει αλ[Am]λιώς
 
{verse: Verse}
[Am]Το ξέρω είναι λίγο [F]δύσκολο μα εγώ
[Am]Στο λέω μπορούσα να περι[F]μένω και μπορώ
[Am]Βλέπεις οι δυο μας μόνοι δε [F]νιώσαμε ποτέ
Τώρα, [E]τώρα πες μου ποιόν
[F]Πες μου ποιόν θα ''χεις να τα [Am]λες;',NULL),
	 ('Του βοτανικού ο μάγκας',40,NULL,0,NULL,'2026-10-29 14:39:34','2026-10-30 09:43:15','{title: Του βοτανικού ο μάγκας}
{verse: Intro}
[Em] [G]
[Em] [G]
[Am] [B7] [Em]
[Am] [B7] [Em]

{verse: Verse}
[Em]Του Βοτανικού ο μάγκας πέθανε την Κυριακή
[Em]και τον κλάψαν οι κοπέλες κι όλοι οι φίλοι καρδιακοί
 
{verse: Chorus}
[G]Του Βοτανικού το μάγκα, το καλύτερο παιδί
[Am]στα μπουζούκια, στις ταβέρνες, πια κα[B7]νείς δεν θα τον [Em]δει
[Am]στα μπουζούκια, στις ταβέρνες, πια κα[B7]νείς δεν θα τον [Em]δει

{verse: Interlude}
[Em] [G]
[Em] [G]
[Am] [B7] [Em]
[Am] [B7] [Em]

{verse: Verse}
[Em]Πάντα όμορφα γλεντούσε και δεν έκανε κακό
[Em]και τον αγαπούσαν όλοι μέσα στο Βοτανικό
 
{verse: Chorus}
[G]Του Βοτανικού το μάγκα, το καλύτερο παιδί
[Am]στα μπουζούκια, στις ταβέρνες, πια κα[B7]νείς δεν θα τον [Em]δει
[Am]στα μπουζούκια, στις ταβέρνες, πια κα[B7]νείς δεν θα τον [Em]δει

{verse: Interlude}
[Em] [G]
[Em] [G]
[Am] [B7] [Em]
[Am] [B7] [Em]

{verse: Verse}
[Em]Του Βοτανικού ο μάγκας είχε ωραίο παρελθόν
[Em]Απ'' τα γλέντια κι απ'' τους μάγκες θα ''ναι τώρα πια απών
 
{verse: Chorus}
[G]Του Βοτανικού το μάγκα, το καλύτερο παιδί
[Am]στα μπουζούκια, στις ταβέρνες, πια κα[B7]νείς δεν θα τον [Em]δει
[Am]στα μπουζούκια, στις ταβέρνες, πια κα[B7]νείς δεν θα τον [Em]δει',NULL),
	 ('Ο Μπάμπης ο φλου',2,NULL,0,NULL,'2026-10-29 15:05:15','2026-10-29 15:05:15','{title: Ο Μπάμπης ο φλου}
{verse: Verse}
[Am]Μια ιστορία θα σας πω για το [G]Μπάμπη το [E]Μπάμπη τον [Am]φλου
[Am]που του ''λεγες βρε Μπάμπη τι τρέχει εδώ
σου ''λεγε [G]φλου, φίλε μου [E]όλα είναι [Am]φλου
 
{verse: Verse}
[Am]Πάντα πιωμένος κι άνεργος
ήταν [G]ωραίος ο [E]Μπάμπης ο [Am]φλου
[Am]Μουρμούραγε μόνος και διαρκώς
σου ''λεγε [G]φλου φίλε μου [E]όλα είναι [Am]φλου
 
{verse: Chorus}
[D]Πείραζε όποιον του ''[Am]ρχότανε
[D]χωρίς να το σκε[Am]φτεί
κι [D]άμα ψιλοβα[Am]ριότανε
άραζε ό[G]που ''βρι[E]σκε να λια[Am]στεί
 
{verse: Verse}
[Am]Πείραζε τις μελαχρινές
ήταν ω[G]ραίος ο [E]Μπάμπης ο [Am]φλου
[Am]Τσιμπολογούσε τις ξανθιές
ήταν ω[G]ραίος ο [E]Μπάμπης ο [Am]φλου
 
{verse: Verse}
[Am]Κι όταν τον μπουζουριάζανε
ψόφιος κο[G]ριός ο [E]Μπάμπης ο [Am]φλου
[Am]κι αν τον πολυρωτάγανε
σου ''λεγε [G]φλου, φίλε μου [E]όλα είναι [Am]φλου
 
{verse: Chorus}
[D]Πείραζε όποιον του ''[Am]ρχότανε
[D]χωρίς να το σκε[Am]φτεί
κι [D]άμα ψιλοβα[Am]ριότανε
άραζε ό[G]που ''βρι[E]σκε να λια[Am]στεί',NULL),
	 ('Ξημερώνει',68,NULL,0,NULL,'2026-10-31 19:31:14','2026-10-31 19:31:14','{title: Ξημερώνει}
{verse: Verse}
[Em]Ξημερώνει, κι ε[F]γώ στους δρόμους τριγυρ[Em]νώ
Κι αν χα[F]ράζει, το [Dm]φως δε φτάνει ε[Em]δώ
[Em]Πού να είσαι, ποια [F]χέρια σε κοι[Dm]μίζου[Em]νε
Ποια τρα[F]γούδια σε [Dm]νανουρίζου[Em]νε
 
{verse: Chorus}
Μια καρ[C]διά έχω μόνο, μια καρδιά, [D] [G] [Am] [Em]ααα...
Που για [C]σένα κλαίει κάθε βραδιά, [D] [G] [Am] [Em]ααα...
 
{verse: Verse}
[Em]Ξημερώνει, κι ε[F]γώ στους δρόμους τριγυρ[Em]νώ
Κι αν χα[F]ράζει, το [Dm]φως δε φτάνει ε[Em]δώ
[Em]Ξημερώνει, στου [F]κόσμου όλου τις καρ[Em]διές
Μα για [F]μένα δε [Dm]χάραξε πο[Em]τές
 
{verse: Chorus}
Μια καρ[C]διά έχω μόνο, μια καρδιά, [D] [G] [Am] [Em]ααα...
Που για [C]σένα κλαίει κάθε βραδιά, [D] [G] [Am] [Em]ααα...

{verse: Outro}
[Em]Σε φωνάζω και [F]να μ'' ακούσεις δε μπο[Em]ρείς
Ξημε[F]ρώνει, και [Dm]συ δε λες να ''[Em]ρθεις',NULL),
	 ('Έμεινα εδώ',121,NULL,0,NULL,'2026-11-02 07:52:47','2026-11-02 07:52:47','{title: Έμεινα εδώ}
{verse: Verse}
[G]Κάποιο βράδυ σου ''χα πει πως [C]θέλω να γυρίσω όλο τον [Em]κόσμο, όλο τον [D]κόσμο
[G]Και συ μου γέλασες γλυκά και [C]μου ''πες πως το φιλί μου μυρίζει [Em]δυόσμο, μυρίζει [D]δυόσμο
[C]Κάποιο βράδυ σου'' χα πει, πως [D]θέλω να πετάξω σαν που[Em]λί, πάνω απ'' τον [D]κόσμο
[C]Και συ ζωγράφισες φτερά σ'' έ[D]να λευκό χαρτί και μου ''πες [Em]φως μου, μη φύγεις [D]φως μου
 
{verse: Chorus}
Κι έμεινα ε[Em]δώ να [D]μη σου λείψει [C]τίποτα
έμεινα ε[Em]δώ να [D]μη φοβη[C]θείς
Να μη μείνεις [Em]μόνη [D]σου και ''γω στο [C]τίποτα
έμεινα ε[Em]δώ να [D]μη μαρα[C]θείς
 
{verse: Verse}
[G]Κάποιο βράδυ μου ''χες πει πως [C]πρέπει να γεννήθηκα για [Em]σένα, μόνο για [D]σένα
[G]Και ''γω σε πήρα αγκαλιά και [C]χάθηκα στα μάτια σου τα μαγε[Em]μένα, τα μαγε[D]μένα
[C]Κάποιο βράδυ μου ''χες πει πως [D]δε μπορείς να ζήσεις μια στιγ[Em]μή, χωρίς ε[D]μένα
[C]Και ''γω δε μίλησα ξανά για[D]τί στα χέρια μου είχα ε[Em]σένα μόνο ε[D]σένα
 
{verse: Chorus}
Κι έμεινα ε[Em]δώ να [D]μη σου λείψει [C]τίποτα
έμεινα ε[Em]δώ να [D]μη φοβη[C]θείς
Να μη μείνεις [Em]μόνη [D]σου και ''γω στο [C]τίποτα
έμεινα ε[Em]δώ να [D]μη μαρα[C]θείς',NULL),
	 ('Για να σε εκδικηθώ',15,NULL,0,NULL,'2026-11-03 07:13:20','2026-11-03 07:13:20','{title: Για να σε εκδικηθώ}
{verse: Verse}
Για να σε εκ[C]δικηθώ
σου σκίζω τις φωτογραφίες
κι εσύ [Am]όπως και εγώ
κομμάτια στις γωνιές και στις πλατείες
τα γράμματά σου [Dm]καίω
μέσα στον πυρετό μου
και σβήνω το όνο[G]μά σου
μαζί με το δικό μου
 
{verse: Verse}
Για να σε εκ[C]δικηθώ
πετάω ενθύμια και δώρα
κι εσύ ό[Am]πως και εγώ
θρύψαλα και σκουπίδια τώρα
τις ζωγραφιές σου [Dm]σκίζω
[G]τα πόστερ που [C]αγαπούσες [Am]
και βάφω τις κουρ[Dm]τίνες
[G]στο χρώμα που [C]μισούσες
 
{verse: Chorus}
Για να για[C]τρέψω τις ατέλειωτες πλη[Am]γές
αφού δεν [Dm]βγήκες από μέσα μου πο[G]τέ',NULL),
	 ('Το καλοκαιράκι',123,NULL,0,NULL,'2026-11-02 08:10:36','2026-11-02 08:10:36','{title: Το καλοκαιράκι}
{verse: Verse}
[G]Το καλοκαι[D]ράκι
[Em]στη ακρογια[C]λιά
[G]μέσα στο νε[D]ράκι
[Em]πλέουμ'' αγκα[C]λιά
[G]Πέφτει το βρα[D]δάκι
[Em]πιάνει η δρο[C]σιά
[G]δως μου ένα φι[D]λάκι
κι [Em]έλα πιο κο[C]ντά
 
{verse: Chorus}
Ε[G]γώ κι εσύ, εσύ κι εγώ
[D]μόνοι πάνω στη γη
[G]Οοοοο [D]... [G]μόνοι στη γη [D]
 
{verse: Verse}
[G]Ήταν η Α[D]θήνα
[Em]κόμπος στο λαι[C]μό
[G]νέφος και ρου[D]τίνα
και [Em]άγχος τρομε[C]ρό
[G]Δως μου ένα τσι[D]γάρο
[Em]δως μου και φω[C]τιά
[G]Θε μου θα σε [D]πάρω
στην καυ[Em]τή την αμμου[C]διά
 
{verse: Chorus}
Ε[G]γώ κι εσύ, εσύ κι εγώ
[D]μόνοι πάνω στη γη
[G]Οοοοο [D]... [G]μόνοι στη γη [D]
 
{verse: Verse}
[G]Τηλέφωνο χτυ[D]πάει
[Em]βουλιάζει το νη[C]σί
[G]και τ'' όνειρο σκορ[D]πάει
στου γρα[Em]φείου τη βου[C]ή
[G]Πετάγομαι ιδρω[D]μένος
[Em]δουλεύεις και γε[C]λάς
[G]σ'' ακούω σαν χα[D]μένος
το ρε[Em]φραίν να τραγου[C]δάς
 
{verse: Chorus}
Ε[G]γώ κι εσύ, εσύ κι εγώ
[D]μόνοι πάνω στη γη
[G]Οοοοο [D]... [G]μόνοι στη γη [D]',NULL),
	 ('Της καληνύχτας τα φιλιά',124,NULL,0,NULL,'2026-11-02 08:54:24','2026-11-02 10:03:27','{title: Της καληνύχτας τα φιλιά}
{verse: Verse}
[G]Εδώ να [C]μείνεις
Να με κρατήσεις αγκα[D]λιά,  να μ'' α[G]νακρίνεις
[G]Της καλη[C]νύχτας τα φι[D]λιά τι μου [G]τα δίνεις
δεν φεύγω [Am]απόψε κι από τ'' αμάξι δεν [G]θα βγω
κι αν έχεις [Am]τίποτα μαζί μου να συ[G]γκρίνεις
εδώ να [Em]μείνεις να το [D]μάθουμε κι οι [G]δυο
 
{verse: Chorus}
Εδώ να [Am]μείνεις, εδώ [G]να μείνεις
της καλη[Am]νύχτας τα φι[D]λιά τι μου [G]τα δίνεις
 
{verse: Verse}
[G]Εδώ και [C]τώρα
γιατί είν'' ο δρόμος μας πα[D]λιός και κατη[G]φόρα
[G]της καλη[C]νύχτας τα φι[D]λιά δεν είναι [G]δώρα
δεν φεύγω [Am]απόψε κι απ'' τη ζωή σου δε θα [G]βγω
κι αν είναι [Am]σχέση μας μισή, τα λόγια [G]φόρα
εδώ και [Em]τώρα στης α[D]γάπης το θυ[G]μό
 
{verse: Chorus}
Εδώ να [Am]μείνεις, εδώ [G]να μείνεις
της καλη[Am]νύχτας τα φι[D]λιά τι μου [G]τα δίνεις',NULL),
	 ('Το κόκκινο φουστάνι',124,NULL,0,NULL,'2026-11-02 10:12:57','2026-11-02 10:12:57','{title: Το κόκκινο φουστάνι}
{verse: Verse}
[Em]Η νύχτα κατεβαίνει [Am]με μαύρο φερε[Em]τζέ          ] 2x
[Am]κι η πόλη διψασμένη [Dm]για φώτα και σου[Em]ξέ       ] 2x
 
{verse: Chorus}
[Em]Βάλε το κόκκι[Dm]νο φου[Em]στάνι
εκείνο που σε [Am]κάνει [F]να μοιάζεις πυρκα[Em]γιά
[Em]Έλα και μη με[Dm]τράς την [Em]ώρα
τα νιάτα είναι [Am]μπόρα [F]που καίνε σαν φω[Em]τιά [Am]
[Dm]που καίνε σαν [Em]φωτιά
 
{verse: Verse}
[Em]Τι να μάς περιμένει [Am]αύριο το πρω[Em]ί            ] 2x
[Am]ποιος έρωτας πεθαίνει [Dm]και ποιος θα γεννη[Em]θεί  ] 2x
 
{verse: Chorus}
[Em]Βάλε το κόκκι[Dm]νο φου[Em]στάνι
εκείνο που σε [Am]κάνει [F]να μοιάζεις πυρκα[Em]γιά
[Em]Έλα και μη με[Dm]τράς την [Em]ώρα
τα νιάτα είναι [Am]μπόρα [F]που καίνε σαν φω[Em]τιά [Am]
[Dm]που καίνε σαν [Em]φωτιά',NULL),
	 ('Θάλασσες',13,NULL,0,NULL,'2026-11-02 11:20:57','2026-11-02 11:20:57','{title: Θάλασσες}
{verse: Verse}
[Am]Θάλασσες, [Em][G][Am]θάλασσες, τα προβλήματα μας [G]λιώνουν, [Em]θάλασσες[Em] [G] [Em]
[Em]Θάλασσες, τα βρώμικα του [F]κόσμου, θάλασσες ωω [Am]θάλασσες[Em] [G] [Am]
 
{verse: Verse}
[Am]Θάλασσες, [Em][G][Am]θάλασσες, τα ατέλειωτα μας [G]λάθη, [Em]θάλασσες[Em] [G] [Em]
[Em]θάλασσες, τα μικρά μας [F]πάθη, θάλασσες
[F]Θάλασσες, κι οι πίκρες που μου ''δωσαν οι [Am]φίλοι μου
 
{verse: Chorus}
[Am]Θάλασσες, μας χτυπούν και είμαστε μο[G]νάχοι
[G]Κρίνουμε των αλλονών τα [Am]λάθη
[Am]Μείνανε στη μέση τα όνει[G]ρα μας
[G]Μια στιγμή κρατάει η χα[F]ρά μας
[F]Μια στιγμή κρατάει [Em]η [G]χα[Am]ρά μας
 
{verse: Chorus}
[Am]Θάλασσες, ψέματα πουλάνε όπως κι [G]όπως
[G]Βρίζουμε, μας βρίζουν κι αντι[Am]στρόφως
[Am]Μείνανε στη μέση τα όνει[G]ρα μας
[G]Σκάλωσε η ζωή στη πονη[F]ριά μας,
[F]Σκάλωσε η ζωή στη [Em]πο[G]νη[Am]ριά μας,
Θάλασσες
 
{verse: Verse}
[Am]Θάλασσες οι μέρες που ''χω χάσει, [Em]θάλασσες
[Em]Θάλασσες οι νύχτες που ''χω [F]κλάψει, [Am]θάλασσες
[F]Θάλασσες τα παράπονα που έχω από [Am]σένανε',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Everybody hurts',84,NULL,0,NULL,'2026-11-02 11:31:28','2026-11-02 12:54:08','{title: Everybody hurts}
{verse: Verse}
[D]When your day is [G]long
and the [D]night
the night is yours a[G]lone
[D]When you''re sure you had e[G]nough
of this [D]life
Well, hang [G]on [D] [Em]
 
{verse: Chorus}
Don''t let yourself [A]go [Em]
cause everybody [A]cries [Em]
and everybody [A]hurts
 
{verse: Verse}
Some[D]times [G]
Sometimes everything is [D]wrong [G]
Now it''s time to sing a[D]long
When your day is night a[G]lone [D]
If you feel like letting [G]go [D]
If you think you had
too [G]much
of this [D]life
Well, hang [G]on [D] [Em]
 
{verse: Chorus}
Cause everybody [A]hurts [Em]
Take comfort in your [A]friends [Em]
Everybody [A]hurts [F#]
 
{verse: Break}
Don''t throw your [Bm]hand
[F#]Whoa [Bm]now
[F#]Don''t throw your [Bm]hand [C]
If you feel like you''re a[G]lone
[C]No no no, you''re not a[Am]lone [D]
 
{verse: Verse}
If you''re on your own [G]
in this [D]life
The days and nights are [G]long [D]
When you think you''ve had too [G]much
of this [D]life
to hang [G]on [D] [Em]
 
{verse: Chorus}
Well, everybody [A]hurts
Some[Em]times
Everybody [A]cries [Em]
and everybody [A]hurts
Some[D]times [G]',NULL),
	 ('Με λένε Γιώργο',125,NULL,0,NULL,'2026-11-03 08:36:06','2026-11-03 08:36:06','{title: Με λένε Γιώργο}
{verse: Verse}
[Am]Με λένε [G]Γιώργο και πο[C]τέ δεν τραγου[E]δάω
[Dm]Για της α[Am]γάπης τον γλυ[Dm]κό πι[E]κρό καη[Am]μό
[C]Δεν έχω [G]μάθει μαργα[Em]ρίτες να μα[Am]δάω   | 2x
[F]Δεν περι[Em]μένω κανε[F]νός το [E]γυρι[Am]σμό     | 2x
[Am]Με λένε [G]Γιώργο και πο[C]τέ δεν τραγου[E]δάω
[Dm]Για της α[Am]γάπης τον γλυ[Dm]κό πι[E]κρό καη[Am]μό
 
{verse: Verse}
[Am]Με λένε [G]Γιώργο και πο[C]τέ δεν τραγου[E]δάω
[Dm]Θα υπο[Am]φέρω στη ζω[Dm]ή κά[E]θε στι[Am]γμή
[C]Γιατί δεν [G]έκανα ό,τι [Em]θα ''πρεπε να [Am]κάνω   | x2
[F]Γιατί σαν [Em]άνθρωπος δεν [F]είχα [E]τη πυγ[Am]μή     | x2
[Am]Με λένε [G]Γιώργο και πο[C]τέ δεν τραγου[E]δάω
[Dm]Θα υπο[Am]φέρω στη ζω[Dm]ή κά[E]θε στι[Am]γμή
 
{verse: Verse}
[Am]Με λένε [G]Γιώργο και πο[C]τέ δεν τραγου[E]δάω
[Dm]Θα υπο[Am]φέρω στη ζω[Dm]ή κά[E]θε στι[Am]γμή
[Am]Με λένε [G]Γιώργο, [Am] οοοοο   | 2x',NULL),
	 ('Με ένα παράπονο',40,NULL,0,NULL,'2026-11-03 08:43:57','2026-11-03 08:43:57','{title: Με ένα παράπονο}
{verse: Verse}
[E]Ήθελα [F]κάτι να σου [E]πω
[E]και στο τρα[F]πέζι σου να [E]ρθώ
[Am]μ'' ένα πα[Dm]ράπονο μ'' ένα παράπονο πι[E]κρό
[C]να σε κα[E]λησπερί[Am]σω
[G]μ'' ένα πα[C]ράπο[E]νο, [Am]   μ'' ένα πα[Dm]ράπονο πι[E]κρό
[C]να σε κα[E]λησπερί[Am]σω
 
{verse: Verse}
[E]Έχεις α[F]φήσει μια ψυ[E]χή
[E]στην παγω[F]νιά και στην βρο[E]χή
[Am]μ'' ένα πα[Dm]ράπονο μ'' ένα παράπονο πι[E]κρό
[C]θα στο ξα[E]ναθυμί[Am]σω
[G]μ'' ένα πα[C]ράπο[E]νο, [Am]   μ'' ένα πα[Dm]ράπονο πι[E]κρό
[C]θα στο ξα[E]ναθυμί[Am]σω

{verse: Verse}
[E]Αν είσαι [F]άντρας με καρ[E]διά
[E]φερ'' την μα[F]ζί σου μια βρα[E]διά
[Am]μ'' ένα χα[Dm]μόγελο, μ'' ένα χαμόγελο ζε[E]στό
[C]θα σε κα[E]λωσορί[Am]σω
[G]μ'' ένα χα[C]μόγε[E]λο, [Am]   μ'' ένα χα[Dm]μόγελο ζε[E]στό
[C]θα σε κα[E]λωσορί[Am]σω',NULL),
	 ('Φίλα με',126,NULL,0,NULL,'2026-11-03 08:56:48','2026-11-03 13:03:52','{title: Φίλα με}
{verse: Verse}
Τι πιο [Am]όμορφο σ'' αυ[G]τή τη ζω[Am]ή
Απ'' την [C]λάμψη των δι[G]κών σου μα[Am]τιών
Τι πιο [Am]όμορφο και [G]πιο λαμπε[Am]ρό
Σ'' έναν [Em]κόσμο που φο[G]βάται το [Am]φως
 
{verse: Verse}
Τι πιο [Am]όμορφο και [G]πιο μαγι[Am]κό
Απ'' το [C]πάθος των γλυ[G]κών σου φι[Am]λιών
Την α[Am]νάσα σου όταν [G]νοιώθω καυ[Am]τή
Στην φω[Em]τιά της μα[G]θαίνω να [Am]ζω
 
{verse: Chorus}
[Dm]Φίλα με [G]πάλι φίλα με [C]αγκά[Am]λιασε με
[Dm]Μες στο κορ[G]μί σου να κρυ[Em]φτώ
[Dm]Φίλα με [G]πάλι φίλα με [C]ξημέρω[Am]σέ με
[Dm]Σ'' ένα [G]ταξίδι ερωτι[Am]κό
 
{verse: Verse}
[Am]Με το γέλιο σου [G]νοιώθω πως [Am]ζω
Με το [C]δάκρυ σου [G]νοιώθω πως [Am]χάνομαι
Τι πιο [Am]όμορφο και [G]πιο ζωντα[Am]νό
Απ'' αυ[Em]τό που για [G]σένα αι[Am]σθάνομαι
 
{verse: Verse}
[Am]Η αλήθεια και το [G]ψέμα ε[Am]σύ
Κι όλα τα [C]άλλα στον [G]κόσμο κο[Am]μμάτια
[Am]Τι πιο όμορφο [G]πάνω στη [Am]γη
Απ'' τα δι[Em]κά μας α[G]τέλειωτα [Am]βράδια
 
{verse: Chorus}
[Dm]Φίλα με [G]πάλι φίλα με [C]αγκά[Am]λιασε με
[Dm]Μες στο κορ[G]μί σου να κρυ[Em]φτώ
[Dm]Φίλα με [G]πάλι φίλα με [C]ξημέρω[Am]σέ με
[Dm]Σ'' ένα [G]ταξίδι ερωτι[Am]κό',NULL),
	 ('Μα που να πάω',127,NULL,0,NULL,'2026-11-03 09:12:06','2026-11-04 07:25:48','{title: Μα που να πάω}
{verse: Verse}
[Am]Σ'' ένα δωμάτιο σκοτεινό
έψαχνα να ονειρευ[Em]τώ κά[Dm]τι δικό μου
[G]Είχα τα μάτια μου κλειστά
πάλευα μέσα στη φω[Dm]τιά τον [F]εαυτό μου
 
{verse: Verse}
[Am]Μα έγιν'' η σκέψη φυλακή
γίναν χιλιάδες τα για[Em]τί μες [Dm]το μυαλό μου
[G]Κι είπα να φύγω, να σω[Dm]θώ
να κάνω κάτι πια και [F]γω για το κα[G]λό μου
 
{verse: Chorus}
[Am]Είπα να [Em]φύγω, [G]ν'' αλλά[F]ξω δρό[E]μο στην καρ[Am]διά
είπα να [Em]φύγω, [G]να μην πο[F]νάω [E]άλλο [Am]πια
Μα που να [F]πάω, [G]που σ'' α[F]γαπώ [E]τόσο πο[Am]λύ
Μα που να [F]πάω, [G]αφού είσαι [F]όλη [E]μου η ζω[Am]ή
 
{verse: Verse}
[Am]Σε μια παραίσθηση τρελή
έψαχνα λόγο κι αφορ[Em]μή στον [Dm]πανικό μου
[G]Να βρω τον τρόπο να σου πω
πως έπαψα να αγα[Dm]πώ τον [F]εαυτό μου
 
{verse: Verse}
[Am]Μα εσύ δεν ήσουνα εκεί
μιλούσα μόνος στη σιω[Em]πή με [Dm]τον καημό μου
[G]Κι είπα να φύγω να σω[Dm]θώ
να κάνω κάτι πια και [F]γω για το κα[G]λό μου

{verse: Chorus}
[Am]Είπα να [Em]φύγω, [G]ν'' αλλά[F]ξω δρό[E]μο στην καρ[Am]διά
είπα να [Em]φύγω, [G]να μην πο[F]νάω [E]άλλο [Am]πια
Μα που να [F]πάω, [G]που σ'' α[F]γαπώ [E]τόσο πο[Am]λύ
Μα που να [F]πάω, [G]αφού είσαι [F]όλη [E]μου η ζω[Am]ή',NULL),
	 ('Πονάμε όσοι αγαπάμε',127,NULL,0,NULL,'2026-11-03 09:17:20','2026-11-03 09:17:20','{title: Πονάμε όσοι αγαπάμε}
{verse: Verse}
[C]Είν'' η αγάπη ένας σταθμός
κάθε φιλί κι ένας καημός
[F]Και ''κει που λες να η χαρά
σου κόβει η πίκρα τα φτερά

{verse: Chorus}
[G] [C]Πονάμε όσοι αγα[Am]πάμε
Γιατί η [F]χαρά μες στη ζω[G]ή, είν'' α[C]κριβή
 
{verse: Verse}
[C]Εκεί που ανθίζει η ζωή
πέφτει μια μπόρα στη ψυχή
[F]Και εκεί που είναι όμορφη η βραδιά
γεμίζει δάκρυα η καρδιά
 
{verse: Chorus}
[G] [C]Πονάμε όσοι αγα[Am]πάμε
Γιατί η [F]χαρά μες στη ζω[G]ή, είν'' α[C]κριβή
 
{verse: Verse}
[C]Έτσι είναι πάντα η αγάπη
Ζει μοναχά με το δάκρυ
[F]Κι όλοι εμείς που αγαπάμε
το μάθαμε πια να πονάμε
 
{verse: Chorus}
[G] [C]Πονάμε όσοι αγα[Am]πάμε
Γιατί η [F]χαρά μες στη ζω[G]ή, είν'' α[C]κριβή',NULL),
	 ('Η νύχτα μυρίζει γιασεμί',127,NULL,0,NULL,'2026-11-03 09:21:30','2026-11-03 09:21:30','{title: Η νύχτα μυρίζει γιασεμί}
{verse: Verse}
[Am]Ένας κόσμος τραγούδια ένα δάσος σ'' αγαπώ
μες τα [F]μάτια σου παίζουνε κρυ[C]φτό
Έχεις [F]μπει στη ζωή μου την καρ[C]διά μου να πονάς
κι απ'' το [Dm]γέλιο στο δάκρυ με γυρ[Am]νάς
 
{verse: Verse}
[Am]Να σε πάρω δικιά μου μ'' έναν έρωτα τρελό
φουρτου[F]νιάζει κι απόψε το μυα[C]λό
το φε[F]γγάρι αλήτης σου χαϊ[C]δεύει το κορμί
και η [Dm]νύχτα μυρίζει γιασε[Am]μί

{verse: Chorus}
[C]Τώ[G]ρα τι να σου [C]πω, [F]φταί[C]ω που σ'' αγαπώ
[F]τ'' ά[C]στρα χίλιοι καημοί κι [Dm]νύχτα μυρίζει γιασε[Am]μί
 
{verse: Verse}
[Am]Ταξιδεύω μαζί σου κι είναι οι σκέψεις μου κρυφές
μα τα[F]ξίδι δεν κάναμε πο[C]τές
Να σε [F]κάνω δικιά μου σε φω[C]νάζω τις βραδιές
μα δεν [Dm]ήρθες και σήμερα και [Am]χθες
 
{verse: Verse}
[Am]Είμαι μόνος κι απόψε μέσα σ'' όνειρα φωτιά
η αγκα[F]λιά σου για μένα ξενι[C]τιά
το φε[F]γγάρι αλήτης σου χαϊ[C]δεύει το κορμί
και η [Dm]νύχτα μυρίζει γιασε[Am]μί

{verse: Chorus}
[C]Τώ[G]ρα τι να σου [C]πω, [F]φταί[C]ω που σ'' αγαπώ
[F]τ'' ά[C]στρα χίλιοι καημοί κι [Dm]νύχτα μυρίζει γιασε[Am]μί',NULL),
	 ('Always somewhere',34,NULL,0,NULL,'2026-11-04 07:32:00','2026-11-04 07:32:00','{title: Always somewhere}
{verse: Verse}
[C]Arrive at [G]seven, the [F]place [Em]feels [Am]good
[C]No time [G]to call you to[Am]day
[C]Encores till e[G]leven then [F]Chi[Em]nese [Am]food
[C]Back to the [G]hotel a[Am]gain
 
{verse: Verse}
[C]I call your [G]number, the [F]line [Em]ain''t [Am]free
[C]I''d like to [G]tell you come to [Am]me
[C]A night without [G]you [F]seems [Em]like a lost [Am]dream
[C]Love, I [G]can''t tell you how I [Am]feel
 
{verse: Chorus}
[C]Always [G]somewhere, [Am]miss you where I''ve been
[F]I''ll be [G]back to love you [C]again [G]
[C]Always [G]somewhere, [Am]miss you where I''ve been
[F]I''ll be [G]back to love you [C]again [G]
 
{verse: Verse}
[C]Another [G]morning, a[F]no[Em]ther [Am]place
[C]The only [G]day off is far a[Am]way
[C]But every [G]city has [F]seen me [Em]in the [AM]end
[C]And brings [G]me to you a[Am]gain
 
{verse: Chorus}
[C]Always [G]somewhere, [Am]miss you where I''ve been
[F]I''ll be [G]back to love you [C]again [G]
[C]Always [G]somewhere, [Am]miss you where I''ve been
[F]I''ll be [G]back to love you [C]again [G]',NULL),
	 ('Still loving you',34,NULL,0,NULL,'2026-11-04 07:40:14','2026-11-04 07:40:14','{title: Still loving you}
{verse: Intro}
[Am] [G] [F] [E]  | x2
 
{verse: Verse}
[Am]Time, it needs time
To win back your love again.
I will be [B7]there, I will be [E]there.
[Am]Love, only love
Can bring back your love someday.
I will be [B7]there, I will be [E]there.
 
{verse: Break}
[Am] [G] [F] [E]  | x2
 
{verse: Verse}
[Am]Fight, babe, I''ll fight
To win back your love again.
I will be [B7]there, I will be [E]there.
[Am]Love, only love
Can break down the walls someday.
I will be [B7]there, I will be [E]there.
 
{verse: Chorus}
[Am]If we''d [F]go again
[C]All the way from the [G]start.
[Am]I would [F]try to change
The [C]things that killed our [G]love.
[Am]Your pride has [Dm]build a wall, so [E]strong
That I can''t get [Am]through.
Is there [F]really no chance
To [G]start once again?
I''m loving [Am]you.
 
{verse: Break}
[Am] [G] [F] [E]  | x2
 
{verse: Verse}
[Am]Try, baby try
To trust in my love again.
I will be [B7]there, I will be [E]there.
[Am]Love, only love
Just shouldn''t be thrown away.
I will be [B7]there, I will be [E]there.
 
{verse: Chorus/Outro}
[Am]If we''d [F]go again
[C]All the way from the [G]start.
[Am]I would [F]try to change
The [C]things that killed our [G]love.
[Am]Yes I''ve [Dm]hurt your pride, and I [E]know
What you''ve been [Am]through.
You should [F]give me a chance
This [G]can''t be the end.
I''m still loving [Am]you [F] [C] [G]
I''m still loving [Am]you,
I''m still loving [Am]you,
I need your [G]love.
I''m still loving [Am]you [F] [C] [G]',NULL),
	 ('Rock you like a hurricane',34,NULL,0,NULL,'2026-11-04 07:49:32','2026-11-04 09:40:41','{title: Rock you like a hurricane}
{verse: Intro}
[E] [G] [A] [C] [D]  (x8)
 
{verse: Verse}
It''s [C]early [Em]morning
The [C]sun comes [Em]out
Last [C]night was [Em]shaking
And [C]pretty [D]loud
My [C]cat is [Em]purring
And [C]scratches my [Em]skin
So [C]what is [Em]wrong
With [C]another [D]sin
 
{verse: Verse}
The [C]bitch is [Em]hungry
She [C]needs to [Em]tell
So [C]give her [Em]inches
And [C]feed her [D]well
More [C]days to [Em]come
New [C]places to [Em]go
I''ve [C]got to [Em]leave
It''s [C]time for a [D]show
 
{verse: Chorus}
[Em]Here I am,[G] [A]
[C]Rock you like [Em]a hurricane [G] [A] [C] [D]
[Em]Here I am,[G] [A]
[C]Rock you like [Em]a hurricane [G] [A] [C] [D]
 
{verse: Verse}
My [C]body is [Em]burning
It [C]starts to [D]shout
De[C]sire is [Em]coming
It [C]breaks out [D]loud
[C]Lust is in [Em]cages
Till the [C]storm breaks [D]loose
Just [C]have to [Em]make it
With [C]someone I [D]choose
 
{verse: Verse}
The [C]night is [Em]calling
I [C]have to [D]go
The [C]wolf is [Em]hungry
He [C]runs the [D]show
He''s [C]licking his [Em]lips
He''s [C]ready to [D]win
On the [C]hunt to[Em]night
For [C]love at first [D]sting
 
{verse: Chorus}
[Em]Here I am,[G] [A]
[C]Rock you like [Em]a hurricane [G] [A] [C] [D]
[Em]Here I am,[G] [A]
[C]Rock you like [Em]a hurricane [G] [A] [C] [D]',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Holiday',34,NULL,0,NULL,'2026-11-04 07:54:48','2026-11-04 07:54:48','{title: Holiday}
{verse: Intro}
[Am] [E]

{verse: Verse}
[Am]Let me take you far away
You''d [G]like a [E]holi[Am]day
[Am]Let me take you far away
You''d [G]like a [E]holi[Am]day
Exchange the [G]cold days for the [Am]sun
[D]Good times and [E]fun
[Am]Let me take you far away
You''d [G]like a [E]holi[Am]day [E]
 
{verse: Verse}
[Am]Let me take you far away
You''d [G]like a [E]holi[Am]day
[Am]Let me take you far away
You''d [G]like a [E]holi[Am]day
Exchange your [G]troubles for some [Am]love
Wher[D]ever you [E]are
[Am]Let me take you far away
You''d [G]like a [E]holi[Am]day [E]
 
{verse: Verse}
[Am]Longing for the sun till it comes
To the [G]island without [F]name
Longing for the [Am]sun be welcome
[G]On the island many [F]miles away from [Am]home
Be welcome on the [G]island without [F]name
Longing for the [Am]sun till it comes
To the [G]island many [F]miles away from [Am]home',NULL),
	 ('When the smoke is going down',34,NULL,0,NULL,'2026-11-04 08:01:18','2026-11-04 09:38:41','{title: When the smoke is going down}
{verse: Intro}
[Em] [D]

{verse: Verse}
[Em]Just when you [D]make your way back [Em]home
[Em]I find some [D]time to be a[Em]lone
[Em]I go to [D]see the place once [Em]more
[Em]Just like a [D]thousand nights be[Em]fore
 
{verse: Chorus}
[B7]I climb the stage again this [Em]night
''cause the [F]place seems still a[Em]live
When the [D]smoke is going [Em]down
 
{verse: Verse}
[Em]This is the [D]place where I be[Em]long
[Em] I really [D]love to turn you [Em]on
[Em]I''ve got your [D]sound still in my [Em]ear
[Em]While your [D]traces disa[Em]ppear
 
{verse: Chorus}
[B7]I climb the stage again this [Em]night
''cause the [F]place seems still [Em]alive
When the [D]smoke is going [Em]down
When the [D]smoke is going [Em]down
When the [D]smoke is going [Em]down',NULL),
	 ('No one like you',34,NULL,0,NULL,'2026-11-04 08:07:35','2026-11-04 08:07:35','{title: No One Like You}
{verse: Intro}
[Am] [F] [G] [Am] [F] [G]
[Am] [F] [G] [F] [E]
 
{verse: Verse}
[Am]Girl, it''s been a [F]long time that we''ve been a[Am]part
Much too [F]long for a man who needs [Am]love
I [F]miss you since I''ve been a[C]way [E]
[Am]Babe, it wasn''t [F]easy to leave you a[Am]lone
It''s getting [F]harder now that I''m [Am]gone
If [F]I had the choice, I would [C]stay [E]
 
{verse: Chorus}
There''s no one like [Am]you
I can''t [F]wait for the [G]nights with [Am]you
I i[F]magine the [G]things we [Am]do
I just [F]wanna be [G]loved by [F]you [E]
No one like [Am]you
I can''t [F]wait for the [G]nights with [Am]you
I i[F]magine the [G]things we [Am]do
I just [F]wanna be [G]loved by [F]you [E]
 
{verse: Verse}
[Am]Girl, there are [F]really no words strong e[Am]nough
To de[F]scribe all my longing for [Am]love
I [D]don''t want my feelings re[C]strained [E]
Ooh, [Am]babe, I just [F]need you like never be[Am]fore
Just i[F]magine you''d come through this [Am]door
To [F]take all my sorrow a[C]way [E]
 
{verse: Chorus}
There''s no one like [Am]you
I can''t [F]wait for the [G]nights with [Am]you
I i[F]magine the [G]things we [Am]do
I just [F]wanna be [G]loved by [F]you [E]
No one like [Am]you
I can''t [F]wait for the [G]nights with [Am]you
I i[F]magine the [G]things we [Am]do
I just [F]wanna be [G]loved by [F]you [E]',NULL),
	 ('Lonely nights',34,NULL,0,NULL,'2026-11-04 08:17:42','2026-11-04 09:35:29','{title: Lonely nights}
{verse: Intro}
[Am] [F] [G] [Em]
[Am] [F] [G] [C]
[Am] [F] [G] [Em]
[Am] [F] [G]

{verse: Verse}
Since you''re [Am]gone [F] [G]
[Em]There is an [Am]empty [F]space [G]
[C]Since you''re [Am]gone [F] [G]
The [Em]world is [Am]not the [F]same [G] [C]
 
{verse: Pre-chorus}
[Am]I go back to the [Dm]places we''ve been
It [G]feels like you''re still [C]there [E]
[Am]I live all those [Dm]moments again
[G]Wishing you were [E]here
 
{verse: Verse}
Since you''re [Am]gone [F] [G]
[Em]There is a [Am]lonely [F]heart [G]
[C]Since you''re [Am]gone [F] [G]
[Em]Nothing is [Am]like it [F]was [G] [C]
 
{verse: Pre-chorus}
[Am]There are memories all [Dm]over the place
[G]Bringin'' it back all so [C]clear [E]
[Am]Remember [Dm]all of those days
[G]Wishing you were [E]here

{verse: Chorus}
All those [Am]lonely nights
[F]lonely nights, [Am]lonely nights
[F]lonely nights, [Am]lonely nights
[F]I gotta fight for [C]you, yes I [E]do
Yes I [Am]do [F] [G] [Em]

{verse: Interlude}
[Am] [F] [G]

{verse: Verse}
Since you''re [Am]gone [F] [G]
[Em]There is a [Am]heart that [F]bleeds [G]
[C]Since you''re [Am]gone [F] [G]
I''m [Em]not the man I [Am]used to [F]be [G] [C]
 
{verse: Pre-chorus}
[Am]I follow you [Dm]steps in the snow
The [G]traces disa[C]ppear [E]
[Am]We know what we''ve [Dm]lost when it''s gone
I''m [G]wishing you were [E]here
 
{verse: Chorus}
All those [Am]lonely nights
[F]lonely nights, [Am]lonely nights
[F]lonely nights, [Am]lonely nights
[F]I gotta fight for [C]you, yes I [E]do
Yes I [Am]do [F] [G] [Em]',NULL),
	 ('Sleeping satellite',128,NULL,0,NULL,'2026-11-04 14:19:12','2026-11-04 14:19:12','{title: Sleeping Satellite}
{verse: Chorus}
[Am]I blame you for the [D]moonlit sky
and the [Em]dream that died, with the Eagle''s flight
[Am]I blame you for the [D]moonlit nights
when I [Em]wonder why, are the seas still dry
[F]Don''t blame this [G]sleepin'' satellite
 
{verse: Verse}
Did we [Am]fly to the moon too soon, did we [G]spoil another chance
In the rush of the [F]race, the reason we chase
is a lost in [G]romance
[Am]And still we [G]try
To [F]justify the waste for a taste
Some man''s [Em]greatest adventure, wo''oh
 
{verse: Chorus}
[Am]I blame you for the [D]moonlit sky
and the [Em]dream that died, with the Eagle''s flight
[Am]I blame you for the [D]moonlit nights
when I [Em]wonder why, are the seas still dry
[F]Don''t blame this [G]sleepin'' satellite
 
{verse: Verse}
Have we [Am]lost what it takes to advance, have we [G]been too soon
If the world is a [F]dream, then why does it scream?
under a [G]blue moon
[Am]We wonder [G]why
if the [F]earth''s sacrificed for a price
of it''s [Em]greatest treasure, wo''oh
 
{verse: Chorus}
[Am]I blame you for the [D]moonlit sky
and the [Em]dream that died, with the Eagle''s flight
[Am]I blame you for the [D]moonlit nights
when I [Em]wonder why, are the seas still dry
[F]Don''t blame this [G]sleepin'' satellite
 
{verse: Verse}
And [Am]when we shoot for the stars, what a [G]giant step
Have we got what it [F]takes, to carry the weight?
[G]of it''s consense
[Am]Or pass it [G]by
Like a [F]shot in the dark, with some mark
with a [Em]sense of adventure, wo''oh
 
{verse: Outro}
[Am]  Wo''oh oh [D]o''oh, yeah''[Em]yeah yeah
[Am]  Wo''oh oh [D]o''oh, yeah''[Em]yeah yeah
[F]Don''t blame this [G]sleepin'' satellite',NULL),
	 ('Big city nights',34,NULL,0,NULL,'2026-11-04 14:36:03','2026-11-04 14:36:03','{title: Big City Nights}
{verse: Intro}
[Am] [F] [E] [D] [G]
 
{verse: Verse}
When the [Am]daylight [F]
is falling [C]down into the [Dm]night
And the [Am]sharks try [F]
to cut a [C]big piece out of [E]life
 
{verse: Verse}
It feels [Am]alright to go [F]out
to catch an [C]   outrageous [Dm]thrill
But it''s [Am]more like spinning [F]wheels
of fortune [C]which never stand [E]still
 
{verse: Chorus}
[Am]Big city, [F]big city [G]nights,
[G]you keep me burning
[Am]Big city, [F]big city [G]nights
 
{verse: Verse}
When the [Am]sunlight [F]
is rising [C]up in my [Dm]eyes
And the [Am]long night [F]
has left me [C]back at somebody''s [E]side
 
{verse: Verse}
It feels [Am]alright for a [F]long
sweet minute [C]  like hours be[Dm]fore
But it''s [Am]more like looking [F]out
for something, [C] can''t find any[E]more
 
{verse: Chorus}
[Am]Big city, [F]big city [G]nights,
[G]you keep me burning
[Am]Big city, [F]big city [G]nights, always yearning
 
{verse: Bridge}
[E]There is no [G]dream that you can''t make [C]true
if you''re looking for [Bm]love
[E]But there''s no [G]girls burning the [C]ice
away from my [D]heart,       maybe to[Am]night

{verse: Chorus}
[Am]Big city, [F]big city [G]nights,
[G]you keep me burning
[Am]Big city, [F]big city [G]nights, always yearning',NULL),
	 ('RNR Στο κρεβάτι',2,NULL,0,NULL,'2026-11-05 10:54:29','2026-11-05 10:54:29','{title: RNR Στο κρεβάτι}
{verse: Verse}
[E]Γουστάρω να σ'' ακούω κούκλα μου όταν μιλάς [G] [A] [E]
[E]να αλληθωρίζουν μάτια όταν στην πίστα πηδάς  [G] [A] [E]
[E]γουστάρω όταν ακούω αχ τι παιδί είναι αυτό  [G] [A] [E]
[E]γιατί εσύ ξέρεις στο κρεβάτι τι θα πει ροκ εντ ρολ  [G] [A] [E]
 
{verse: Chorus}
Στα [B7]σκοτεινά δωμάτια είν'' η ψυχή μας γυμνή και δεν χωράν εκεί μυστικά
και ''συ μονάχα ξέρεις πως η αλήθεια είναι εκεί
που η μονα[C]ξιά μου στον κα[D]θρέφτη κοι[E]τά
 
{verse: Verse}
[E]Γουστάρω που όταν κλαίω δε ρωτάς το γιατί  [G] [A] [E]
[E]γιατί εσύ ξέρεις πως ο πόνος μου έχει αιτία τυφλή  [G] [A] [E]
[E]Γουστάρω σαν γατούλα όταν μου παίζεις κρυφτό  [G] [A] [E]
[E]κι όταν φοβάμαι μη σε χάσω να μου λες σ'' αγαπώ  [G] [A] [E]
 
{verse: Chorus}
Στα [B7]σκοτεινά δωμάτια είν'' η ψυχή μας γυμνή και δεν χωράν εκεί μυστικά
και συ μονάχα ξέρεις πως η αλήθεια είναι εκεί
που η μονα[C]ξιά μου στον κα[D]θρέφτη κοι[E]τά
 
{verse: Verse}
[E]Το ξέρω πως - [E]δεν είμαι αυτός - που πάνω του θα [G]στη[A]ριχτείς [E]
[E]κι ούτε λεφτάς - [E]κι ίσως γυρνάς - πιωμένο μες τα [G]μπαρ [A]να με βρεις [E]
[E]μα όμως εγώ - [E]θα σου μετρώ - της πόλης το σφυγ[G]μό με [A]αγκαλιές [E]
[E]θα σου χαϊδεύω - [E]το μυαλό - με χίλιες και μια [G]νύχτα γλυ[A]κές [E]

{verse: Chorus}
Στα [B7]σκοτεινά δωμάτια είν'' η ψυχή μας γυμνή και δεν χωράν εκεί μυστικά
και εκεί να σ'' αγαπάω ξέρω κούκλα μου εκεί
τη μονα[C]ξιά μου στον κα[D]θρέφτη όταν [E]σπας',NULL),
	 ('Μη με ονειρευτείς',129,NULL,0,NULL,'2026-11-06 11:58:23','2026-11-06 11:58:23','{title: Μη με ονειρευτείς}
{verse: Verse}
[Am]Κι αν μ'' αγα[G]πάς, κι αν με θυ[F]μάσαι
Δεν σ'' έχω [Am]πια [F] [G] [Am]
Είσαι μακρι[G]ά, όπου και [F]να ''[G]σαι
σ'' άλλη τρο[F]χιά [G], σ'' άλλη αγκα[F]λιά [G]
 
{verse: Chorus}
[F]Μη με ονειρευ[C]τείς, μη ρω[G]τάς αν [Am]ζω
[F]Να μη μ'' αγα[C]πάς, αν δεν [Em]είσαι ε[Am]δώ
[F]Μη μ'' επιθυ[C]μείς, μη ρω[G]τάς αν [Am]ζω
[F]Να μη μ'' αγα[C]πάς, αν δεν [Em]είσαι ε[Am]δώ
 
{verse: Verse}
[Am]Μη μ'' αγα[G]πάς, αν δεν το [F]ξέρω
Όλα είσ'' ε[Am]σύ [F] [G] [Am]
Ανάσα εσύ, που αν δεν την [F]παίρνω [G]
δεν έχω [F]πια, [G] εγώ ζω[F]ή [G]
 
{verse: Chorus}
[F]Μη με ονειρευ[C]τείς, μη ρω[G]τάς αν [Am]ζω
[F]Να μη μ'' αγα[C]πάς, αν δεν [Em]είσαι ε[Am]δώ
[F]Μη μ'' επιθυ[C]μείς, μη ρω[G]τάς αν [Am]ζω
[F]Να μη μ'' αγα[C]πάς, αν δεν [Em]είσαι ε[Am]δώ',NULL),
	 ('Everything I do I do it for you',130,NULL,0,NULL,'2026-11-06 14:51:13','2026-11-06 14:51:13','{title: Everything I Do I Do It For You}
{verse: Intro}
[D] [A] [G] [A]
 
{verse: Verse}
[D]Look into my eyes, [A]you will see
[G]What you mean to [A]me
Search your [D]heart, search your [A]soul
And when you [G]find me there you''ll [D]search no [A]more
 
{verse: Chorus}
Don''t [Em]tell me it''s not worth [D]tryin'' [Em]for
You can''t tell me it''s not worth [D]dyin'' [Em]for
You know it''s [D]true
Everything I [A]do, I do it [D]for you
 
{verse: Verse}
[D]Look into your heart, [A]you will find
There''s [G]nothin'' there to [A]hide
Take me as I [D]am, take my [A]life
I would [G]give it all, I would [D]sacri[A]fice
 
{verse: Chorus}
Don''t [Em]tell me it''s not worth [D]fighting [Em]for
I can''t help it there''s nothing [D]I want [Em]more
You know it''s [D]true
Everything I [A]do, I do it [D]for you
 
{verse: Bridge}
There''s [C]no love, like [F]your love
And no [C]other, could give [G]more love
There''s [D]nowhere, unless [A]you''re there
All the [E]time, all the [A]way
 
{verse: Chorus}
Oh, you can''t [Em]tell me it''s not worth tryin'' [A]for
I can''t [Em]help it, there''s nothin'' I want [A]more [G]
Yeah, I would [D]fight for you, I''d [A]lie for you
Walk the [G]wire for you, yeah I''d [Gm]die for you
 
{verse: Outro}
You know it''s [D]true
Everything I [A]do, [G]oh, [Em]    I do it [D]for you...',NULL),
	 ('Βοριάς',131,NULL,0,NULL,'2026-11-06 14:51:13','2026-11-06 14:51:13','{title: Βοριάς}
{verse: Verse}
[Am]Μη με κοιτάς μέσα στα μάτια, [Em]μη
Σου το λέω φοβάμαι σαν παι[Dm]δί
Νιώθω πως μαζί σου θα αφε[Em]θώ
Και τρομάζω

{verse: Verse}
[Am]Μη, μη μου πεις πως ήταν μια στι[Em]γμή
Γίνε ήλιος κι όχι αστρα[Dm]πή
Βλέπω κάτι ωραίο στον ουρα[Em]νό
Στ'' αγοράζω
 
{verse: Chorus}
[Am]Να φορέσω το φεγγάρι στο λαι[Em]μό σου
Να γίνω δάκρυ και παράπο[G]νό σου
Να ''μαι βοριάς επάνω στις πλη[Dm]γές
Να φυσάω

{verse: Chorus}
[Am]Σαν αέρας να δροσίζω το κορ[Em]μί σου
Τον κόσμο να γυρνάω μόνο μα[G]ζί σου
Έρωτας να ''ναι από άλλες επο[Dm]χές
Σ'' αγαπάω
 
{verse: Verse}
[Am]Μη με κοιτάς μέσα στα μάτια, [Em]μη
Γίνε βλέμμα, φλόγα και αρ[Dm]χή
Νιώθω ότι κλέβεις στο λε[Em]πτό
Το μυαλό μου

{verse: Verse}
[Am]Μη μου γελάς γιατί είναι φυλα[Em]κή
Δεν με νοιάζει πέτα το κλει[Dm]δί
Σε έναν κόσμο θα σε πάω ε[Em]γώ
Στον δικό μου

{verse: Chorus}
[Am]Να φορέσω το φεγγάρι στο λαι[Em]μό σου
Να γίνω δάκρυ και παράπο[G]νό σου
Να ''μαι βοριάς επάνω στις πλη[Dm]γές
Να φυσάω

{verse: Chorus}
[Am]Σαν αέρας να δροσίζω το κορ[Em]μί σου
Τον κόσμο να γυρνάω μόνο μα[G]ζί σου
Έρωτας να ''ναι από άλλες επο[Dm]χές
Σ'' αγαπάω',NULL);
INSERT INTO public.songs (title,artist_id,tuning,capo,song_key,created_at,updated_at,"content",strumming_pattern) VALUES
	 ('Hotel of California',1,NULL,0,NULL,'2026-09-08 13:21:12','2026-10-16 10:41:43','{title: Hotel California}
{verse: Intro}
[Am]  [E]  [G]  [D]   [F]  [C] [ Dm]  [E]
 
{verse: Verse}
[Am]On a dark desert highway, [E]cool wind in my hair
[G]Warm smell of colitas [D]rising up through the air
[F]Up ahead in the distance, [C]I saw a shimmering light
[Dm]My head grew heavy and my sight grew dim; [E]I had to stop for the night.

[Am]There she stood in the dooway, [E]I heard the mission bell
[G]And I was thinking to myself [D]This could be heaven or this could be Hell
[F]Then she lit up a candle, [C]and she showed me the way
[Dm]There were voices down the corridor [E]I thought I heard them say...
 
{verse: Chorus}
[F]Welcome to the Hotel Cali[C]fornia...
Such a [E]lovely place, (such a lovely place) such a [Am]lovely face...
[F]Plenty of room at the Hotel Cali[C]fornia...
Any [Dm]time of year, (any time of year) you can [E]find it here...
 
{verse: Verse}
[Am]Her mind is Tiffany-twisted [E]she got the Mercedes Bends
[G]She got a lot of pretty pretty boys [D]that she calls friends
[F]How the dance in the courtyard, [C]sweet summer sweat
[Dm]Some dance to remember [E]some dance to forget

[Am]So I called up the Captain [E]please bring me my wine
[G]He said: "We havent had that spirit here since [D]nineteen sixty-nine
[F]And still those voices are calling from [C]far away
[Dm]Wake you up in the middle of the night [E]just to hear them say...
 
{verse: Chorus}
[F]Welcome to the Hotel Cali[C]fornia...
Such a [E]lovely place, (such a lovely place) such a [Am]lovely face...
[F]They living it up at the Hotel of Cali[C]fornia...
What a [Dm]nice surprise, (what a nice surprise) bring your [E]alibis...
 
{verse: Verse}
[Am]Mirrors on the ceiling [E]the pink champagne on ice
And she said:[G]"We are all just prisoners here [D]of our own device
[F]And in the masters chambers [C]they gathered for the feast
[Dm]They stab it with their steely knives but they [E]just cant kill the beast
 
[Am]Last thing I remember, I was [E]running for the door
[G]I had to find the passage back to the [D]place I was before
[F]Relax said the night man, We are [C]programmed to receive
[Dm]You can check out anytime you like [E]but you can never leave
 ',NULL),
	 ('Αν δεν είχα και εσένα',9,NULL,NULL,NULL,'2026-11-09 12:43:01.771321','2026-11-09 12:43:01.771321','{title: Αν δεν είχα και εσένα}
{verse: Verse}
[C]Με προδώσαν οι φίλοι μου, μα να είσαι καλά
που σαν βράχος μου [F]στάθηκες στην κάθε συμφο[C]ρά
[C]Μου κρατούσες το χέρι [F]στα λασπόνε[C]ρα
[C]Βόηθα Πανα[F]γιά μου, [G]και μη χειρότε[C]ρα
 
{verse: Chorus}
Αν δεν [Am]είχα και [Em]σένανε, τι θα [Am]ήμουν στη [Em]γη 
[F]Μπορεί αλήτης [C]να ''μουνα, [G]να ''χα καταστρα[C]φεί
 
{verse: Verse}
[C]Όπου ρίξω το βλέμμα μου, μόνο πόνο θα δω
και χιλιάδες πα[F]ράπονα στον κόσμο αυ[C]τό
[C]Και βουλιάζει η ζωή μας [F]στα λασπόνε[C]ρα
[C]Βόηθα Πανα[F]γιά μου, [G]και μη χειρότε[C]ρα
 
{verse: Chorus}
Αν δεν [Am]είχα και [Em]σένανε, τι θα [Am]ήμουν στη [Em]γη
[F]Μπορεί αλήτης [C]να ''μουνα, [G]να ''χα καταστρα[C]φεί',NULL),
	 ('Πιο καλή μοναξιά',9,NULL,NULL,NULL,'2026-11-08 12:13:32.565338','2026-11-08 12:13:32.565338','
{title: Πιο καλή μοναξιά}
{verse: Verse}
[C]Να ''χε χρώμα η μοναξιά, στο χαρτί να ζωγρα[Dm]φίσω
Να την κάνω θαλασσιά και α[G]γέρα πελα[C]γίσο
Να της βάλω και πα[Em]νιά  για ταξίδι τελευ[F]ταίο
λιμανάκι στο Αι[C]γαίο, [G]  η δική μου αγκα[C]λιά

{verse: Chorus}
[C]Πιο καλή η μονα[F]ξιά από σένα που δε [C]φτάνω
Μια σε βρίσκω, μια σε [G]χάνω [F]
Πιο καλή η μονα[C]ξιά

{verse: Verse}
[C]Να ''ταν πέτρα η μοναξιά, σκαλοπάτι να τ'' α[Dm]νέβεις
Να χαθείς στη λησμονιά για να [G]μη σε δω που [C]φεύγεις
και να γίνεσαι κα[Em]πνός, σαν τσιγάρο που τε[F]λειώνει
τώρα πια θα είσαι [C]μόνη [G]  και θα είμαι μονα[C]χός

{verse: Chorus}
[C]Πιο καλή η μονα[F]ξιά από σένα που δε [C]φτάνω
Μια σε βρίσκω, μια σε [G]χάνω [F]
Πιο καλή η μονα[C]ξιά
',NULL),
	 ('Φταίμε και οι δυο',9,NULL,NULL,NULL,'2026-11-09 12:26:18.650165','2026-11-09 12:26:18.650165','{title: Φταίμε κι οι δυο}
{verse: Verse}
[Am]Λες πως έφταιξα εγώ που χωρίσαμε οι [Dm]δυο μας
και καράβι στο βυθό είναι τώρα τ'' όνει[Am]ρό μας
[F]Λες πως έφταιξα ε[Em]γώ, αλλά αλίμο[Am]νό μας
[F]είν'' το φταίξιμο δι[Em]πλό σε κάθε χωρι[Am]σμό
 
{verse: Chorus}
Φταίμε κι οι [Am]δυο που ζούμε [Dm]χώρια
κάτω απ'' τον [G]ίδιο ουρα[C]νό [E]
Και μας [Am]ξυπνά η στενα[Dm]χώρια
και λέει βρα[G]χνά φταίμε κι οι [E]δυο
 
{verse: Verse}
[Am]Λες πως έφταιξα εγώ που ναυάγησε η ζω[Dm]ή μας
κι είναι δάκρυ αλμυρό τώρα κάθε ανάμνη[Am]σή μας
[F]Λες πως έφταιξα ε[Em]γώ για την καταστρο[Am]φή μας
[F]όμως πρέπει να στο [Em]πω πως φταίξαμε κι οι [Am]δυο
 
{verse: Chorus}
Φταίμε κι οι [Am]δυο που ζούμε [Dm]χώρια
κάτω απ'' τον [G]ίδιο ουρα[C]νό [E]
Και μας [Am]ξυπνά η στενα[Dm]χώρια
και λέει βρα[G]χνά φταίμε κι οι [E]δυο',NULL),
	 ('Της μοίρας το παιχνίδι',9,NULL,NULL,NULL,'2026-11-09 12:55:38.98781','2026-11-09 12:55:38.98781','{title: Της μοίρας το παιχνίδι}
{verse: Verse}
[Am]Καθισμένος στο [E]απέναντι πα[Am]γκάκι
Σαββα[Am]τόβραδο μπρο[F]στά στην εκκλη[E]σιά
Βλέπω ε[Dm]κείνη που αγαπούσα
γελα[G]στή κι ασπροφο[Am]ρούσα
ν'' ανε[Dm]βαίνει μ'' έναν άλλον τα σκα[E]λιά
Βλέπω ε[Dm]κείνη που αγαπούσα`
γελα[G]στή κι ασπροφο[Am]ρούσα
ν'' ανε[Dm]βαίνει μ'' έναν [E]άλλον τα σκα[Am]λιά

{verse: Chorus}
Θέλει η [E]μοίρα το φινάλε της να [F]παί...[Am]ξει
και το [G]παίζει μες [Dm]στα μάτια μου μπρο[E]στά
Και της [E]εκκλησιάς τον κήπο έχει [F]δια-λέ[Am]ξει
για να [E]γίνει το [Dm]παιχνίδι της σω[Am]στά

{verse: Verse}
[Am]Το χαμόγελο έχει [E]φύγει απ'' το [Am]στόμα
Το τσι[Am]γάρο έχει [F]πέσει κατα[E]γής
Ζωντα[Dm]νό έχω γίνει πτώμα
αχ Θε[G]έ, μου λίγο α[Am]κόμα
κι ένας [Dm]άνθρωπος θα μείνει δυστυ[E]χής
Ζωντα[Dm]νό έχω γίνει πτώμα
αχ Θε[G]έ, μου λίγο α[Am]κόμα
κι ένας [Dm]άνθρωπος θα [E]μείνει δυστυ[Am]χής

{verse: Chorus}
Θέλει η [E]μοίρα το φινάλε της να [F]παί...[Am]ξει
και το [G]παίζει μες [Dm]στα μάτια μου μπρο[E]στά
Και της [E]εκκλησιάς τον κήπο έχει [F]δια-λέ[Am]ξει
για να [E]γίνει το [Dm]παιχνίδι της σω[Am]στά',NULL),
	 ('Ναχα τη δύναμη',14,NULL,NULL,NULL,'2026-11-09 15:27:27.48346','2026-11-09 15:27:27.48346','{title: Ναχα τη δύναμη}
{verse: Verse}
[Am]Χωρίς το σύννεφο βρο[F]χή δεν κατε[C]βαίνει
ούτε το [G]δάκρυ χωρίς καη[C]μό [E] [Am]
[Am]Χωρίς τον άνεμο τα [F]δέντρα δε [C]λυγάνε
Δε σταμα[G]τάν οι πίκρες [E]δίχως γυρι[Am]σμό
 
{verse: Chorus}
Αχ να μπο[C]ρούσα τα λι[G]μάνια να τα [C]κλείσω
Να σταμα[Em]τήσω τα [F]τραί[A]να στο στα[Dm]θμό [G]
[G]Να ''χα τη [Am]δύναμη [G]τα βράχια να κυ[F]λήσω
να μην α[C]φήσω δρόμο [G]για το χωρι[C]σμό
 
{verse: Verse}
[Am]Γιατί κοιτάς τα μάτια [F]μου τα βουρκω[C]μένα
Πού πάς στα [G]ξένα, σ'' ωκεα[C]νό [E] [Am]
[Am]Γιατί κοιτάς τα χέρια [F]μου τα λαβω[C]μένα
Πού πας στα [G]ξένα κι έχουν [E]σφίξει κεραυ[Am]νό
 
{verse: Chorus}
Αχ να μπο[C]ρούσα τα λι[G]μάνια να τα [C]κλείσω
Να σταμα[Em]τήσω τα [F]τραί[A]να στο στα[Dm]θμό [G]
[G]Να ''χα τη [Am]δύναμη [G]τα βράχια να κυ[F]λήσω
να μην α[C]φήσω δρόμο [G]για το χωρι[C]σμό',NULL),
	 ('Δεν μπορώ',61,NULL,NULL,NULL,'2026-11-10 06:07:09.014702','2026-11-10 06:07:09.014702','{title: Δεν μπορώ}
{verse: Verse}
Να [Am]γλιστρούσες στο σκο[Em]τάδι
Να πετούσες σαν αερι[G]κό
Θα πε[Dm]θάνω αυτό το [Am]βράδυ
Θα πεθάνω αν [G]δε σε [F]δω
 
{verse: Verse}
Με [Am]γλυκό κρασί θα [Em]γίνω
Αργοναύτης να ''ρθω να σε [G]βρω
Να σε [Dm]ανταμώσω [Am]λίγο
Στης ψυχής μου [G]το βυ[F]θό
 
{verse: Chorus}
[C]Δεν [G]μπο[Am]ρώ
[C]Ο χειμώνας με πληγώνει άλλο [G]πια, δεν μπο[Dm]ρώ
[C]Δεν [G]μπο[Am]ρώ
Την αυλή μου καίει το χιόνι, άλλο [G]πια δεν μπο[Dm]ρώ
 
{verse: Verse}
[Am]Είσαι τ'' άγγιγμα του α[Em]νέμου
Που μου ξαφνιάζει το κορ[G]μί
Δεν σε [Dm]χόρτασα πο[Am]τέ μου
Όλα ήταν [G]μια στιγ[F]μή
 
{verse: Verse}
Να γλι[Am]στρούσες στο σκο[Em]τάδι
Να πετούσες σαν αερι[G]κό
Θα πε[Dm]θάνω αυτό το [Am]βράδυ
Θα πεθάνω αν [G]δε σε [F]δω
 
{verse: Chorus}
[C]Δεν [G]μπο[Am]ρώ
[C]Ο χειμώνας με πληγώνει άλλο [G]πια, δεν μπο[Dm]ρώ
[C]Δεν [G]μπο[Am]ρώ
Την αυλή μου καίει το χιόνι, άλλο [G]πια δεν μπο[Dm]ρώ',NULL),
	 ('Μια βραδιά στο λούκι',47,NULL,NULL,NULL,'2026-11-10 06:12:36.237223','2026-11-10 06:12:36.237223','{title: Μια βραδιά στο λούκι}
{verse: Verse}
Προχ[G]θές εκεί που [D]τα ''πινα με [C]κάποιο κολλη[G]τό μου
κοιτώ και βλέπω [C]πίσω μου δυο [G]μάτια, δυο μα[D]τάκια
Γυ[Em]ρίζω στον δικό μου, ο [Bm]τύπος μου Nικόλα
και [F]μένα μ'' απαντάει, και ''[D]κει αρχίσαν όλα
 
{verse: Verse}
E[G]γώ αυτοσυγκε[D]ντρώθηκα για [C]να την μαγνη[G]τίσω
αυτά είναι κόλπα [C]ζόρικα που [G]κάνουν στην Iν[D]δία
Α[Em]λήθεια σάς το λέω, α[Bm]πότυχα τελείως
Δε [F]μου ''δινε καμία, μα κα[D]μία σημασία
 
{verse: Verse}
Ό[G]πως καταλα[D]βαίνετε, δεν [C]μ'' έπαιρνε κα[G]θόλου
αλλά εξακο[C]λούθησα ε[G]ρήμην να κοι[D]τάω
Ο [Em]φίλος μου εγκρίνιαζε, ρε [Bm]Χάρη σου μιλάω
για [F]πες μου σε κοιτάει; Κα[D]θόλου, τού απαντάω
 
{verse: Verse}
Σε [G]μια στιγμή το [D]βλέμμα της πλα[C]νήθηκε στο [G]χώρο
κι απάνω μου στα[C]μάτησε σαν [G]κάτι να ζη[D]τούσε
Τα[Em]ράχτηκα και σκέφτηκα, Θεέ μου ε[Bm]μένανε κοιτάει
Ό[F]μως εκείνη κοίταγε να [D]βρει τον σερβιτόρο
 
{verse: Verse}
Βο[G]ήθεια [D]χριστιανοί, κο[C]ντεύω να φλι[G]πάρω
εγώ για κείνη [C]χάνομαι και [G]κείνη ούτε με [D]ξέρει
Αχ [Em]να ''μουν αεράκι, κα[Bm]πνός από τσιγάρο
Στα [F]στήθια της να μπαίνω κι ε[D]κείνη ας μη με θέλει
 
{verse: Verse}
Βο[G]ήθεια [D]χριστιανοί, κο[C]ντεύω να φλι[G]πάρω
Ζηλεύω όποιον [C]τής μιλά και [G]όποιον την κοι[D]τάει
Μα [Em]πιο πολύ ζηλεύω ε[Bm]κείνον π'' αγαπάει
Σαν [F]τρέμει το κορμάκι της και [D]σαν λιγοθυμάει',NULL);
