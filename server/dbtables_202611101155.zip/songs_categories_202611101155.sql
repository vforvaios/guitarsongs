INSERT INTO public.songs_categories (name,parent_id,created_at) VALUES
	 ('ΛΑΙΚΑ',NULL,'2026-09-08 13:20:01'),
	 ('ΕΝΤΕΧΝΑ ΕΛΛΗΝΙΚΑ',NULL,'2026-09-08 13:20:01'),
	 ('ΞΕΝΑ',NULL,'2026-09-08 13:20:01');
