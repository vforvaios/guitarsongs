INSERT INTO public.page_sections (id,name,contenttype) VALUES
	 (1,'HEADER',''),
	 (2,'HEROBANNERS','imageAndLink'),
	 (3,'ABOUTUS','richTextEditor'),
	 (4,'CALENDAR','calendar'),
	 (5,'FOOTER',''),
	 (6,'GALLERY','gallery'),
	 (7,'CONTACT',''),
	 (8,'BOOKING','booking');
