INSERT INTO public.categories (id,category_name,isactive) VALUES
	 (1,'ΑΘΛΗΤΙΚΑ',1),
	 (2,'ΙΣΤΟΡΙΑ',1),
	 (3,'ΚΙΝΗΜΑΤΟΓΡΑΦΟΣ',1),
	 (4,'ΓΕΩΓΡΑΦΙΑ',1);
