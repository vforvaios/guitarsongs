INSERT INTO public.users (userid,name,email,"password",isactive,isadmin) VALUES
	 ('921d0d39-5b52-4a9d-9052-b34403096e46','vaios','vaios_a@outlook.com','$2b$12$x8KcLpDfu0CmhvA.fqQtM.B7b4qfzcVYWR67P4u0S.jVxlnSLxLjG',1,1);
