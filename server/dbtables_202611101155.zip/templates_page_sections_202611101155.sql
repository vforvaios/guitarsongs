INSERT INTO public.templates_page_sections (id,template_id,page_section_id) VALUES
	 (1,1,1),
	 (2,1,2),
	 (3,1,3),
	 (4,1,6),
	 (5,1,5),
	 (6,1,7),
	 (7,1,8);
