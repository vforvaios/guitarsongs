INSERT INTO public.tenants (id,tenant_id,name,"password",email,template_id,isactive,createdat) VALUES
	 (3,'5dd8bbbd-b90e-4cd5-b20d-1f581538003a','quickpage-orxo','$2b$12$U7dC3zPO9K1CrmaOtMMNsO9ZPPNWq1R9fdAPFB4brJvwZmQFFapDy','vaios_a@outlook.com',1,1,'2025-10-07 12:37:03');
