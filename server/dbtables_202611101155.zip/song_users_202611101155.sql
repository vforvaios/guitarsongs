INSERT INTO public.song_users (email,"password") VALUES
	 ('vaios_a@outlook.com','$2b$12$dMJBTD2KWO4htTIJ.TKPjuZdbjAB/QDNXOkCo.WOHu8Elb4.lBu5i');
