INSERT INTO public.templates (id,name,image,variant,isactive) VALUES
	 (1,'Simple','simple.jpg','simple',1);
