INSERT INTO public.tenant_services (id,tenant_id,name,duration_minutes,price,isactive) VALUES
	 (1,'5dd8bbbd-b90e-4cd5-b20d-1f581538003a','Κούρεμα ανδρικό',30,15,1);
